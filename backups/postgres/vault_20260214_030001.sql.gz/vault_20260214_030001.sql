--
-- PostgreSQL database dump
--

\restrict xNKtVxFdM8tDxSxPmgid5RdMmZEZtahqwPMlapmnFXap9u0gpuyqFE0vhvpbNKY

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg12+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: cleanup_expired_reset_tokens(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.cleanup_expired_reset_tokens() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM password_reset_tokens
    WHERE expires_at < NOW();

    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


ALTER FUNCTION public.cleanup_expired_reset_tokens() OWNER TO vault;

--
-- Name: FUNCTION cleanup_expired_reset_tokens(); Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON FUNCTION public.cleanup_expired_reset_tokens() IS 'Deletes expired password reset tokens';


--
-- Name: find_similar_faces(uuid, public.vector, double precision, integer); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.find_similar_faces(p_user_id uuid, p_face_embedding public.vector, p_threshold double precision DEFAULT 0.6, p_limit integer DEFAULT 10) RETURNS TABLE(face_id uuid, item_id uuid, cluster_id uuid, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        f.id as face_id,
        f.item_id,
        f.cluster_id,
        1 - (f.embedding <=> p_face_embedding) as similarity
    FROM faces f
    WHERE f.user_id = p_user_id
      AND 1 - (f.embedding <=> p_face_embedding) > p_threshold
    ORDER BY f.embedding <=> p_face_embedding
    LIMIT p_limit;
END;
$$;


ALTER FUNCTION public.find_similar_faces(p_user_id uuid, p_face_embedding public.vector, p_threshold double precision, p_limit integer) OWNER TO vault;

--
-- Name: semantic_search(uuid, public.vector, integer); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.semantic_search(p_user_id uuid, p_query_embedding public.vector, p_limit integer DEFAULT 20) RETURNS TABLE(item_id uuid, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.item_id,
        1 - (e.embedding <=> p_query_embedding) as similarity
    FROM embeddings e
    JOIN vault_items v ON e.item_id = v.id
    WHERE e.user_id = p_user_id
      AND v.deleted_at IS NULL
    ORDER BY e.embedding <=> p_query_embedding
    LIMIT p_limit;
END;
$$;


ALTER FUNCTION public.semantic_search(p_user_id uuid, p_query_embedding public.vector, p_limit integer) OWNER TO vault;

--
-- Name: update_album_count(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_album_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE albums SET item_count = item_count + 1, updated_at = NOW()
        WHERE id = NEW.album_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE albums SET item_count = GREATEST(0, item_count - 1), updated_at = NOW()
        WHERE id = OLD.album_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_album_count() OWNER TO vault;

--
-- Name: update_storage_quota(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_storage_quota() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO storage_quotas (user_id, used_bytes, file_count)
        VALUES (NEW.user_id, NEW.file_size, 1)
        ON CONFLICT (user_id) DO UPDATE
        SET used_bytes = storage_quotas.used_bytes + NEW.file_size,
            file_count = storage_quotas.file_count + 1,
            updated_at = NOW();
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE storage_quotas 
        SET used_bytes = GREATEST(0, used_bytes - OLD.file_size),
            file_count = GREATEST(0, file_count - 1),
            updated_at = NOW()
        WHERE user_id = OLD.user_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_storage_quota() OWNER TO vault;

--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at() OWNER TO vault;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: album_items; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.album_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    album_id uuid NOT NULL,
    item_id uuid NOT NULL,
    sort_order integer DEFAULT 0,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.album_items OWNER TO vault;

--
-- Name: albums; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.albums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    parent_id uuid,
    encrypted_name text NOT NULL,
    encrypted_description text,
    cover_item_id uuid,
    item_count integer DEFAULT 0,
    is_smart_album boolean DEFAULT false,
    smart_criteria jsonb,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.albums OWNER TO vault;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(64) NOT NULL,
    key_prefix character varying(8) NOT NULL,
    scopes text[] DEFAULT ARRAY['read'::text],
    rate_limit integer DEFAULT 1000,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_keys OWNER TO vault;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id uuid,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO vault;

--
-- Name: collaborators; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.collaborators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    album_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    collaborator_id uuid,
    collaborator_email character varying(255),
    can_view boolean DEFAULT true,
    can_add boolean DEFAULT false,
    can_remove boolean DEFAULT false,
    can_edit boolean DEFAULT false,
    can_share boolean DEFAULT false,
    encrypted_album_key text,
    status character varying(20) DEFAULT 'pending'::character varying,
    invited_at timestamp with time zone DEFAULT now(),
    accepted_at timestamp with time zone,
    CONSTRAINT collaborator_has_identity CHECK (((collaborator_id IS NOT NULL) OR (collaborator_email IS NOT NULL)))
);


ALTER TABLE public.collaborators OWNER TO vault;

--
-- Name: data_exports; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.data_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    file_path text,
    file_size bigint,
    download_count integer DEFAULT 0,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    error_message text
);


ALTER TABLE public.data_exports OWNER TO vault;

--
-- Name: document_metadata; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.document_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    encrypted_summary text,
    encrypted_entities text,
    category character varying(100),
    encrypted_ocr_text text,
    document_date date,
    expiry_date date,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.document_metadata OWNER TO vault;

--
-- Name: embeddings; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.embeddings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    embedding_type character varying(50) NOT NULL,
    embedding public.vector(1024),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.embeddings OWNER TO vault;

--
-- Name: face_clusters; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.face_clusters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    encrypted_name text,
    relationship character varying(50),
    photo_count integer DEFAULT 0,
    centroid public.vector(512),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.face_clusters OWNER TO vault;

--
-- Name: faces; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.faces (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    cluster_id uuid,
    bbox_x double precision NOT NULL,
    bbox_y double precision NOT NULL,
    bbox_width double precision NOT NULL,
    bbox_height double precision NOT NULL,
    embedding public.vector(512),
    detection_confidence double precision,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.faces OWNER TO vault;

--
-- Name: import_connections; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    access_token text,
    refresh_token text,
    token_expires_at timestamp with time zone,
    credentials jsonb,
    files_imported integer DEFAULT 0,
    bytes_imported bigint DEFAULT 0,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


ALTER TABLE public.import_connections OWNER TO vault;

--
-- Name: import_history; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    source_id text NOT NULL,
    source_hash text,
    vault_item_id uuid,
    imported_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.import_history OWNER TO vault;

--
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    paths text[],
    include_shared boolean DEFAULT false,
    preserve_folders boolean DEFAULT true,
    delete_after_import boolean DEFAULT false,
    status character varying(20) DEFAULT 'pending'::character varying,
    total_files integer DEFAULT 0,
    imported_files integer DEFAULT 0,
    failed_files integer DEFAULT 0,
    total_bytes bigint DEFAULT 0,
    imported_bytes bigint DEFAULT 0,
    current_file text,
    errors text[] DEFAULT '{}'::text[],
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.import_jobs OWNER TO vault;

--
-- Name: item_places; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.item_places (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    cluster_id uuid,
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.item_places OWNER TO vault;

--
-- Name: item_versions; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.item_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    version_number integer NOT NULL,
    storage_key text NOT NULL,
    file_size bigint NOT NULL,
    encrypted_metadata text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    change_type character varying(50),
    change_note text
);


ALTER TABLE public.item_versions OWNER TO vault;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title text NOT NULL,
    message text,
    data jsonb,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO vault;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.password_reset_tokens OWNER TO vault;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON TABLE public.password_reset_tokens IS 'Stores password reset tokens with expiration';


--
-- Name: COLUMN password_reset_tokens.token; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.password_reset_tokens.token IS 'Secure random token sent via email';


--
-- Name: COLUMN password_reset_tokens.expires_at; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.password_reset_tokens.expires_at IS 'Token expiration (typically 1 hour)';


--
-- Name: place_clusters; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.place_clusters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    encrypted_name text,
    place_type character varying(50),
    latitude double precision,
    longitude double precision,
    radius_meters double precision DEFAULT 100,
    city character varying(100),
    country character varying(100),
    photo_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.place_clusters OWNER TO vault;

--
-- Name: processing_queue; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.processing_queue (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    task_type character varying(50) NOT NULL,
    priority integer DEFAULT 5,
    status character varying(50) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.processing_queue OWNER TO vault;

--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    key character varying(200) NOT NULL,
    requests integer DEFAULT 1,
    window_start timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rate_limits OWNER TO vault;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: vault
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limits_id_seq OWNER TO vault;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vault
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: share_links; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.share_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    share_token character varying(64) NOT NULL,
    item_id uuid,
    album_id uuid,
    encrypted_password text,
    expires_at timestamp with time zone,
    max_downloads integer,
    download_count integer DEFAULT 0,
    allow_download boolean DEFAULT true,
    allow_preview boolean DEFAULT true,
    encrypted_message text,
    created_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone,
    revoked_at timestamp with time zone,
    CONSTRAINT share_has_target CHECK (((item_id IS NOT NULL) OR (album_id IS NOT NULL)))
);


ALTER TABLE public.share_links OWNER TO vault;

--
-- Name: shares; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.shares (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    share_token character varying(100) NOT NULL,
    expires_at timestamp without time zone,
    max_views integer,
    view_count integer DEFAULT 0,
    burn_after_view boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed timestamp without time zone
);


ALTER TABLE public.shares OWNER TO vault;

--
-- Name: storage_access_log; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_access_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_name character varying(63),
    object_key text,
    operation character varying(20),
    status_code integer,
    bytes_transferred bigint,
    client_ip inet,
    user_agent text,
    request_id uuid,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_access_log OWNER TO vault;

--
-- Name: storage_buckets; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_buckets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(63) NOT NULL,
    owner_id uuid,
    quota_bytes bigint DEFAULT 0,
    used_bytes bigint DEFAULT 0,
    object_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.storage_buckets OWNER TO vault;

--
-- Name: storage_chunks; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_chunks (
    hash character varying(64) NOT NULL,
    size bigint NOT NULL,
    ref_count integer DEFAULT 1,
    compressed boolean DEFAULT false,
    stored_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_chunks OWNER TO vault;

--
-- Name: storage_multipart_parts; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_multipart_parts (
    upload_id uuid NOT NULL,
    part_number integer NOT NULL,
    chunk_hash character varying(64) NOT NULL,
    size bigint NOT NULL,
    etag character varying(64),
    uploaded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_multipart_parts OWNER TO vault;

--
-- Name: storage_multipart_uploads; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_multipart_uploads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    key text NOT NULL,
    content_type character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '24:00:00'::interval)
);


ALTER TABLE public.storage_multipart_uploads OWNER TO vault;

--
-- Name: storage_object_chunks; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_object_chunks (
    object_id uuid NOT NULL,
    chunk_hash character varying(64) NOT NULL,
    chunk_index integer NOT NULL,
    chunk_offset bigint NOT NULL,
    chunk_size bigint NOT NULL
);


ALTER TABLE public.storage_object_chunks OWNER TO vault;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    key text NOT NULL,
    version integer DEFAULT 1,
    size bigint NOT NULL,
    content_type character varying(255),
    etag character varying(64),
    metadata jsonb DEFAULT '{}'::jsonb,
    is_current boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.storage_objects OWNER TO vault;

--
-- Name: storage_quotas; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_quotas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_name character varying(50) DEFAULT 'free'::character varying,
    quota_bytes bigint DEFAULT '5368709120'::bigint,
    used_bytes bigint DEFAULT 0,
    file_count integer DEFAULT 0,
    max_file_size bigint DEFAULT 104857600,
    max_versions_per_file integer DEFAULT 10,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_quotas OWNER TO vault;

--
-- Name: sync_tokens; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.sync_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    device_name character varying(255),
    device_public_key text NOT NULL,
    last_sync_version bigint DEFAULT 0,
    last_sync_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sync_tokens OWNER TO vault;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    device_name character varying(100),
    device_type character varying(50),
    ip_address inet,
    user_agent text,
    last_active_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


ALTER TABLE public.user_sessions OWNER TO vault;

--
-- Name: users; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    auth_hash character varying(255) NOT NULL,
    salt character varying(255) NOT NULL,
    encrypted_master_key text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_login timestamp without time zone,
    storage_quota_bytes bigint DEFAULT '10737418240'::bigint,
    storage_used_bytes bigint DEFAULT 0,
    email_verified_at timestamp with time zone,
    display_name character varying(100),
    language character varying(10) DEFAULT 'de'::character varying,
    timezone character varying(50) DEFAULT 'Europe/Berlin'::character varying,
    deletion_requested_at timestamp with time zone,
    deletion_scheduled_at timestamp with time zone,
    deletion_reason text,
    login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    totp_secret text,
    totp_enabled_at timestamp with time zone,
    recovery_codes text,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    subscription_status character varying(50) DEFAULT 'free'::character varying,
    subscription_ends_at timestamp with time zone,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    email_verification_expires_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO vault;

--
-- Name: COLUMN users.email_verified; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.users.email_verified IS 'Whether user has verified their email address';


--
-- Name: COLUMN users.email_verification_token; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.users.email_verification_token IS 'Token for email verification';


--
-- Name: vault_content; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.vault_content (
    id integer NOT NULL,
    storage_key text NOT NULL,
    user_id text NOT NULL,
    encrypted_content bytea NOT NULL,
    original_size integer NOT NULL,
    encrypted_size integer NOT NULL,
    checksum text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    accessed_at timestamp without time zone
);


ALTER TABLE public.vault_content OWNER TO vault;

--
-- Name: vault_content_id_seq; Type: SEQUENCE; Schema: public; Owner: vault
--

CREATE SEQUENCE public.vault_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vault_content_id_seq OWNER TO vault;

--
-- Name: vault_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vault
--

ALTER SEQUENCE public.vault_content_id_seq OWNED BY public.vault_content.id;


--
-- Name: vault_items; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.vault_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    item_type character varying(50) NOT NULL,
    encrypted_metadata text,
    storage_key character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    captured_at timestamp without time zone,
    deleted_at timestamp without time zone,
    sync_version bigint DEFAULT 1,
    device_id character varying(100),
    processing_status character varying(50) DEFAULT 'pending'::character varying,
    processed_at timestamp without time zone,
    current_version integer DEFAULT 1,
    source_provider character varying(50),
    source_path text
);


ALTER TABLE public.vault_items OWNER TO vault;

--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: vault_content id; Type: DEFAULT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content ALTER COLUMN id SET DEFAULT nextval('public.vault_content_id_seq'::regclass);


--
-- Data for Name: album_items; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.album_items (id, album_id, item_id, sort_order, added_at) FROM stdin;
\.


--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.albums (id, user_id, parent_id, encrypted_name, encrypted_description, cover_item_id, item_count, is_smart_album, smart_criteria, sort_order, created_at, updated_at, deleted_at) FROM stdin;
adc5b95b-bf2b-4685-8040-4f1f5b5b8ede	94ff25b3-0399-477f-b460-0dcda844f143	\N	Test Album 2026	Testing albums API	\N	0	f	\N	0	2026-02-03 01:55:51.911292+00	2026-02-03 01:55:51.911292+00	\N
a25191c0-077f-4276-b16e-4baec7dc8477	53e3e0f5-7b76-40e5-97da-36b44892adeb	\N	encrypted-test-album	\N	\N	0	f	\N	0	2026-02-03 22:29:58.827145+00	2026-02-03 22:29:58.827145+00	\N
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.api_keys (id, user_id, name, key_hash, key_prefix, scopes, rate_limit, last_used_at, expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.audit_log (id, user_id, action, resource_type, resource_id, ip_address, user_agent, created_at) FROM stdin;
18d45fb7-6233-43a5-8e4e-da729a521073	\N	migration	database	\N	\N	\N	2026-02-03 02:38:09.647678
5c7821da-a294-454a-85bb-853816863bc1	f56b2c90-8e7b-4914-9ca1-63ee7317f134	account.deletion_requested	user	\N	\N	\N	2026-02-03 22:31:34.653171
1b121b5e-f6f1-48f1-8e4e-9b2f0281c160	f56b2c90-8e7b-4914-9ca1-63ee7317f134	account.deletion_cancelled	user	\N	\N	\N	2026-02-03 22:31:34.777955
\.


--
-- Data for Name: collaborators; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.collaborators (id, album_id, owner_id, collaborator_id, collaborator_email, can_view, can_add, can_remove, can_edit, can_share, encrypted_album_key, status, invited_at, accepted_at) FROM stdin;
\.


--
-- Data for Name: data_exports; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.data_exports (id, user_id, status, file_path, file_size, download_count, expires_at, created_at, completed_at, error_message) FROM stdin;
\.


--
-- Data for Name: document_metadata; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.document_metadata (id, item_id, user_id, encrypted_summary, encrypted_entities, category, encrypted_ocr_text, document_date, expiry_date, created_at) FROM stdin;
\.


--
-- Data for Name: embeddings; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.embeddings (id, item_id, user_id, embedding_type, embedding, created_at) FROM stdin;
f0e8fdd0-40e7-4d5c-bfae-9c62f1a702b1	0c0920ff-5e11-4ace-886c-0f4228749ec4	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.48425233,0.1366914,-2.1691165,0.026320294,-0.007706493,0.034315903,0.121488854,1.6758682,1.5195653,0.51615316,0.73586506,-0.27801868,0.3575487,0.6240834,0.3485778,0.37215197,0.28965527,-1.3738203,-0.0003645718,-0.04249079,-1.224931,0.5236192,0.16119331,-0.36243525,-0.94864935,-0.25607112,-0.37345874,-0.9019872,0.24258837,0.63954675,0.10746591,-0.4892327,-0.16681282,0.6260707,0.44024742,-0.87209433,-1.5767766,-1.0174228,-1.0044765,-0.21259645,-0.017775904,-0.079450145,1.0291739,-0.94910717,-0.36053276,-0.9241348,-0.8912537,-0.26161644,-1.3818332,-0.8202432,-0.22858867,0.9379001,1.2611691,-0.43246305,-0.27115077,0.09408166,0.65211266,0.062201455,-1.4792832,0.1614813,-0.8781546,1.6241629,-0.009624956,-0.538231,-0.0076497984,1.8442695,0.46339706,1.4849027,-0.55763286,-1.6005595,0.37334007,-0.057689432,-0.752531,-0.44788608,-1.4873782,0.44232342,-1.1488498,0.3876667,-0.6476853,0.8458736,0.19444102,0.87408847,-0.58533597,0.407263,0.95646024,0.69899124,-0.6429637,1.6231773,0.04046163,-0.43259078,-0.6609831,-0.099980496,0.952242,-0.5569875,-0.9057486,-0.042813063,-1.2260516,-0.14602426,0.33471406,0.017562497,-0.14862886,0.22055498,0.31724787,-0.55937517,-0.15171963,-0.21029301,0.4934067,2.0194526,0.22607481,-0.28765985,1.1889598,0.72115564,0.20634927,0.07571144,-0.0637115,-0.03707715,-0.102722794,-0.9528814,0.20822331,0.46158373,-0.67233723,0.33953393,0.38613266,-0.40245765,-0.6663453,-0.5875627,-0.42424738,0.48052412,-0.47293702,-0.44495484,-0.13755977,-0.51039565,0.11649795,-1.0374593,-0.1688615,-0.35403323,0.4033046,0.75358135,-0.41057318,0.2668143,0.97867656,0.99981284,-0.100124516,-1.5160384,1.7978392,-1.3468075,-0.355603,-0.8168412,0.19754194,-0.54800075,-1.173567,-0.6200962,0.3308932,-0.6418397,-0.9169362,-0.47046396,-0.476783,1.1918069,-1.1536629,-0.17113219,0.792928,0.28249517,-1.0874317,0.32805178,0.98139465,-0.735722,0.75888705,1.2920356,-0.5128987,-0.8728245,0.22726369,-1.5106037,0.74804336,0.021800615,0.9357662,0.05807513,1.5733252,0.13557757,0.4999377,-0.41273022,-1.8287402,-0.7041507,0.24040565,-0.87131244,-0.11036631,0.5409166,-1.2129757,0.1992414,-0.048739776,-1.2186041,-0.8073021,-0.32802898,-0.1886833,-0.9748998,0.5436378,-0.5583083,0.51379263,-1.2397022,0.64354295,-1.6449504,-0.35542265,1.504291,-0.524035,-0.37306324,0.44120276,0.17396414,-1.3624635,0.030777384,0.7735725,-1.1054561,-0.55685455,0.56370574,-0.010749798,-1.0280868,-1.0637792,0.5230468,1.4965725,0.84549475,0.056653723,1.2814136,0.4339258,-0.54718065,0.48386022,-0.17367859,0.56649,0.5239273,0.6176372,1.249517,-0.5206257,-0.7011036,-0.14085513,1.4598869,-0.3208912,-0.22944012,0.26360044,0.09022947,-0.337575,0.4079126,0.7976126,-0.81404525,0.14580378,1.4733025,-0.98281854,-0.17566219,-0.44863632,0.24369487,0.4357683,-0.10872719,0.14499636,-0.24145919,0.7667924,-0.2053574,-0.5692193,0.7045175,0.45329607,0.72423387,0.8174319,0.4955982,-0.019993871,0.67381793,0.21632457,-1.1993057,1.399957,0.93791497,0.5761276,-0.43941936,0.7352011,-0.14771746,0.38296375,1.2734504,0.12572908,0.38655403,0.46517223,0.26377946,1.4047343,1.8855207,0.3953276,-0.53723663,0.25280786,-0.6183214,1.258073,-1.7387085,0.015986554,0.45017853,0.29393756,-0.16976508,-0.124342084,1.8135164,0.7675196,-0.35255215,1.0634587,0.07999071,0.49865913,0.3205367,-0.15007387,-0.0416286,-0.090589754,-3.6008058,-0.46604806,0.24961683,0.009547826,0.45994,-0.87656283,-1.1222651,-2.2309334,-0.26988757,0.25659552,-0.12211246,-0.6761111,-0.7097209,-0.33398977,0.7055037,0.50913405,-0.10860522,0.18216154,0.05084247,-0.73576623,-0.19304231,-0.046159886,2.7474248,-1.050107,-0.6503102,-0.007546778,-0.34010622,-0.9209926,-0.61802584,-0.66828746,0.037875358,-0.16010186,-0.41538057,-0.12775432,-0.7098511,0.029281525,0.20015994,-1.0217386,-0.43230602,0.4000479,-0.7086741,1.1548967,-0.6661579,1.2050059,0.14435248,-0.54889446,-0.77590436,0.55752367,-0.026615022,-1.3977714,0.15845387,0.8819352,-1.5093397,-0.06531624,-1.7738667,1.0545908,0.44821084,1.0174437,-0.6090036,-0.16473652,-0.13419828,-1.2768067,0.64001197,-0.7019301,-0.8095229,-0.56808096,0.63752806,0.21247695,-0.06092027,-1.0771223,1.9298929,-0.95246285,0.26126575,0.7088794,1.7675272,1.5322146,-0.34546477,-0.5490669,0.10506208,-2.2401674,-0.1804891,-0.042987537,0.6101311,0.4152471,0.046925828,-0.34638444,0.30138198,-1.0122654,1.9245578,5.6414113,1.3389698,0.595343,-1.68254,2.2223651,-0.46297148,0.34946954,-0.20557219,-0.17935514,-0.87766385,-0.9169979,0.86127985,-0.8469384,0.7603221,-0.89649695,1.5058898,-1.429895,-0.21118744,0.9732975,-0.89709574,-0.5226765,-1.0346168,0.35669658,-0.29288116,-1.5524205,0.06550956,0.07769133,1.280092,0.45097122,-1.0221183,-2.1546242,0.47021312,0.77217317,-0.9215797,1.0164814,0.04585012,-0.6914537,0.23357211,0.14826867,1.4897566,0.32881486,-0.5941241,0.19706841,-0.15696111,-1.0391157,0.1832901,0.7652125,0.41634026,-0.9432509,0.4192229,-0.35843688,-0.89263546,-0.5477704,-0.10186563,0.38396332,-0.55491555,-0.5027807,-0.90618956,0.47877425,0.97989273,0.4880885,0.05048101,-0.13682511,-0.10315816,0.31071454,-0.699149,-0.08886906,-0.86585563,-0.4930595,-0.40805903,0.76153064,0.076876186,0.5725169,0.7510337,0.5075496,1.0248762,0.92101455,1.0560342,0.8306714,-0.39111882,-0.7104289,-0.38169456,0.24020465,1.0382981,0.8839948,0.33867836,-0.22934024,1.0968262,2.4946735,-0.8692493,0.5073405,0.403697,-0.5728652,0.092442065,0.22295779,-0.9965017,-0.110819235,-1.0465641,-0.028688699,0.14542368,-0.04464764,0.1800416,-0.09669239,-1.543149,0.98957,0.9211486,-1.3943275,-0.16559781,1.078864,1.1368614,-0.88903314,-0.3750281,0.0027744323,-0.37746248,0.5468988,0.16930827,0.47440833,0.51982605,-0.5153574,0.07271432,1.0641083,0.7465271,-0.4459338,0.6045054,0.2022532,-1.8688469,1.186667,-0.2987747,-0.65002745,0.97076476,-0.43739405,-0.87596494,-1.7328742,0.8846376,1.9191211,-0.047330238,1.0627633,-0.023355464,-0.40521723,0.47362053,-0.19556114,0.54324126,0.64365846,0.8625777,-0.058115795,0.94166,-1.4429466,1.3947746,-0.38309512,-0.6875525,1.3257812,0.30459416,-0.07041396,-1.3729036,-1.1232095,-0.33994037,-0.8739744,-0.7440956,1.2532741,0.04536137,1.0484953,0.0809845,0.1421678,1.4678377,0.93102145,1.6396909,-0.18810715,0.6873195,-1.5080777,-0.55071574,0.11328621,0.5152999,0.28662062,1.6012747,-0.36393648,-1.3983623,0.54864645,1.0817418,-0.17633693,-0.32608908,-0.061028477,0.021563563,-0.47228697,-0.6849606,0.510936,0.80520594,0.102908015,-0.0041471794,0.6652505,-0.98002684,-0.18621588,1.8507584,-1.0088384,-0.34121102,0.79629636,0.6974421,1.5399145,1.526122,0.13808212,-1.1154945,-0.39103627,-0.690676,-0.672747,-0.95617473,-1.0872151,-1.6260827,0.5410092,0.40780944,-0.8663534,-0.08713929,-0.96695197,0.035492208,-1.1676383,0.07071878,-0.66415304,-0.556534,-0.49875355,1.8348738,0.0859092,-0.76460385,-0.008118467,-0.26124746,-0.19369468,-0.40254897,-1.2453595,-0.15228462,0.8004049,-0.04623138,-2.05055,-0.109836146,-0.24024713,-0.22608511,-0.0011088531,0.155144,1.1068342,-0.57698965,-0.8450696,0.28398538,0.31521747,0.2206631,-0.0963121,-0.73516476,1.303947,0.6965918,-0.55727863,0.19561267,-1.2195337,-0.6632159,-0.016184557,0.2523705,-0.15543993,0.013363995,0.22736035,-2.021519,-0.23840858,0.31153587,0.56709015,0.20955372,0.098516226,-0.7497202,-0.053199396,1.4428053,0.56605035,0.40016425,-0.14014986,-1.40191,0.10404311,-0.7037904,-0.37807146,-0.43793702,-0.46422306,0.5931525,-0.6503645,-0.9152336,0.63624644,-0.32915118,-0.39858773,0.8115832,-0.21568288,0.7207144,-1.4090554,0.55032444,-0.5767387,0.96518993,-0.38698584,-0.47440892,-0.9034491,-0.17546879,-0.07505144,-0.24465947,-0.13436456,-0.7336469,-0.2953909,0.9686278,0.019110195,0.2082645,0.08885666,-0.51366615,-0.42380056,-0.12435739,-0.472594,-0.14814803,-0.20056531,0.08090876,0.016619215,-0.946818,0.23795158,0.24742287,0.74144113,-0.6158368,0.66128063,-1.3204998,-0.27358872,0.13387665,0.19950749,-1.2214032,0.53892994,-0.80911374,-0.14683968,0.31412554,0.94456816,-0.46453688,-0.6066704,0.34312138,-0.8687125,1.103751,-0.8561592,0.48272443,0.27442822,1.69905,-0.3011804,-0.049452137,0.09461778,-0.018456478,0.36022234,-0.0056056734,1.1283901,0.21365717,2.1727355,0.04289769,0.8389174,2.3136828,0.9171393,-0.097560674,0.89330536,0.38933274,0.11072409,0.30941483,-0.27025008,-1.4155892,0.62542796,0.36030352,-0.96208143,-0.8523332,1.2853822,-0.28406447,-0.86926,-0.24457471,0.14296712,0.4544718,-1.230476,1.4334421,-0.6471461,0.31448746,-0.08844023,0.6114074,-0.8983946,-2.484952,1.907286,0.006222591,-0.19165908,-0.96138865,0.76491964,0.54159516,-1.3297547,0.82966435,-1.2661909,0.33918518,-0.2783327,0.37907472,-1.0824379,-1.0720615,-1.58604,-0.15281141,1.0110447,-0.45852757,-0.80018765,1.1286848,0.41578695,0.6765611,-1.1587884,-0.490166,-0.7376978,-0.47535214,-3.4263458,0.5295691,0.70422506,0.8489805,-0.54257774,0.7340778,-1.2359229,-0.5419759,-0.33266333,-0.32239503,0.3340413,0.22153838,0.32892084,-0.77358764,1.1954523,0.3421118,-0.14297518,-0.36038208,-0.36072314,2.5361378,0.5940476,-0.39380944,-0.12756726,-0.4107422,-0.16738951,-0.8104613,-0.09822263,0.39857143,-0.5908644,-0.4093737,-0.100850135,-0.988036,0.4470634,-1.3121332,-0.12146836,0.060770832,-0.17099172,0.55928224,0.83448,-0.15949036,0.26213434,0.75350636,-1.9646636,0.20364441,0.25224173,1.7819241,-1.2815968,-0.4269122,-0.532967,-0.12096074,0.02341286,-1.0773251,-0.17535721,0.64278257,0.29457617,0.6713054,1.0253167,-0.090418346,1.0893108,0.09305304,-0.19732879,-0.4404493,-1.3334699,-0.4446038,-0.30514616,0.26984546,-1.6955851,0.541008,0.4185505,0.5908333,-0.5413549,1.4884268,0.9869367,-1.1042309,0.8351527,0.52299815,-0.2921107,-0.50093055,-2.0810335,-1.3306023,0.6529512,-0.75119406,0.91226506,-0.27322876,0.23449247,0.48381525,-0.57243127,-1.4034249,-2.462653,0.03826256,-2.2745647,-0.29585004,-1.1393368,0.4164959,-0.94553536,0.8972505,-0.7099669,-0.5126935,0.37267962,-0.83131266,0.427338,-1.1296622,0.33870405,-0.4236463,-0.7444954,-0.22557722,0.29626793,-0.11192101,0.38855287,0.2870294,-0.73854643,-0.3767847,-0.4135464,0.17369096,-0.8174425,-0.24755076,-0.11809931,1.1512281,0.6284264,0.6841309,-0.1466839,-0.6702137,-0.12239975,-0.63325804,1.6524581,1.8925078,0.5061401,0.1493039,0.7061637,0.9788672,1.3301601,-1.5584799,0.05359769,-0.53593296,-0.26756725,-0.53776884,-0.76869994,0.20059443,-1.221553,-0.168508,0.11892721,-0.62323457,-0.9537823,-1.4396309,-1.0137174,0.014809795,-0.20696568,0.12496825,0.62949884,-0.40892443,0.07677766,-0.6446015,-0.19101967,0.080723375,-0.07628078,0.32698748,0.89329207,1.0336636,0.5143657,1.3804698,-0.7506802,1.3882326,-0.93879133,-0.2104099,-1.3091187,0.5941941,-0.25930664,-0.5238193,-0.088097624,-0.020233076,0.84867775,0.47380358,-0.43930608,-1.1391817,1.1672802,0.04105724,-0.30156386,0.6982951,0.09882817,0.3685647,0.8350376,0.72558355,-0.5700023,0.012744814,0.41548684,2.0754893,1.1254085,0.016950816,2.069048,-0.7438361,-0.43267676,-1.1935776,0.32158732,-0.39939302,0.9038141,0.4873679,-0.35396788,0.5987976,1.1493471,-0.066908084,1.1592876,-0.43009993,-0.28988558,-0.5793359,0.16779208,-0.7808212,-0.6277191,0.60331124,-0.24179566,1.3935415,0.13425916,-0.48679486,-0.25004637,0.25652805,1.1249993,0.84402674,-0.31464726,-1.2903018,0.070369646,1.3217973,0.41554168,-0.2638235,-0.7837992,-0.45562366,-0.087577984,-0.31349543,-2.2950845,-0.15443692,-0.1583491,1.0144591,-0.287299,-0.71432155,0.22154766,0.27558732,0.1671089,-0.45477143,0.34047127,0.5063783,-0.42213416,-0.44593197,1.3176849,-0.6344415,-0.28663242,0.27178425]	2026-02-01 11:25:09.660733
f1048e65-be19-4d03-825a-75e7920a501b	49833632-082e-43c9-8ba5-a6b32d1600fb	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.00031776653,-0.31513575,-2.5210328,0.17322583,-0.37988842,0.26890996,0.3320751,1.7918472,0.63027763,0.3700486,-0.15938808,-0.35017928,-0.0147852,0.10945436,0.14287508,-0.03182396,0.7350312,-0.12231444,0.20415863,0.42504895,-0.13622357,-0.2640621,-0.25504935,0.057880715,-1.453995,-0.3886011,-0.50865996,-0.9023285,0.03841993,0.9819243,0.23156264,0.083382435,0.19875263,0.6205983,0.49164236,-0.2522894,-1.0976851,-0.44160426,-1.211813,0.2309232,0.5908748,-0.06274554,0.8381497,-0.6499549,-0.1912571,-1.2989845,-0.1986683,-0.19265567,-1.7846141,-1.910313,0.5213035,0.572799,0.86692107,-0.0863211,-0.17189008,-0.50048274,1.1043953,-1.2843713,-1.7218833,-0.26670715,0.19563511,0.6909008,-0.09487068,-0.7590867,-0.25062722,1.7815903,0.25517854,0.8264157,-0.55411077,-1.2011601,0.71987176,-0.50406915,-0.3622115,-1.0524621,-0.8121503,-0.029099777,-1.0034158,-0.029759731,0.48385048,0.780119,0.7555435,0.692332,0.047655694,-0.21345992,0.09891468,0.83917165,-0.6267561,-0.22194523,0.9169377,-0.5738748,-0.3627849,0.64442,1.2581884,-0.85788244,-0.4939593,0.419363,-0.80843115,-0.86977935,-0.09549691,0.30990386,0.48484963,-0.01270027,0.010077661,-0.43410012,-0.95410615,-0.39306763,0.2910046,0.9577707,1.0641243,-0.18227264,1.7868819,-0.51518,0.6043222,0.42662057,0.23410992,0.0043171383,-0.15851441,-1.017242,-0.9491619,0.26888973,-1.5752141,0.5166759,0.9038616,0.085138276,0.15199193,-0.08000606,-0.09230542,0.51915514,-0.9901685,0.17652224,0.38947937,-0.3899643,-0.5169378,-0.058508437,0.22830579,-1.2160772,0.059526414,0.81213766,0.82069826,-0.56095636,1.0206681,0.22404674,-0.23359643,-1.3713536,1.5753098,-0.45121005,0.15931845,-1.1210978,-0.374899,-1.0199736,-0.5419628,-0.24558148,1.0848937,-0.31758532,0.046351552,0.022366665,-0.7973101,0.45722556,-1.5833261,-0.0799778,0.68084264,-0.6855227,-2.3296907,-0.052892417,0.16585346,-0.15877369,0.565154,1.2511623,-0.2841772,-0.3063026,0.02281899,-0.77287036,0.9400693,-0.21761817,1.1400238,0.42224774,1.0863146,0.27980548,0.40117088,-0.8675074,-1.1907345,-0.57328767,0.57808006,-1.1229273,-0.304364,0.34082898,-0.1579865,-0.7637618,-0.14886007,-0.17380635,-0.28583172,-0.14957699,-0.44312316,0.16316555,0.4669736,-0.728952,0.21467695,-1.173764,0.06490591,-0.7942734,0.19670793,1.0554314,-0.57814854,-0.7405948,0.48787856,-0.16851926,-1.5705491,-0.1536005,0.7569779,-2.0438416,0.54629093,1.0480422,0.72793084,-1.2144988,-1.3437415,0.9962312,-0.0007571569,-0.09989482,-0.86493814,1.0119778,0.12507735,-1.2076445,0.9514444,-0.6235774,0.42493862,0.8267624,0.7754381,0.7733444,-0.5486893,-1.3118007,0.055015743,1.6249063,-0.46545872,-0.96813023,0.80463296,-1.1096003,-0.23022202,-0.25052986,1.0494056,-0.37650192,0.5707115,0.12770955,0.121531814,0.47861513,0.021879755,0.84969825,-0.24729262,-0.5210419,-0.15790072,-0.7977296,0.8178613,-0.018442392,-0.122657925,0.75749326,-0.12232553,0.1928787,0.62477934,0.05752191,-0.61620355,0.19123706,-0.18535115,-0.84369695,0.9512746,0.87258697,0.4875931,-0.5290735,1.036256,-0.08617148,0.07628152,1.0604095,0.7812861,0.17972173,0.27503055,-0.42641178,1.224693,1.0821887,0.61371243,-0.758611,0.2412937,-0.8224301,-0.26510447,-1.8051643,0.72618884,0.66077775,0.28868112,0.15365526,0.052734308,2.1953762,0.7044003,-0.34904283,0.10599153,1.2720833,0.3858863,-0.015299199,0.5704728,0.53492785,-0.46531558,-3.7785072,-0.9183537,0.74931896,0.31619528,0.51011145,-0.78523684,-0.6781357,-0.9799943,-0.55876184,-0.49832726,0.33493665,-0.36410663,-0.20700134,0.31889793,1.300243,0.027775073,-0.6696562,-0.10881881,-0.23317568,-1.114208,-0.25383663,0.07135323,2.6462636,0.47760463,-0.7809564,1.3682542,-0.0060769804,-0.6581135,-0.61769164,-0.36677954,-0.5584022,0.04113681,-0.2148087,-0.030461889,-1.038969,0.7172422,0.49581033,-0.47180277,-0.06958256,-0.26572385,-0.005580008,1.01305,-0.6084242,0.9391296,-0.7299494,-0.7512033,0.27962968,0.7916131,-0.78069174,-1.4340334,-0.2845963,0.081289604,-0.9532452,-0.021471595,-1.588053,0.37420717,1.3113607,1.4480556,-0.68167895,0.34473827,-0.78524756,-2.9781961,0.98834014,-1.0199718,-0.4913088,-0.92725015,-0.14122212,0.21951914,-0.86356026,-0.21580085,1.4216824,-0.027157428,-0.472304,0.4872645,1.2549489,1.6888968,0.2656311,0.024344072,0.3919929,-2.3142924,0.86301273,-0.5128637,0.4401801,1.1231126,-0.43637362,-1.0644546,0.8039228,-0.48406437,1.7197541,5.532254,1.0724876,0.7308474,-0.7689749,1.4237934,-1.2631108,0.2839577,-0.07976675,0.17720154,-1.1967103,-0.7695572,0.34000343,-0.43616045,0.6083629,-1.6885316,0.7187438,-1.8386817,0.07967888,0.9892628,-0.015328666,-0.77931356,-0.3974435,0.094046794,-0.06531602,-1.7615544,0.094822064,0.20852797,1.627296,1.0617361,-0.08742021,-1.9277396,-0.33673242,0.8404798,-0.5309193,0.4457598,-0.042890046,-0.5218014,0.26744562,-0.9475937,1.6221778,0.34414014,0.21689856,0.15699095,-0.768502,0.08256948,-0.29935354,0.8797846,-0.1593401,-0.3750057,0.10426311,-0.65185255,-0.80305994,-0.53891724,0.24989617,0.112283364,-0.81828904,-0.8793078,-0.60325485,0.84031504,1.6825846,-0.1042168,0.8692645,-0.8892113,-1.261855,-0.3963621,-0.482168,-0.31966636,-1.6383151,0.09722746,0.26757652,0.92350507,0.30686718,0.055548027,0.98392993,0.009219795,1.1261351,0.20925938,0.57478595,0.8646159,0.16848676,-0.2202624,-0.27171573,0.08211496,0.868656,1.1617136,0.12913483,-0.39329663,1.1582818,1.9491608,-0.99942017,0.6689168,0.57079715,-0.58181983,-0.48017007,0.15984619,-0.64442134,0.09216319,-0.66249555,-0.009845053,0.38461143,-0.41777194,0.5309286,0.70086753,-1.7642975,0.47635385,-0.7266202,-1.2940029,0.6813969,0.94666964,0.5563274,-0.56133,-0.44319978,-0.33996034,1.0666378,0.9243742,0.86424387,0.087509006,1.3737533,0.09602849,0.118277,0.6026624,-0.837362,0.19045676,0.3796412,-0.50452876,-1.437464,-0.033518575,-0.1646592,0.326812,1.0555515,-0.922276,-0.4782205,-2.001682,1.0133686,1.3951598,0.154443,1.5696889,1.1273165,-0.55933994,0.72793525,-0.36229557,1.2290491,0.37231907,0.34831354,0.10793108,0.7215656,-1.6128159,0.61362964,-0.05143155,-1.4266986,0.81715846,0.42201295,0.40458328,-1.2713283,0.57724893,-0.8242495,-0.3433401,-0.6950003,0.093336925,-0.4318618,-0.14878613,-0.12049482,-1.3655874,1.0784692,0.37687415,1.3690593,-0.27746743,0.7145782,-1.1909425,-1.334212,0.18415795,0.27447325,-0.2521317,0.48785728,-0.33336368,-0.29512918,-0.06984593,-0.061489996,-0.49780083,-0.83487874,0.13038014,-0.22110552,-0.28336853,0.41612318,1.6933087,0.5546065,-0.22869398,-0.073462896,0.91250056,-1.1407303,0.5054107,2.118211,-0.62711626,-1.2903916,1.2580194,0.08310231,1.9864993,0.8017245,-0.34555045,-1.2086704,-0.21591304,-1.2225913,-0.9296422,-0.7355263,-0.27077448,-1.241887,0.5123471,0.82259595,0.06478361,-0.07271527,-0.79299587,0.1732448,0.18950711,-0.59450537,-1.2509205,-0.4983181,0.14763641,0.6096785,0.1291555,-1.2895055,0.31961358,-0.16198035,0.03978449,-0.12988111,-1.0775422,-0.092200145,-0.17961177,-0.42430633,-0.15209988,-0.38760436,-0.26406425,-0.55160326,0.07184189,0.42654267,1.0865176,-0.51609886,0.3948522,1.014027,-0.2878058,0.28883252,-1.2553586,0.19681993,1.4110334,0.23753542,-0.2705318,-0.1860008,-0.18611568,-0.8794462,0.18881254,0.16114886,-0.7593007,-0.41182545,1.1845795,-1.5194538,-0.6376107,-0.21390268,-0.17878035,0.83384806,-0.07311861,0.74698126,-0.37360883,1.7980697,0.493895,-0.024531683,-0.43082905,-1.4682183,0.265045,0.4690531,-0.34611732,-0.88968354,-1.2947658,0.2032808,-0.46135518,-1.6393945,-0.3844169,-0.31535318,0.41414422,1.2062652,-0.03773354,0.26786745,-0.35279563,1.5000157,0.23402935,1.5862545,-0.046028163,-0.8817955,-0.5872352,-0.39093837,-0.048825696,-0.21266177,0.61635995,-1.1263838,-0.24501492,0.40841302,-0.5749965,-0.19470921,-0.56458384,0.17004639,-0.6027349,-0.15179396,-0.47109205,-0.32296523,-0.17992774,-0.5364611,0.07153331,-1.3699282,1.03819,-0.6768716,-0.68236464,0.2868887,0.27999648,-0.888011,-0.10195143,-0.96434706,0.6400006,-0.5269154,0.6590246,0.0515095,0.27288684,0.5520768,0.12712708,0.42849028,-1.1493648,-0.15828492,-0.3682638,0.86762714,-0.18978198,-0.3515082,-0.92256117,0.5559012,-0.9891628,-0.47941676,0.11939609,-0.50515735,1.1935018,0.591536,0.54167,-0.07721837,1.0620066,-0.06841995,0.86566067,2.1090147,0.44347924,0.122017324,1.5701816,-0.3280261,0.34552506,0.38727525,0.6254733,-0.51640034,0.5186939,0.67255384,-1.3793631,-1.7357327,0.78730017,0.35889056,-0.680611,-0.16249049,0.2530944,-0.24248977,-1.6460449,0.52058065,0.20683274,-0.35273162,0.11486578,0.2790542,0.17215866,-2.1460264,0.813135,-0.63020486,0.0067241527,-0.87482756,0.5154316,-0.20071447,-1.4904742,0.6523059,-0.85713744,0.3017052,-0.49155545,0.44631833,-0.024435434,-0.2878471,-1.9498456,0.2475186,0.28806293,-0.3954236,-0.2576468,1.304846,-0.4836184,0.3553643,-1.6138741,0.39117894,-0.40719163,-0.9696539,-3.286129,0.42191294,0.284089,0.9597171,-0.7026476,0.5801474,-1.5373528,-0.7252294,-0.56935567,-0.5167322,-0.090713955,0.43128324,-0.08552063,-0.74055064,1.9886432,1.3432798,-0.6591415,-0.33237764,-0.50718915,2.1392934,-0.27908593,-0.48143992,-0.33708894,-0.5314295,-0.052097443,-0.2905882,-1.4267992,1.0264088,-0.6433464,-0.6676117,-1.0254123,-1.838087,0.7091269,-0.22498801,0.76452684,0.31405896,0.4342072,0.52091575,0.1141472,0.24408725,-0.99513054,0.7558222,-1.6188916,1.2170306,-0.23635699,2.1734624,-0.11898986,-1.002056,-1.2124221,0.20427294,-0.9144691,-0.2682055,-0.0007774718,1.6653168,0.27078852,1.4291667,0.5051886,0.50665605,0.24205878,0.1534452,-0.027615275,-0.6434972,-1.5867603,-1.5212111,-0.357346,0.32675785,-1.7408234,0.23982155,0.14066978,0.45724452,-0.21684404,1.2928728,1.0226063,0.04579906,0.59460413,0.72121406,1.2159519,-0.44992337,-1.230379,-0.07595651,0.21090314,-0.8289841,0.67694986,0.6986711,0.21814762,0.9994409,-0.2142487,-1.2130305,-1.7393116,-0.6025333,-0.54784924,-0.47470576,-0.22603823,0.6004407,-1.1476737,1.0550486,-1.1505086,-0.6910755,0.042283177,-0.9670736,0.3420991,-1.3950003,0.55920666,-0.6775373,-0.6294241,1.1656731,-0.21912694,0.06204375,1.1716555,1.3987228,-0.76920795,0.81588256,-0.73790056,0.59583336,-0.10286207,-0.618276,0.30930102,1.1442997,0.23062906,1.444999,0.006497046,0.50203115,0.6967849,-0.9247279,0.7573651,1.4923851,0.5397727,0.7912737,1.0031826,1.0417031,1.1282959,-1.331959,-0.79574496,-0.38610226,0.24966627,0.5018641,-0.4787254,0.49432164,-1.0022037,-1.119866,0.7500916,-1.6551918,-0.33489782,-1.0090516,-0.7865677,-0.2500627,0.23294467,0.024730975,-0.70375466,0.21272239,0.4712643,-1.1111059,0.3943007,1.1787897,-0.13531873,0.13416709,-0.15763393,0.48530257,0.34518605,1.4568111,-0.22963393,-0.041477237,-0.91614825,-0.18926232,-1.2745763,0.9831532,-0.032348007,-0.536337,-0.34700912,0.39705336,0.38269457,1.1029031,-0.4782505,-1.7794001,0.095755935,0.1340095,0.32903966,0.8811019,0.6187863,0.98846686,0.9965869,0.23376371,-0.95851433,0.7577702,-0.36941433,1.2937847,0.36422092,-0.4675804,2.1591291,-0.81513745,-0.65279543,-0.24773642,-0.8534194,-0.67137545,1.4014485,-0.1406636,-0.18001378,-0.40866646,-0.15278558,-0.012819573,0.9854909,0.18424307,0.0011416133,-0.050055135,0.622449,-0.82270926,-0.46118158,1.0635763,-0.21668641,0.6807112,0.49188805,-0.13435201,-0.31878427,0.8351762,0.1663271,0.92770976,0.22492754,-0.82714933,-0.5949519,1.1612519,0.27246648,0.36689714,-0.86809045,0.0067508593,-0.22482437,-0.36102936,-2.1854236,0.90370095,-0.28926188,1.3458493,-1.0440761,1.1344384,0.6833293,0.5690777,0.015507799,-0.23877473,0.014908899,0.40221116,-0.60925364,0.2803515,0.7226398,0.1370319,-0.23448282,-0.6298111]	2026-02-01 11:25:15.412697
37e46ebc-6d17-4c0a-af90-3a05a91e1068	78154705-8d87-493a-a684-618d5c73269e	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.40411842,-0.023157688,-2.0946157,0.015643839,-0.0116564855,0.8886937,0.06854039,1.5851291,0.5941983,0.6651665,-0.7140189,-0.51799214,-0.33550152,0.49321938,-0.1161597,-0.040461905,0.9702152,-1.0096619,0.15902139,-0.15635958,-0.2466715,0.8811149,-0.5760374,1.0559613,-1.2351174,0.2024485,-0.71792805,-0.5269549,0.87368804,1.1135381,-1.0858248,-1.1243587,0.5141195,-0.19214712,-0.29572558,-1.2732677,-0.14114955,0.21509463,-1.2912745,-0.62736833,0.4247696,0.17465784,1.5554516,-0.8477323,-0.28674302,-1.1985506,0.3896476,-0.57306904,-1.7700932,-0.34632042,-0.7630811,0.55294394,0.84163,-0.71706915,-0.8546273,0.6682921,0.46478763,-0.8144377,-2.5289953,-0.2763215,-0.9676277,0.9080564,0.4408097,-0.80242413,-0.053220354,1.1208763,0.5325614,0.81731117,0.16463178,-1.0895194,-0.23089431,-0.42871222,-1.1069329,-0.26555008,-0.8413254,-0.011105853,-1.4247103,-0.13799603,-0.05543661,2.2235222,0.51974165,0.33325198,-0.42752016,-0.7782287,0.112283826,0.18921183,-0.24413343,0.34752837,-0.18094191,-1.1203012,0.81984013,0.057386428,0.545231,-1.0255848,0.15477207,-0.23250544,-0.3907364,-0.18546039,0.091298446,0.86529404,0.09551318,0.77057076,0.25577736,-0.8312777,-0.23480333,0.45801222,0.70622563,0.29006714,0.6406115,0.29068327,0.61768794,-0.12957178,0.6477075,0.6917602,-0.15516971,-0.17318952,-0.55787635,-0.8028198,-0.31174234,0.053983945,-0.5828011,0.37218684,0.9994699,-0.1706512,0.062263697,-0.8404907,0.11530623,0.5295439,0.28461903,0.5400541,-0.050157614,-0.046328664,-0.17519952,-0.5402833,0.30106533,-1.0444541,0.6216113,1.1605046,1.5297472,-0.67555165,0.6374108,-0.18401822,-1.0798821,-1.4127469,1.2176604,0.058087703,-0.013172647,0.018745914,-1.2439626,-0.56004536,-0.40525037,-0.7251685,-0.24217159,-0.8992117,-0.0054847486,0.4293189,0.537939,0.62706655,-0.94242305,-0.16969755,0.036931254,-0.7981809,-0.48391983,0.14481875,0.7583615,-0.53187466,-0.10350074,0.887348,-0.50603056,-0.8739374,0.78855705,-0.45795786,1.2356269,0.3314994,1.3435202,0.28249776,1.892715,0.040242255,0.17220457,-0.59797126,-1.1565119,-0.13413593,-0.2792728,-0.87299913,-0.14317465,0.8370152,-0.82688004,-1.0612284,-0.06336815,-0.24751502,-0.8540177,-0.7646233,-0.21235189,-0.67645496,0.7687257,-1.136016,0.16975112,-0.9792904,0.5018906,-1.9626644,-0.73853403,-0.42278466,0.51540196,-0.14788932,-0.21267916,0.18096143,-1.0108685,-0.24653113,1.528709,-1.1411275,0.9474603,0.29249012,0.582555,-1.1702107,-0.27534717,0.59566265,0.56885904,0.10145143,0.8090968,0.5081693,0.14982693,-0.72638965,1.3099467,0.05392327,0.5711442,0.56964004,1.1398104,1.1765507,-0.4999997,-1.0646752,-0.16548072,2.1130004,0.11683348,-0.42605105,1.1665237,-0.803507,-0.72696835,-0.009460847,0.5084624,0.79243356,0.18640079,0.47651199,0.13891459,0.013228781,-0.55832535,0.029923324,0.054600373,-0.46974874,0.039783698,-0.5946656,0.73072135,-0.28298804,0.092927866,0.2555368,0.3493347,0.63927394,0.9039883,0.7241741,0.4501537,0.6272909,-0.09433688,-0.27293557,0.6836651,0.603464,0.84526634,-1.0188698,-0.052836683,0.17428681,0.09381304,0.74774635,0.47368413,-0.5100912,0.25721872,-0.26283547,1.1647006,1.3742305,0.42953613,-0.2020808,0.21297812,-0.48559397,0.033623405,-1.0884109,0.34128103,0.9269307,0.42506292,-0.19743954,-0.7834674,1.1516848,0.57975054,-1.0616758,-0.36124948,0.18767133,0.8560194,-0.6260628,0.24806276,0.13189507,-0.13233209,-4.1454816,-1.038291,0.6052521,-0.7738074,0.84200305,-0.8561083,-0.772605,-1.9063922,-0.42351627,-0.035091452,-0.534892,-0.7911355,-0.35525435,0.856261,0.17398733,1.2857587,0.040014513,0.37752843,0.2813263,-0.2879631,0.31160727,0.16551849,2.987892,-0.8453961,-0.8850638,0.6503166,-0.81673175,-1.1590492,-0.8996723,0.055414647,-1.2947294,-0.37153053,-0.44179472,0.0963746,-0.5857412,0.31819224,0.30480176,-0.8026335,-0.15321842,0.26549745,-0.16727242,1.526046,-0.99390423,1.1653117,-0.8587428,-0.92550206,0.18887404,0.14071347,-0.92788565,0.16059966,-1.1226214,0.12427439,-0.9138251,-0.12591991,-1.6768847,0.7054383,-0.058226425,0.26158673,-0.94861555,0.52810174,-0.62043595,-1.0881343,-0.06894744,0.11376454,-0.29128256,-1.4724122,0.89693683,-0.19398522,-0.27413994,-0.3398062,1.6192999,-1.0769259,0.07266628,0.33392346,1.367748,0.8424572,0.128254,-0.9921819,0.3232518,-1.6940644,0.2924951,-0.41971296,0.41276997,0.10923956,-0.27293283,-0.8187227,0.6094001,-1.2301381,1.3974731,5.603159,1.6082916,0.29910457,-1.0386972,0.48244584,-0.7381042,0.053073965,-0.5868633,-0.11102176,-1.145271,-0.8956871,0.6301745,-0.13950105,0.9287607,-0.8884033,0.39869174,-1.5176558,0.15275173,0.89083016,0.6578141,-0.63776106,-1.137303,0.6624871,1.0533433,-1.4326829,-0.08194584,0.23173714,1.125254,0.10046786,0.40674162,-2.084908,-0.40111247,1.29628,-0.8639899,0.9790429,0.42325574,-0.53116107,-1.1634613,-0.4832795,1.3052104,0.20117894,-0.018170126,0.76725113,-0.56103146,-0.068463005,-0.254171,0.82975906,-0.53601307,-0.26087943,-0.10741402,-0.53226507,-0.3497512,0.14545736,-0.29524207,0.72330064,-0.84001607,-0.8264315,-0.30992952,-0.27124304,0.95446277,-0.17947064,0.33691487,-1.6453336,-0.6945857,0.1474365,-0.032285485,-0.2269744,-2.1105626,0.67427814,-0.3537836,1.0748106,0.4826158,-0.0669203,0.8566672,-0.2106841,1.0873584,0.759928,0.60227555,0.9398158,1.0457209,-0.59142864,-0.686319,-0.27669555,0.87962997,0.493205,0.46658057,0.45146996,0.48926693,2.1106968,-0.3659759,0.45744443,0.09937972,-0.9715732,-0.09425002,-0.40343517,-0.8404985,1.0906346,0.0006526485,-0.83191645,-0.23149975,-0.4525721,0.37401703,0.84609777,-1.6733844,0.4900025,0.044282272,-1.1238805,0.27269703,0.8687521,0.77129906,-0.8642444,-0.4127384,-0.9387321,0.22130606,1.1719089,0.632911,0.15355489,0.99344134,0.2567021,0.40073347,-0.26014662,0.663024,0.27327648,0.6655323,0.45034033,-1.2850089,0.31616503,-0.74968594,-0.21928638,0.83231276,-0.0906854,-0.6547668,-2.58885,1.2712125,1.8495743,0.26476493,1.9040794,0.043899536,-0.27566344,-0.24277766,-0.5723474,0.5029441,0.034594394,0.76189476,-0.16585538,1.3783858,-1.1500195,0.19953595,-0.33446553,-0.45243022,0.7883639,-0.42121446,0.26667812,-1.6797051,-1.041328,-0.7831765,-0.9821379,-1.0076879,0.24490118,0.3401967,-0.20844822,-0.32231462,-0.10545477,0.893968,0.76393193,1.3378543,-0.97732884,1.0079241,-0.33474424,-0.37512025,-0.1988833,-0.49359423,-0.32418817,1.1217029,0.011642054,0.08181009,-0.71091926,0.0323904,-0.26684642,-0.567565,0.27210408,-0.046669945,-0.14272234,0.50395626,0.7660232,-0.10204804,-0.06202948,-0.32178208,-0.047832727,-0.61544585,-0.148211,2.7253947,-1.0855784,-0.63511133,1.5074399,-0.44318742,1.44653,0.5604265,0.59813565,-1.6965612,-0.17524038,-0.7713442,-0.33306053,-0.813215,-0.7982724,-0.760522,0.38048726,-0.08782935,-0.3587833,0.06357839,-0.08441392,0.03993261,-0.83446616,0.17287849,-1.2076669,-0.52287877,1.010993,0.2630765,0.6339739,-1.3617413,0.6251677,0.14492571,-0.14809637,-1.1279795,-0.6221466,-0.48271525,0.40588486,-0.2630006,-0.17880736,0.21667968,-0.13958335,-1.0785141,-0.454629,0.6632341,1.0899144,0.26057926,0.014066968,0.1962571,-0.21802458,0.33716637,-0.7552984,0.24019155,1.0813652,0.5382598,0.040617727,-0.6958951,-1.3050121,-1.0673689,-0.13990879,0.88883436,0.16572402,0.46373725,0.4674294,-1.6683786,-0.23307142,0.4278721,0.65699255,-0.019972593,-0.9332208,-0.76026464,-0.26219842,1.8881439,0.34197903,0.34172806,-0.4336199,-1.8503888,0.34676233,-0.29682153,-0.6338637,-0.20404626,0.3440336,0.3526407,-0.07222612,-2.2089417,-1.8212457,0.58921313,0.2742752,0.9249745,0.18980421,-0.60333943,-0.61834663,1.2261703,-0.13902009,0.62263274,0.090191565,-0.9508983,-0.983918,0.29657024,0.13393788,-1.1335317,0.8710058,-1.102009,0.27118346,0.83385825,-0.54122144,-0.4714645,0.61868644,1.8806627,-0.5625169,0.011904243,-0.24198735,0.004158631,0.036090486,-0.66876364,0.030554865,-0.26540968,0.26596934,-0.135147,0.54263186,0.50962996,-0.7058008,0.30170423,-0.28974953,-1.9427924,0.38112658,-0.086266994,-0.59062165,-0.6197988,-0.27318162,-0.5055362,1.2828455,0.0776843,0.16503331,0.9957713,-0.35386267,0.101283945,-0.30194184,-0.2993133,0.36130252,-0.017391521,-0.033534627,-1.3604631,-0.16945846,-1.3220333,0.26630116,0.12827066,0.21314201,-0.65982646,1.3608179,0.27889478,0.33930174,1.9355507,0.6510142,-0.27564636,0.9363929,0.3191433,-0.17075469,0.4465588,0.24423939,-0.011357622,-0.111072175,0.44742125,-1.0884038,-1.1395047,-0.7587229,-0.39198026,-0.5144857,-0.25154945,0.5653698,-0.054074474,-0.81556594,1.2895182,-0.071216024,0.023800265,-0.019944761,0.36488482,-0.05086475,-1.6593624,0.16606428,-0.036868613,-0.14316168,-0.36035308,0.43782797,-0.98219466,-1.4385391,0.91509837,-1.3897817,0.8757046,-0.1819223,1.6818106,-1.1781188,-0.31645358,-1.3255281,0.2027885,-0.433997,-0.4646222,0.096149996,0.36546847,0.039538436,0.5158511,-0.45353374,0.9503443,-0.64401233,0.18797198,-3.5310438,0.49351826,0.07628953,1.1383393,-0.5602633,1.1105719,-1.0395695,-0.6968419,0.0060567968,-0.99448794,0.1988231,-0.45308736,0.31161815,-0.5282805,1.1748059,0.41481432,-0.057711743,-0.47597712,-0.30460367,1.33375,0.21366206,0.23216459,-1.2459949,-0.4121457,0.4513083,-0.51617956,-1.8104287,0.21971026,-0.68648946,-0.43281305,-0.70316696,-1.950659,-0.241055,0.8402419,0.8639756,0.5278743,-0.22956604,-0.14106536,0.41085154,0.39120322,0.9329871,0.44525495,-1.1974384,0.27217996,-0.65711695,1.7098049,-1.2358055,-0.46402925,-0.30866867,-0.6493576,0.27391243,0.8182917,0.15435779,1.4504116,0.2363056,1.0504249,0.60988647,0.2561469,0.27465522,-0.7054982,0.40399107,-0.3657512,-0.88337225,-1.3534638,0.6669644,0.30372787,-1.6097585,1.2804571,-0.64071363,-0.18425609,0.6222752,1.2681831,1.4502512,-0.17846563,0.21581122,0.7904579,1.2497671,-0.3296639,-0.59595954,-0.45059186,-0.48710784,-0.4136827,1.2910478,0.37143776,-0.72062117,0.8466498,-0.6098253,-1.2357843,-1.5322964,-0.4993591,-1.4465752,-0.17200272,-0.047528632,0.7659727,-1.026644,0.025740847,-0.424059,0.28106982,0.45225883,-0.28040165,-0.23545305,-1.8310069,0.2706297,-0.55007035,-1.0563855,0.9479273,-1.0387044,-0.29515165,1.1472714,-0.10799151,-0.32322437,1.9116241,-1.638145,0.6859336,-0.1000221,-0.15461531,0.24067399,0.88545376,0.084855214,1.001093,-0.04596233,-0.86087394,0.6679083,-0.7999286,1.0579528,1.3620037,1.4138578,1.5291215,0.48199952,0.534371,1.2290801,-1.2966275,-0.3063499,0.13542725,-0.039975878,0.60926634,0.5493781,0.20797354,-1.1539767,-0.06497763,0.05365406,-1.2329125,0.012513701,-1.0441343,-0.7329068,-0.7483614,-0.0067774924,-0.1472224,-0.22579215,-0.53382885,-0.13010846,-0.1880705,0.98124677,0.05692088,0.75677705,0.23210305,0.41952652,0.8182085,-0.03900744,0.5050409,-1.2743785,-0.8794362,-1.1557249,-0.7074045,-1.3398495,1.7274773,0.37313077,-0.76240706,1.1249841,0.8480042,-0.2174326,0.687788,-0.7108162,-0.59095913,0.5251711,1.0661567,0.3896991,1.7202348,0.15833682,0.46196485,1.1010292,0.8753047,0.23408137,0.739814,0.13829306,2.2341404,0.09056717,-0.236094,1.7142195,-1.2122266,-0.0021380223,-0.9052431,0.009393681,-0.39522022,1.250801,-0.25897896,-0.14295724,0.19687036,-0.2155792,0.38773465,1.1281332,0.118279144,-0.040780522,0.023210503,0.35427105,-0.96973157,0.13339159,0.5852391,0.13433985,0.47100246,0.80716634,-0.32237133,-0.07896135,0.9663881,0.439098,0.63080186,-0.30040008,-0.19026142,-0.39600408,0.37293327,0.71721613,0.54152364,-0.93921554,0.5818681,-0.74594545,-0.067872405,-0.89645976,-0.38815528,-0.9591834,0.99861574,-0.54077345,-0.119693816,0.51552385,0.67037505,-0.5962911,0.41759625,0.54891557,0.3289828,-0.30283412,-0.14221081,1.3744459,0.0732543,-0.6537117,-0.5770573]	2026-02-01 11:25:20.886581
3eadb282-1f10-48e9-9f5c-08e2dd5103b5	d3d05a46-f61b-4bf5-97ff-f0f96114a21b	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-1.4858118,-0.20968184,-1.3560781,0.09967236,-0.29105908,-0.14999527,0.6745924,1.3565099,0.86508983,0.5544928,0.009984497,-0.31604117,0.2868598,0.057512313,0.6057884,0.83676535,0.53246003,-0.77816963,0.07584202,-0.5094776,-0.5213989,0.13936359,-0.34002322,0.003363533,-1.0553591,0.98596185,-0.06888419,-0.879413,-0.85337716,0.8165714,-0.3535575,-0.25226253,1.1181214,-0.32664227,0.37460595,-0.44391254,-0.74587345,0.021436565,-1.2681446,-0.042082876,-0.18816787,-0.6938973,0.90155566,-0.1186288,0.14552267,-0.52333283,-0.20273452,-0.8009504,-1.2336167,-1.370364,-0.7680049,-0.06534616,0.83920413,0.101325996,0.32213554,0.62166977,0.9310538,-0.7514023,-1.8001367,-0.08596734,-0.44702584,1.1468949,0.1288428,-0.6995037,-0.23868021,1.3992903,-0.03966725,0.5254856,-0.30558404,-1.1291837,0.54554296,0.35904524,-0.13706234,-0.616687,-0.8889152,0.060088158,-0.3899492,1.1835145,-0.33881363,2.049655,0.6656178,0.07347432,0.10010505,0.4024201,-0.36397114,0.6858823,-0.81659937,1.8604225,0.2965741,-1.253106,-0.35992628,0.020450711,0.25445476,-0.81242263,-1.1258456,0.21684617,-0.43131384,-0.60819656,-0.04029406,0.49899212,-0.09123872,-0.5318421,0.097864725,-1.0415304,0.14723404,-0.21479213,1.1420752,1.5130832,0.82333666,-0.31177023,1.5406091,1.0734363,1.3520763,0.3143175,-0.5266862,0.4624802,-0.5959024,-1.3822381,-0.5290388,0.37102717,-1.017021,0.46494192,0.9084704,0.21559028,-0.7251636,-0.5532461,-0.017979244,0.048442103,-0.42886832,-0.13100764,0.40829593,-0.5059612,0.30199066,-0.18973087,-0.19514102,-0.4301825,0.31669542,0.5316042,1.1870345,-0.14699447,1.1433603,0.11182526,-0.38420644,-0.6074304,1.3718296,-0.69974446,0.09609669,-0.6267308,-0.4614731,-0.34359422,-0.49359384,-0.4942312,-0.5279898,-0.6536452,-0.28664985,0.21765736,0.3518507,0.5867806,-0.762291,0.29537144,-0.17192964,0.08869188,-0.049796402,-0.818162,1.2255211,-0.7342328,0.5109928,0.33367458,-0.46983948,-1.0793712,0.82397467,-1.0270164,0.49148798,0.5373356,0.4614625,0.3475567,2.533947,-0.2738583,-0.11798326,-0.5779161,-1.1250904,0.020995572,-0.3477695,-0.25839704,0.13025497,0.49934024,-1.259634,-0.5955916,-0.26552442,-0.6351635,-0.63020605,-0.53131056,-0.058213245,0.24330544,0.9879664,-0.5547628,1.1987898,-1.7416906,0.5605868,-1.5162556,-0.66597,-0.2675226,0.4712968,0.0013982281,-0.34218663,0.16124684,-1.6217873,-0.2715109,0.9463897,-1.1527389,-0.6203103,1.1553673,-0.26938745,-1.8488377,-0.97153753,0.22251976,0.8658564,0.3642073,0.4843185,1.3888683,-0.28463116,0.12501122,0.70286536,0.05536367,0.56960005,0.8394224,-0.21122259,1.0760585,-0.6143213,-1.478286,-0.9482647,1.8422551,-0.037793733,-0.7650553,0.45142004,-1.5151331,-1.4643159,0.03708919,-0.2740736,-0.59044063,-0.39551666,0.17292586,-0.4299988,-0.3813616,-0.68915755,0.4426102,0.16571574,-0.53561443,0.7006383,-0.20025517,0.8770685,0.5397529,-0.9623641,-0.03315919,0.42437574,0.5561991,1.1751685,0.25961894,-0.15167096,0.3880491,0.0075219255,0.32677236,0.8368385,0.9886124,0.24756208,-0.9235949,-0.20416312,-0.73639464,0.13294016,-0.14132273,0.047358025,-0.048883032,0.20080893,-0.8967925,1.6142989,1.6051152,0.48265323,-1.0482452,-0.31476438,-0.08958078,0.32209986,-0.86530656,-0.042741805,0.6703931,0.53001744,-0.11243988,-0.511916,0.548846,0.28830773,-0.08135923,0.40512192,-0.003949966,0.6356509,-0.26750317,-0.7284966,0.8955884,-0.681608,-4.2971067,-0.49819487,0.6200216,-0.31192565,0.36919147,-0.40665776,-1.4976118,-1.048614,0.4450487,-0.39598408,0.39369896,-0.5856393,-0.09037933,1.0866861,0.4377312,1.212818,-0.5108699,-0.6776058,0.59937346,-0.09392589,-0.811981,-0.5557022,2.5253458,-0.5490001,-0.5835907,1.3553076,-0.29153284,-0.9034929,-1.2773213,0.5837576,-0.09273326,0.3960422,-0.41847646,0.37546933,-0.52831596,-0.025212858,-0.32928434,-0.7601514,-0.512146,-0.21252345,-0.72466445,1.5607816,-0.959828,1.5727482,-0.30162922,-0.49945784,-0.1334222,0.7263527,-1.010628,-0.0874612,-1.3186327,0.1966019,-0.0011756346,-0.8354171,-1.5361011,0.52957135,0.49902725,-0.28528458,-0.8995683,0.36783922,-0.32904145,-0.97164875,0.5744469,-0.7755011,-1.13538,-0.94241863,0.66329426,-0.1417181,-0.03975329,-0.7182821,1.1263685,-0.563342,1.0273814,0.3144486,1.5808626,1.6799344,-0.5681067,-0.5109717,0.47677457,-2.2916589,0.41361764,-0.5250498,0.6513776,-0.087192945,-0.31558925,0.06670581,0.48560292,-1.3583924,1.5971925,5.139718,2.0468173,0.54415596,-1.4129827,1.0574663,-0.8800699,0.849665,-0.721309,0.34339,-1.2221522,-0.25086713,1.0088763,-0.09981591,0.21335416,-0.18969266,0.076575145,-1.2039642,-0.51810336,0.896837,-0.095473,-0.26548558,-0.18932562,0.72944176,-0.00615271,-1.2314501,-0.54297847,0.414981,1.1689128,0.36794484,-1.0866605,-1.8841577,0.4497849,1.7072717,-0.5638017,0.075736135,-0.3166668,-0.31658125,-0.6500476,-0.8870599,1.6880646,-0.09248861,-0.44884375,-0.51933527,-0.96919775,-0.025794938,-0.19572887,0.7932376,-0.46445706,-0.03976806,-0.30311057,-1.0355617,-0.9784224,-0.32929048,-0.6573625,-0.3695074,-1.2189604,-1.0877284,-0.6237293,0.20959029,1.0699579,0.19910541,0.31686077,-1.004144,-0.6474613,0.7185681,-0.374323,1.2263652,-1.8719633,-0.03312338,-0.007378229,0.80267775,1.3519349,-0.11109939,1.0572493,-0.52994347,0.44587407,-0.0020761527,0.77818316,1.0750164,0.9800204,-1.2567167,-0.5316681,0.12566803,0.06561473,-0.091840744,0.62757415,0.4262941,0.6697314,2.6247532,-1.1266029,0.7362816,1.1084838,0.18987796,0.22465143,1.071328,-1.1040184,0.27153882,-0.6518584,0.024309853,-0.09943989,-0.6577763,0.71071666,-0.1452673,-1.3920597,0.90537745,0.26125517,-1.1011186,0.13419801,0.7129232,0.9595822,-1.344024,-0.33511958,-0.022633681,-0.10566028,1.301582,0.8900939,-0.04195652,0.9156783,0.31812003,0.27348527,0.6544905,-0.4996956,-0.91393906,0.9197423,0.24571064,-0.56316,0.66580826,-0.23625997,0.3387779,0.7374972,-0.6248631,-0.58450425,-2.186122,1.226978,1.308053,0.3967433,1.6431477,0.91296184,-0.6807786,0.28268006,0.4648366,0.1743813,0.6728678,1.0777681,-0.57516485,1.6840478,-0.85586566,0.37391442,-0.38950858,-0.91651654,0.7705039,0.12286712,0.6021003,-1.8817314,-0.6334833,-0.41667315,-0.67902035,-0.74202657,0.43464148,-0.57158494,0.3505723,-0.6399201,0.3993009,0.6728691,0.14273655,0.46047634,-0.537287,0.76107085,-0.51099044,-1.4791281,-1.12684,0.20649964,0.14055341,0.4587628,-0.15593857,-1.5874102,-1.1517763,0.30904248,0.5588814,0.34741622,0.325639,-0.17651178,-0.5468017,1.3098211,0.5999715,0.51848304,-0.28685793,-0.006557461,-0.14970057,-1.4336504,-0.6269318,1.8778732,-1.3343829,-0.116790384,1.1446775,0.33453697,1.3358405,1.185548,0.293505,-0.45393005,0.31144962,-0.3505429,0.34416434,-0.2686591,-0.10570328,-1.7763709,0.6825939,0.29283157,-0.58280295,-0.6345547,0.026956573,0.4481255,-0.63714087,0.29152188,-1.6462978,-0.3048643,0.20981084,1.213075,-0.14191568,-1.379865,0.9672659,-0.100120306,0.6049871,-0.79490155,-1.3895535,0.01137118,-0.1329608,0.21494302,-1.0893519,0.10331376,-0.09038098,0.09021364,0.42863983,1.0558121,0.91281354,-0.27677876,-0.91117483,0.68313944,-0.2556234,-0.06256564,0.3377922,-0.09372095,0.84207743,1.0546505,-0.20952481,-0.4181669,-0.58754456,-0.643391,-0.041294973,0.2996037,-0.39206025,-0.32102308,0.5930393,-1.4625585,-0.24744196,0.5277281,0.26595885,0.9823725,-0.3260194,-0.30387652,-0.0048712045,0.9284965,0.20609522,0.6030741,-0.00947635,-0.89077276,-0.64012456,-0.0701236,-0.43270838,-0.87531257,-0.074010596,-0.34389856,-0.3609047,-1.7910894,-0.11889459,0.24739611,0.603945,0.9875114,-0.6007953,0.069687404,-1.5083926,1.3359325,0.6434668,0.8805515,0.4085559,0.16675298,-1.0483488,-0.5122024,0.41484806,-0.60874355,0.33428764,-1.4125549,0.24255964,0.29491597,-0.5322321,-0.114399105,0.6354045,1.0111719,-0.42456993,0.2578169,-0.41437173,-0.8382763,-0.36474374,-0.10052231,-0.79833764,-1.047421,0.48418847,-1.0140682,0.9580695,-0.17048466,0.99405587,-0.96001714,-0.49948582,0.009166015,1.3956474,-0.21068001,-0.6164977,-0.479329,0.41224524,-0.19586287,0.4448357,0.34843084,-0.8160865,-0.07097297,-0.8877339,0.4910494,-0.26340473,0.11399709,-0.50502217,0.8857829,-0.37477693,-0.8305625,0.20641084,-0.5635698,0.56174046,0.14073887,1.2455916,-0.48988122,0.90385026,0.42283782,-0.296975,2.0805643,-0.32116887,-0.6224719,1.3649122,0.40188077,0.66176546,0.47238925,0.06171553,-0.66994876,-0.31732354,0.7183168,-1.0013182,-1.4298005,0.7744244,-0.22843376,-0.31227028,-0.40336186,0.5116245,0.13417412,-1.055976,1.182833,0.77168673,0.12487219,0.044616714,0.016016394,-1.2071235,-2.1782224,2.0325098,-0.33882195,0.24199384,-0.2682469,0.5052897,-0.15354553,-1.2103478,0.22744334,-0.52297866,0.6175705,-0.15019235,0.7280731,-1.2361332,-0.36668774,-0.53144133,-0.44758132,-0.34978586,0.40117115,-0.7807745,1.2766305,0.37430835,0.7777103,-1.1764929,0.4629668,-0.50181866,-0.23543237,-3.615756,0.74682474,0.31379274,0.8662232,-0.24650139,1.0442199,-1.4823767,0.06272124,0.08694902,-0.8055888,0.6613619,-0.064857036,-0.077541955,-0.36644334,0.9345244,0.5297696,-0.2747654,-0.93089163,-0.11285777,2.8602204,0.5971393,-0.5079932,0.6914254,0.6725205,-0.70652753,-0.9158166,-1.0420427,-0.03648408,-0.6498547,1.0469314,-0.48662403,-1.939005,0.280589,-0.9518594,-0.078471094,0.5326461,-0.24416794,-0.38478482,0.3219927,0.75148267,-0.007359622,0.6306175,-1.3413583,0.28686702,-0.07783534,2.362734,-0.62431294,-0.6657073,-0.22651544,0.11446816,0.7659316,0.33599198,-0.19243395,0.37752575,-0.07850668,0.552823,1.5184906,1.0099678,0.43811554,-0.19721578,0.61398304,-0.26946253,-0.94995034,-0.37884295,-0.3911859,-0.018385146,-1.2967533,0.3692424,0.447893,0.46262455,-0.6058291,0.8831723,0.7447043,-0.14433694,-0.015611984,0.64610314,0.3620739,-0.16382925,-0.057670645,-1.0955687,-0.01597409,-0.7673671,0.7059158,0.0085437745,0.05194989,0.22044854,-0.927661,-0.8986681,-1.3573383,-0.5240542,-0.74341995,-0.028711362,-0.39436892,0.4298087,-1.1337718,0.48635173,-0.42755902,-0.6344533,-0.19885331,-0.5616672,-0.32585776,-0.58791703,-0.25762734,-1.1643751,-0.9008725,0.3504702,-0.9984566,-0.4674599,0.49011916,-0.10649703,-0.9470163,0.653604,-0.48529065,-0.11289697,-0.15800563,-0.36602083,0.5327981,1.3101449,0.2551078,1.4618531,-0.7392737,-0.12825376,0.9549267,-1.0590194,1.1460098,1.245958,0.62293965,0.9502193,0.45309025,1.2312222,0.85664964,-1.3959204,-0.77568835,0.519487,0.1745943,0.5380157,-0.6980661,0.16920902,-0.45584396,0.3214491,0.1809217,-1.2136049,-0.42915276,-0.837974,-1.1795971,-0.29660478,0.14932232,-0.08987843,-0.43817362,0.16088477,-0.018468667,-0.7438045,0.4862072,1.2368784,0.20528412,0.9271572,0.80744433,-0.70608866,-0.21685417,0.7228026,-0.5434052,0.14399596,-1.29406,-0.3410648,-1.1988695,0.9266058,0.32436574,-0.54203403,0.38041994,0.9237774,-0.029393196,-0.24370328,-0.6996612,-0.7556057,1.0394055,0.82194406,-0.21235007,1.247534,-0.5796022,0.28736636,1.046787,-0.44113925,-0.25803298,0.50959224,0.8556638,1.2687954,0.78116256,0.198188,1.0475768,-0.74054664,-0.027210413,-0.6096291,-0.34758618,-0.42575473,1.3202415,-0.5218405,-0.5407562,-0.1326991,0.8984465,0.6859335,0.7497087,-0.41254035,-0.6451305,-0.16497648,0.11667475,0.17394547,-1.4493833,0.59430426,-0.5026675,0.8776756,0.591723,0.1960001,0.36594275,0.490076,0.7754754,0.75149775,-1.1803436,-0.88432705,-1.3143203,1.5765665,0.45099103,0.80254084,-0.4461415,-0.37250072,-0.0791654,-0.27592888,-1.3932918,-0.06856969,-0.059339307,0.7538666,-0.8963405,0.1665861,0.71367157,1.4703724,-0.7070886,0.05824372,0.3178204,0.18602784,0.43385184,-0.62293655,1.337889,0.003319785,-0.8817229,-0.71006155]	2026-02-01 11:25:27.765499
e4e21228-afa0-49c6-a250-8b590d1bd9de	06ebd867-87c1-4f46-9ed7-0c8fe8c876b6	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.42769593,0.29911768,-1.8396761,0.04206399,0.081634074,0.20883043,0.488342,2.464585,0.0026925877,0.31720737,-0.109116726,0.112406716,0.24314392,-0.37718594,1.019351,0.6490038,0.6404089,-0.2688867,-0.10890542,-0.26379052,-0.3185464,0.067735575,-0.04863614,1.2463983,-1.6020707,0.45547864,-0.028031733,-0.63245064,-1.0210546,1.5187126,-0.26665294,0.3059847,0.77095526,0.17618272,-0.62656045,-0.7116937,-0.83897156,-0.01962031,-1.1376305,0.73154414,1.0274457,0.13907786,0.44164994,-0.3224366,-0.20877059,-2.251885,-0.47416103,-0.27444518,-1.1251116,-1.5378073,-0.6551251,0.008493899,1.3418906,0.37032434,-0.06281718,-0.3520176,1.2632093,-1.116638,-2.1964023,-0.8348816,-0.5389153,0.8215634,0.025669072,-0.9267439,-0.74526954,2.387922,0.5169055,1.2510526,-0.0009542182,-0.5853941,0.8740095,-0.51881385,-0.31821465,-0.9002878,-1.1709445,0.36859056,-0.81003386,-0.37156132,1.0786686,0.62837803,0.8804387,0.66625506,0.13493037,-0.0630967,-0.15940695,1.066293,0.11945838,0.26931545,0.016925067,-1.2617931,0.09354334,0.7063786,0.619516,-0.7257068,-0.39408436,-0.611903,0.31477118,-1.1183599,0.0749034,0.9493506,0.16584,0.57197833,-0.35880563,0.08821242,-0.88887376,-0.7701398,0.991441,0.7703069,0.8600448,0.6039193,1.2682551,-0.5803226,0.6870849,0.38856804,0.32794684,-0.07725245,-0.5464258,-1.0725133,-1.6080782,0.13928685,-1.8159146,0.108999774,1.3637027,0.44087976,0.26248378,-0.48144785,-0.013284592,0.8156705,-0.22980393,0.3212647,1.271229,-0.55498964,-0.64372945,0.32185352,0.14391738,-0.8828777,0.20314813,0.5336188,0.84629583,0.1365695,0.81759036,0.5185757,-0.86897796,-1.4739395,0.12566823,-0.47744894,-0.014687603,0.12933291,-0.8817932,-0.27824175,-0.33870646,0.6625721,1.0488964,-1.0565879,0.78922266,-0.2969119,-0.56719637,0.2699095,-1.090387,0.2139011,0.83891386,-0.43258995,-1.497449,-0.2603551,0.089738145,0.30278572,0.13628148,1.0085278,-0.33220446,0.14493373,0.19596978,-1.2278774,1.7755926,0.5709247,1.1597396,0.23255245,1.2858211,-0.082280636,0.51340836,-0.48958087,-1.0613524,0.045602232,-0.23590069,-0.3404727,-0.065240055,1.3004065,-0.7479016,-0.2253633,0.11444284,-0.088298365,-0.1300324,0.12419596,-0.09463765,0.02288325,1.9140111,-0.41043252,-0.7228406,-1.3149431,0.5406512,-0.6926883,-0.22495352,0.45612073,-1.1235476,-0.68060386,-0.1281433,0.14486592,-1.5187968,0.29860276,0.87645704,-1.5342749,0.79166275,0.8243707,0.7595936,-1.7173823,-0.94677216,0.030702531,-0.36280134,-0.4002852,0.2182025,0.93014187,0.059761345,-0.83558244,0.9568123,-0.23547058,0.25539404,0.6361868,0.38111654,0.6412069,-1.0333043,-0.93285686,-0.7082153,2.04444,-0.04506577,-1.1722928,0.48336208,-0.74338716,-0.12446643,-0.8965781,0.4912877,0.194094,0.6232406,-0.32030314,0.7269708,-0.5869821,0.21003002,0.36181325,-0.55705106,-0.7912302,0.106460065,-0.39670944,0.5007798,0.12479302,-0.10836664,0.4772262,-0.82447535,-0.27058342,0.40265825,0.34108695,-1.021111,-0.028224282,-0.5751207,-1.2121006,1.2687298,0.83453566,0.1397791,-0.31363207,0.27228636,-0.60098314,0.3844784,0.21544096,0.6845586,-0.23076229,0.5868645,-0.540645,1.8539355,0.8965807,0.2882483,-0.83758485,-0.058674373,-1.1427306,0.63773084,-2.2257864,0.20093068,0.110807985,0.7878882,0.62773746,0.09650347,0.57004213,-0.10785903,-1.2815375,0.6923954,0.22034039,0.5954098,-0.17790988,0.03883714,0.31109437,-0.96189487,-3.75216,-0.4929671,1.3241577,0.4247606,0.75389814,-0.725731,-1.1248525,-0.38366428,0.10963257,-0.7150601,0.22192211,-0.52481306,-0.47894773,0.36349407,1.4000187,0.06777684,-0.33625036,0.04107153,0.83933175,-0.67838407,0.20151553,0.73132783,2.7746027,0.2918416,-1.3918985,0.9122299,0.12207422,-0.40507168,-0.5003897,-0.5760505,0.684181,0.61052126,-0.21222885,0.42267647,-0.4054211,0.3535213,1.360137,-0.10976826,1.0345341,-0.4481926,-0.13677512,1.4622972,-0.7336767,1.4570522,-0.6269636,-1.0733025,0.4051665,0.6687693,-0.72151595,-0.77120763,-0.2858205,0.3454582,-0.57158536,-0.81623155,-1.440319,-0.23113087,0.78869605,0.31400588,-0.6652759,0.28040683,-0.22486655,-1.0792114,0.6493233,-0.42109445,-1.1621208,-1.0371239,0.8116327,-0.2448278,-0.6041244,-0.17177315,0.77422667,0.3532878,-0.4894673,0.03880114,1.0474012,1.3477902,0.34683347,0.5979034,0.40003702,-2.1256216,1.3038698,-0.3009067,0.6069973,-0.07445896,-0.27824986,-1.1653758,1.0038352,-1.2239947,1.8380761,5.138885,0.82776463,1.0825392,0.41544113,0.96283126,-1.1326948,0.11461753,-0.16144353,0.37626442,-0.5736314,-1.024183,0.44089612,-0.4748612,0.99392426,-1.0182521,0.64509004,-1.4344594,-0.5850009,1.0566691,-0.22217745,-0.8533078,0.031218652,0.48984087,0.5600486,-0.9958794,0.7051106,0.69036543,0.3852318,0.38375553,-0.0968937,-1.0868117,-0.8605228,1.8144718,-0.9433721,0.3834524,-0.6734567,-0.787638,-0.2787656,-0.57934225,1.6950539,0.21890098,0.43908498,-0.7938016,-1.224413,0.41514793,-0.8081727,1.0010619,-0.2833719,-0.71584374,-0.54442215,-0.55638975,-0.26538727,-0.8942607,0.8403983,0.13104917,-1.1886936,-0.7026197,-0.5667591,1.0355994,1.6204306,1.1868396,0.9430492,-1.3904622,-1.4994422,0.11987644,-0.39659217,-0.47611475,-1.6775982,0.94202054,-0.13131145,0.17930502,0.6452119,0.3741762,0.34421638,0.06624179,0.80503935,0.40878445,0.4282088,1.0138806,0.10480574,-0.4356649,-0.4971808,-0.109011054,0.7821593,0.47188658,0.36789647,-1.1717106,1.1386071,1.3466252,-0.7124091,0.728881,-0.4561984,-0.7524202,-0.9159603,0.004416231,-0.8963067,-0.3517409,-1.1765654,-0.21259162,0.71260095,-0.3149829,0.22411725,0.01067799,-0.98598826,1.0297792,-0.9496269,-0.2830841,0.52969754,1.3641049,-0.3814366,0.32889563,-0.056324806,0.4029938,0.57570446,0.519927,0.11480732,-0.5357371,1.1580658,-0.019794248,0.27907562,0.6094332,-0.7162898,0.27271235,-0.88455474,-0.5551214,-1.3857951,-0.11107508,-0.36218044,0.42498773,0.23652944,-0.9134521,-0.72859335,-1.5547326,0.6838423,1.5461096,-0.23466143,1.597673,0.8432917,-1.2264187,-0.24747148,-0.6641795,1.01781,0.0642744,-0.5430392,-0.40455672,0.5664986,-1.5464488,0.36445186,-0.59439963,-1.5546054,1.299864,-0.05514861,0.42963678,-1.4383442,0.22569993,0.0373616,-0.42313826,-0.5178007,0.05173742,-0.94932044,-0.3316517,0.031007268,-1.5309396,1.4579141,0.10112338,0.674762,-0.8356378,0.35727018,-0.28066808,-0.42937303,-1.0178039,-0.024040772,-0.5554048,0.9437735,0.07576381,-0.5692262,-0.28868616,0.899536,0.14335917,-0.4988497,1.03257,0.062945,-0.15137056,1.0183983,1.4572235,0.084569976,-0.3080456,-0.054856077,0.50627416,-0.74675876,-0.26060927,1.8858867,-0.76422143,-0.66117966,1.1748303,0.053418383,1.7614452,0.8358006,-0.30215973,-1.7243015,-1.0739218,-1.0329275,-0.15966716,0.062223665,-0.55558544,-1.5785754,0.9070383,0.27628362,-0.8211554,0.049965672,-0.58125615,0.8206597,0.17550485,-0.2196711,-1.131104,-0.37944776,-0.5530299,-0.22738957,0.2284025,-2.0797544,0.742401,-0.06896958,0.6581765,-0.6185128,-1.0344036,-0.00033843517,0.11068034,0.12770045,0.13527657,-0.32387856,-0.037298292,-0.0600738,-0.6924287,0.3435165,0.890417,-1.7357303,0.698213,1.2576858,-0.3450127,0.2261762,-0.62928385,0.5969162,1.8229847,0.27286804,-0.30018848,0.11316568,-0.30278072,-0.8526523,0.65229994,-0.04087922,-0.7413097,-0.33864164,1.3216027,-0.8343497,-0.09085136,0.74699265,-0.34272715,0.92743206,-0.58951515,1.5368701,-0.24117303,1.6365062,0.12754169,0.076492675,0.104833715,-0.52894616,-0.32338256,-0.06490839,-0.5887587,-0.7499001,-1.4759946,-0.15930337,0.15328404,-1.4162266,-0.66356313,0.33527315,-0.3695659,1.3325804,-1.4502522,0.07892751,-0.31293112,0.7303083,-0.053026155,1.055706,-0.012038626,-0.93284243,-0.81620634,-0.5258454,0.18465707,0.20067574,1.045724,-0.4119452,-0.8979323,-0.69296396,-0.95209503,-0.381424,-1.2231897,1.3151311,0.0025954098,-0.24610995,-0.3458032,-0.82036895,0.11309269,-0.49671134,0.30414185,-1.279753,0.8699033,-0.5842804,-0.037670594,0.7896059,0.70649195,-1.3229084,0.34560767,-0.7517229,1.2496003,-0.00076682866,0.85702956,0.083172485,0.06029609,0.37283736,-0.18457332,0.68397534,0.2746015,0.6585606,-0.43122023,1.1983308,0.12207846,0.3998663,-1.1270975,0.769706,-0.49402002,-0.7467058,-0.32745215,-0.24457285,0.58041996,0.8259339,0.059891906,0.018521644,0.7711471,-0.37461627,-0.1946644,2.707388,0.5117798,-0.31361476,1.3467441,-0.8009244,0.16526285,0.10519062,0.85312986,-0.17184427,0.38994098,1.0431728,-1.4435574,-2.0307655,0.9911027,-0.5629819,-0.6654435,0.3490793,0.40142307,-0.5827626,-1.7294334,0.098030016,0.12047152,-0.6069236,-0.03058976,-0.5375669,0.4231902,-1.682683,0.35583282,-0.97360873,-0.37099883,-0.21632336,0.52040994,0.32446218,-0.7430364,0.25617212,-1.1962967,0.76238006,-0.5778218,0.67979497,-0.44362023,-0.15323621,-0.9038005,-0.06525752,0.037226245,-0.24558547,-0.48054036,1.0106975,0.01926966,0.5511734,-1.2329193,0.26394472,-1.1431997,-0.7816164,-3.331035,1.0303345,0.34894192,1.1783805,-0.30965284,0.9863781,-1.8398112,-1.3398407,-0.9312072,-0.2926983,-0.3668241,1.1076338,0.36486828,-0.9387854,0.7714143,1.6404142,-0.41745538,-0.7000396,-0.32308245,1.8112369,0.14044124,-0.69463265,-0.43500116,0.48573166,-0.34016117,-1.5865083,-1.2162066,0.3842625,-0.52393216,-0.8376363,-1.3630358,-2.3629754,0.3256367,-0.69088614,1.1994283,0.8851043,0.28575143,0.28099427,0.43291613,0.21680683,-0.29702565,0.45484188,-1.503487,1.3653392,-0.73059464,1.6009108,0.17164962,-0.82768065,-0.78914315,0.32431263,-0.4205605,0.27622166,0.407735,1.4374826,0.06996651,1.5267645,-0.011373528,0.406218,0.2267681,0.20758495,-0.026755106,-1.2056144,-0.91677123,-0.74623543,0.6238401,-0.11441498,-1.9445875,0.31180117,0.025650427,0.23708081,-0.5659648,1.0679891,0.7084703,-0.14659734,1.172195,0.61765903,0.30664328,-0.3706454,-1.2693512,-0.44867498,-0.28138173,-0.60447514,0.31501073,0.8102804,-0.34477255,0.68199134,-0.032047916,-0.9221531,-1.1363692,-0.68038774,-0.74089515,-0.06710598,-0.9496316,-0.012459109,-1.1509838,0.3756246,-0.7298514,-0.7860613,0.19669524,-0.8014965,0.8112952,-0.9097404,0.58033776,-0.6151894,-0.8485554,1.8454043,-0.09329363,0.3642215,0.9573488,1.0260403,-1.8616688,0.33432445,-0.37417066,0.6924193,-0.5348133,-0.00829647,0.28097817,0.6072091,-0.20696764,1.1097888,-0.028685968,0.13654126,0.78138995,-0.9343919,0.52362466,1.3474923,1.435107,1.2144326,1.1153567,1.4199226,1.3973207,-1.2304769,-0.50868654,0.3606761,0.42872158,-0.062221155,-0.87602824,0.15892154,-0.27615613,-0.6531336,0.79237324,-1.8070604,-0.3381866,-0.8387038,-0.7623707,0.059726916,0.2013504,0.111088336,0.7877638,-0.22587067,0.65814203,-1.1109483,-0.035324715,0.76565295,-0.0033059418,-0.14897338,0.15696935,-0.41621062,0.12440038,1.3328494,-0.2708702,-1.3357153,-0.4796817,0.34921357,-0.92182773,1.2092333,-0.13802621,-0.13122003,0.14497353,0.1642372,-0.643361,0.14656045,-0.8178443,-1.4134578,-0.6758411,0.1388096,0.7329382,1.2851671,-0.78734857,1.3171009,0.374108,0.106250644,-1.2157266,0.8675918,0.35599017,1.7294077,0.3493947,-0.5537969,1.9501606,-0.9613462,-0.80891097,-0.8482445,-1.0786934,-0.7020056,1.3309692,-0.33224475,-0.22957493,-0.23060903,0.70020854,-0.1285027,1.8358964,-0.1003927,-0.23759219,-0.90092665,0.25835592,-0.66918373,-0.38842672,0.60791564,0.5753469,0.9802928,1.0434842,-0.1404543,-0.23662339,0.6205954,-0.19014493,0.60228646,-0.58644277,0.06703575,-0.8398377,1.5907274,-0.14507146,0.45501047,-0.26017267,-0.15204632,-0.10448404,-0.5897146,-0.97530246,1.0075047,-0.584339,0.16528015,-1.3302634,0.5050157,0.992185,0.84261245,-0.019989766,0.22156185,-0.8233856,0.50820404,-0.3139315,0.23269004,-0.026256815,0.6862392,-0.10510087,-0.39832824]	2026-02-01 11:25:34.067678
e8a31f77-4ba0-4d45-a6d3-65911b24159a	f9c9b1a2-8172-47cf-adf8-2128ad1ba885	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.33691075,-0.55892503,-2.788364,0.45718792,-0.4735891,-0.7113689,0.27437022,1.294508,0.6840665,0.4128501,0.8132895,-0.7934243,-0.15419868,-0.08090382,0.58032477,0.10581739,0.7598117,-0.4121403,0.55549127,-0.030248048,-0.491714,-0.08822912,-0.5818196,-0.040769413,-2.0032105,-0.8202813,0.35290405,-0.040189497,0.05331778,1.737283,0.2636183,-0.7438082,0.7366902,1.0926743,0.39698213,-0.13631432,-0.4157749,-1.0693169,-1.4847488,0.05574598,0.75317067,-0.48870435,0.53616,-0.13013096,0.09648466,-1.8248374,-0.8439761,-0.21999544,-2.0679526,-1.2208791,-0.13018367,-0.1742536,1.7666551,-0.2843683,-0.6198418,0.11932634,0.68848103,-0.8135735,-1.8226105,0.23442788,-0.5817795,0.09371512,-0.114409775,-0.2687538,-0.17396417,1.4939377,-0.26574838,0.92279696,-0.6259753,-1.417849,0.5115172,-0.91813534,0.19843253,-0.64014876,-1.1341624,0.25344473,-0.6797283,0.31785542,0.19978316,0.28347427,0.67388844,0.72770375,0.3670469,-0.06791807,-0.39688665,0.64167583,-1.4358017,0.24637762,0.51517195,-0.50429165,-0.765656,-0.22183354,1.484942,-0.9209815,-0.66856664,0.10241469,-0.44362304,-0.770223,0.9609005,0.9429929,-0.3457956,-0.73731583,0.06610704,-0.34450266,-0.2655542,-0.3415081,0.20568754,0.6052246,0.93181854,-0.36894575,1.5242106,-0.5135126,0.59169114,0.6049151,0.18868382,0.20090035,-0.5282651,-0.71956885,-0.34541816,-0.5532927,-1.0696905,1.4978327,1.1799713,-0.06778304,-0.5100855,0.68072516,0.17285566,0.37273642,-0.51318514,0.038813464,0.85531014,-1.1354303,-0.9080949,-0.62815404,0.47631145,-0.6539568,1.0128853,0.13910173,0.2128846,-0.7018699,1.0016125,0.17697039,-0.5913727,-1.0797862,1.5697706,-0.57267046,0.2032429,-1.0276014,0.46877375,-0.7174061,-0.7373912,0.36800924,0.80066204,0.2651189,-0.2143473,0.11651026,-0.75195473,0.17441648,-1.4583509,-0.40652725,0.5457635,0.38690117,-1.3324273,0.32326967,-0.10983702,-0.38556015,0.26753142,1.2889233,-0.04809112,-0.6236672,0.096296474,-1.248943,0.84707546,-0.04717666,0.9753587,0.22303933,1.1436583,0.40846846,0.47820467,-0.38399616,-2.2390752,-0.2220584,0.022202142,-0.78497356,0.18907702,0.10728158,-0.83621687,-0.3331409,-0.7308169,-0.15564886,-0.19959551,-0.5430052,-0.43300536,0.017371403,0.7300576,-0.6476696,0.4130289,-2.1573582,0.2970624,-0.59142894,-0.24321075,1.0054942,-0.44670594,-0.7583973,0.39960903,-0.35674345,-2.0193062,0.003095327,0.78688407,-1.2737639,0.2739059,1.2270786,0.15678988,-1.233335,-0.72948843,0.85848063,0.66985595,0.054108337,0.44999325,0.19748393,0.17509818,-0.42195648,0.5661136,-0.18568902,-0.056655668,0.5077144,0.4321843,0.38109928,-0.18626957,-0.60338575,-0.103256814,0.92629355,-0.48450777,-0.8506805,0.711829,-0.5425812,-0.67061883,0.44089144,0.47568578,-0.67903,0.6410706,0.468863,-0.49597064,-0.27370816,0.12268633,0.22781524,0.14417672,-0.55992615,-0.053310283,0.13314563,1.3913807,-0.19132066,-0.74389404,0.7920472,0.4701351,1.0909175,0.5944328,-0.057234585,0.38449234,0.0503278,0.15452723,-0.92406887,1.1507251,1.4689066,0.7039548,-1.0482547,0.386725,0.53890616,0.75579447,1.2339548,0.5987204,0.38348964,0.8462758,-0.3663744,0.6496996,1.5112205,-0.35948768,-0.06333932,0.28427604,0.13535292,0.3619848,-2.0215816,0.78127426,0.09741795,-0.3314351,-0.013844971,0.03613019,1.2806349,0.08143151,0.39795032,0.008108154,2.2255669,0.6623291,0.34969866,0.40153655,0.5696008,-0.40412906,-3.7972546,-0.73397994,0.7783346,-0.0004938785,0.5024525,-0.524553,-0.7861668,-1.1644638,-0.9983348,-0.8347094,0.2661815,-0.35662875,-0.85021484,-0.58661884,1.1635535,0.16301282,-0.65742743,-0.009537557,0.022796966,-1.1778227,-0.5901369,-0.3328047,2.5739555,0.77123135,-0.6078369,0.26672173,0.08633918,-0.6394668,-0.62827206,-1.2979614,-0.009018719,0.113661215,-0.40890536,0.3264779,-0.80189085,0.31867966,0.27503425,-0.4253989,0.34193707,-0.015311946,-0.13799074,-0.22617266,-0.7018142,0.854762,-0.8387519,-0.31779876,0.07849694,0.9833056,-0.84069824,-0.70744413,-0.44027525,-0.039683472,-0.65111524,-0.08099723,-1.5118604,0.47498256,0.27350488,1.5013063,-1.5531517,0.14256932,0.14809802,-1.2112223,0.81511223,-1.1719862,0.149228,-0.8606386,0.67959577,0.52315205,-0.146345,0.23358946,1.0776576,-0.28404617,-0.53029245,0.04700178,1.0804456,1.0813723,-0.24309452,0.66820025,0.69886285,-2.25418,0.33413106,-0.23772652,0.5894346,0.01850494,-0.49914438,-0.68647385,0.6502567,-1.1390046,1.3257556,5.150157,1.1694885,0.8407635,-0.8205874,0.22770438,-1.5275046,0.9102926,-0.023152327,-1.304781,-1.1404281,-0.6754238,0.04170604,-0.08813869,1.0902569,-1.0322269,1.0224825,-1.3733246,-0.080036506,0.7236308,-0.5223868,-1.1840386,-1.0040925,0.031809468,-0.20806403,-1.5097915,1.3175485,0.45962137,1.2843237,0.4298547,-0.2031593,-2.0308409,-0.2297415,1.116598,-0.78672415,-0.21955594,-0.9074605,-0.44706428,-0.4924263,0.4236247,1.1137416,0.050503187,0.069313765,-0.09459008,-0.8757064,0.12500146,-0.34486607,1.5166587,-0.38455814,-0.5799938,0.32112327,-0.9435357,-1.0702907,-0.83661854,-0.20930697,-0.49294427,-1.2760694,-0.22937952,0.16810156,0.6599104,1.1332033,1.0142856,0.60818976,-1.0951941,-0.3305128,0.20960873,-0.66027904,0.15390676,-0.94806737,0.08358771,0.17693684,-0.096414804,0.7471935,0.22523986,-0.1472367,-0.37015423,1.0201792,-0.20032921,0.6253169,1.2017393,0.45241654,-0.46401706,-0.17581329,0.6465649,0.95762396,1.2301087,-0.032364253,-0.29873145,0.76961434,1.7570578,-0.44354603,1.0276355,0.7146308,-0.05757511,-0.020542845,0.15538606,-1.2365878,-0.12993525,-1.0139277,0.084120624,0.42860234,-0.92887336,-0.011943601,-0.39364547,-1.5298762,1.3265281,-0.8645518,-0.69925267,-0.0379362,1.4312294,0.45856184,-1.3869369,-0.4050106,0.1159115,0.13192268,0.10536337,0.32429162,0.83164746,1.192942,0.21985383,0.69045305,0.31244987,0.024685882,0.4435403,0.33194432,-0.3935799,-1.236992,0.70885336,0.14346066,0.1657922,1.0525821,-0.94203025,-0.69911623,-1.8792,0.6024863,1.7207866,0.28524575,0.026667312,-0.45298684,-0.9429746,0.3558097,-0.8599096,0.8864594,0.83317804,0.5084435,0.327985,0.8348163,-1.0458795,0.9569341,-0.6957604,-2.1476,0.58623713,0.38711706,0.36545274,-0.5070157,0.30399853,-1.238699,-0.08184695,-1.324174,0.70607954,0.079050794,-0.32806936,-0.44125855,0.14797738,1.1156399,0.7999124,1.4040214,-0.20707487,0.29426333,-1.1819615,-0.44046262,0.5132489,0.28365257,-0.48196647,0.5185292,0.5597886,-0.8097319,-0.25089824,-0.18371421,0.7985454,-1.3043233,0.3318118,-0.16532953,0.97682357,0.12109484,1.2352962,0.5288905,-0.11023162,-0.35819736,0.30254117,-1.1457207,0.29260823,2.011626,-1.403102,-0.90923285,0.5594476,0.9779708,1.7987024,1.3047266,-0.3170106,-1.3859674,-0.57955843,-0.72203714,-0.5942404,-0.4173457,-1.1053807,-1.0478041,0.751889,1.4089067,0.47634214,-0.26481628,-0.59675866,0.29432464,-0.697928,-0.27857262,-0.9938297,-0.6293795,0.5267901,1.5089625,-0.37067735,-1.6026958,0.97436774,-0.17638922,-0.13682875,-0.65000135,-0.6154962,1.3389256,0.450014,-0.08713559,-0.32446858,-0.7051129,-0.090473995,-0.052249752,-0.33788246,0.26318148,0.20019999,-0.16873962,0.3329278,1.1039544,0.3100889,0.41906524,-0.33727226,-0.26791734,0.9234359,0.5434716,-0.5147077,-0.4516409,-0.93023974,-1.2713968,0.8579445,0.08263631,-0.6375014,-0.8218749,0.66248184,-1.0315185,-0.5198835,0.038621955,0.31904072,0.9700514,-0.25253516,0.30944917,0.17902528,1.9235522,0.8854152,0.29446262,0.51793796,-1.0482095,0.4316833,-0.7998164,-0.3834565,-0.48595634,-0.46040583,0.9329225,-0.28436658,-0.4987218,-0.14328569,-0.2880984,-0.19554533,1.178298,-0.25086832,0.5148365,-0.45494896,0.2735027,-0.15847516,0.69369406,-1.4543855,-1.0361359,-0.84611017,0.4929831,-0.33218098,-0.5532707,0.17627801,-0.53989595,-0.60999566,0.37498513,-0.1598461,-0.00037986413,-0.59069467,-0.5024042,-0.3934334,-0.21526676,-0.8704614,0.7744407,-0.18058175,-0.16373995,0.33273992,-0.22739983,1.0411775,-0.85019743,-0.15560883,-0.11101943,0.42159933,-0.8930069,-0.06013429,-0.36599416,-0.36928156,-0.6588443,0.7693392,-0.4243254,0.14621651,0.7867068,-0.0144924065,0.1487756,-0.5735089,0.5467671,-0.86909974,1.4837196,-0.4982412,-0.7634422,-1.2105383,1.2367977,-0.8381723,-0.73584664,-0.95629936,-0.4238527,0.7321662,0.924293,0.056986783,-1.0327239,1.1515718,-0.12204185,0.16284965,2.432106,0.55327594,0.26060593,1.4248726,0.45759505,-0.41838872,0.15866554,0.4879173,-0.4899424,0.65615565,0.99642384,-1.3670528,-1.407635,0.9281385,-0.26859394,-0.42247918,-0.76371634,0.5299724,0.80240554,-1.5929081,0.5821532,-0.5054811,-0.6477754,-0.008006046,0.46785384,0.024825925,-1.7585663,0.854485,0.117894575,0.30331957,-0.610252,1.0620304,-0.0901709,-1.6712136,0.9272731,-0.67281145,0.73818564,-0.29766265,-0.19159944,-0.54525197,0.37640062,-1.9091678,0.4115368,0.80200195,-0.9676663,0.46765518,0.5770224,-0.3462128,0.34085885,-0.62226784,0.87048197,-0.72509265,0.46861556,-3.2458775,0.17438096,0.21958335,1.3846205,-0.16348416,1.1065713,-1.7526932,-0.7714216,-0.41278118,-0.16119997,-0.3406162,0.6958025,-0.1771737,-0.62107146,1.5294902,1.144058,-1.1912639,-0.24649996,-0.04796305,2.224372,-0.6740836,-0.07247688,-0.83010185,0.06384458,-0.09873352,-0.2802531,-0.44465062,0.6491773,-0.29109105,0.039530937,-0.61884123,-2.5781884,0.3876817,0.05208209,0.6480336,1.0446149,0.36060023,0.39627412,0.498877,0.42173007,-1.2132032,0.84935576,-1.634746,1.1997956,-0.9897569,2.7764034,0.022910774,-1.0903763,-0.9067628,0.7106721,-0.5180772,-0.19484504,-0.41879603,1.839109,1.0976036,0.9394343,0.1605104,0.88327456,0.792795,-0.5889136,0.21179129,-1.3805718,-1.3170961,-1.3811256,0.006318831,0.062435336,-1.4513857,-0.14754984,0.622726,0.6408579,0.021768719,0.9709958,1.4160696,-0.2172613,1.2629609,0.7792445,0.50538594,-0.57760704,-1.2062559,-0.2575413,-0.57542473,-0.6041941,0.105033934,0.41374722,-0.46787664,1.3664653,-0.5204892,-1.3092148,-1.3700684,-0.60654277,-1.9647806,-0.46643332,0.10591856,0.44679397,-0.7387524,0.3651988,-1.55698,-1.0171721,-0.24562815,-0.80898005,-0.018595055,-1.5648378,0.023118507,-1.0741373,-1.0377489,1.435156,0.367939,0.5997082,0.45382613,1.2375379,-1.3340896,0.34649542,-1.3351529,0.5454562,-0.949993,-0.45931813,0.75934464,0.9387583,0.5304005,0.906531,-0.33975667,0.15646324,-0.2941635,-0.4437151,0.6069531,1.6651559,0.54788166,1.2332695,0.48781413,0.9182032,1.2692248,-1.6453156,-0.7936121,-0.36883846,0.68042314,1.2814792,-0.97622114,0.39519313,-0.20295557,-0.14567214,1.190521,-0.49957597,-0.4556189,-1.3789198,-0.97646236,0.44178995,0.60279536,0.2686845,-0.9846388,0.00074207864,-0.00927284,-0.7359115,-0.15088505,1.3779943,0.052476436,-0.5512891,-0.7444986,0.37581962,0.7036131,1.2944044,-0.084533386,0.004870898,-0.46753588,0.22957374,-0.47154436,2.2392943,-0.49301812,-0.47029868,-0.6397474,0.20629798,0.5876288,-0.23481303,-0.9664872,-0.91745466,0.7028561,0.6293204,-0.3292884,0.92143816,-0.4815458,0.84133816,0.59801364,-0.3735147,-0.09888618,0.72916096,-0.17024879,1.5815511,0.6907481,-0.9738797,1.1416509,-0.6946435,-1.0130616,-1.2776905,0.44790837,-0.73346794,1.6714482,0.288005,0.6526606,0.31686425,0.16836673,-0.6417351,-0.067791134,-0.6093176,0.15731879,0.10585219,0.13182434,-0.99467003,0.19968271,0.7544956,0.10707614,0.7398844,0.63434225,0.2607029,0.05875025,0.6405574,-0.40500224,0.8591636,-0.17387055,-1.6542213,0.067297675,1.4385065,0.3912143,1.031287,-0.6115658,-0.3219879,-0.811956,0.22230357,-1.2817012,0.7189816,-0.2371468,1.1838008,-0.472075,-0.40084413,0.9224061,0.7756092,0.58795244,-0.270163,-1.3495961,0.22527763,-0.39808956,0.0978653,1.2452444,0.004391838,-0.56031877,-0.7959556]	2026-02-01 11:25:38.821002
49d8c592-d8fa-4512-a773-c7598dfdcb98	bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-1.4650491,-0.06506481,-2.1102052,0.964838,0.13497989,0.23772268,0.498605,0.9622811,1.2440515,-0.22863103,0.75089985,-0.4118192,0.69789666,-0.26407236,0.6283847,-0.09201571,0.6081862,-0.7563882,0.024053007,0.14114231,-0.17393105,1.0995902,-0.27110928,0.88985264,-1.0435965,0.3364018,-1.1603287,-0.026744565,-0.005822491,0.3816412,-1.0754557,-1.3518769,0.018533614,0.54260033,0.38633078,-0.4452922,-1.0479904,-1.4364941,-1.1165488,-0.21684127,0.97288,0.23776108,0.26914677,-1.7428174,-0.9261759,-0.83931565,-0.7091085,-0.19412744,-2.307321,-0.22690281,-0.16432342,0.81874275,2.0526166,-0.64263296,-0.12629585,1.3168123,0.44115242,-0.5008855,-2.906377,0.18017055,-0.7072854,0.8318705,-0.19160669,-0.51409036,0.12810068,1.9068468,-0.7218286,0.87257826,-0.42268947,-0.77961624,0.6436467,-0.44880608,0.38853356,-0.6062286,-1.0521696,0.5189378,-1.1132631,-0.28767577,-1.3310318,1.1452469,0.23394898,-0.09806946,0.17860205,0.10871476,0.34497577,0.559309,-0.12253119,1.0245391,-0.54648006,-0.82996523,0.35753015,0.21043843,0.6489582,-0.3383523,-0.57198334,0.25692528,-0.7787208,-0.73626184,0.5932594,0.52984,0.023947343,0.37573418,-0.29489347,-0.9491924,0.35518804,0.287995,1.3343155,0.83110654,1.1823088,0.098444514,1.0829881,-0.3819858,0.4963146,-0.11812286,0.31288314,0.019329507,-0.39936557,-1.3470416,-0.313692,0.26359284,-0.67215145,0.80927014,0.479303,-0.15616673,0.4411309,-0.1713052,-0.06521339,0.17571384,0.17144337,-0.35530803,-0.105470955,0.2405045,-0.66009945,-0.87334317,0.19251542,0.05514756,1.057543,1.3859196,-0.06717366,-0.7838667,0.71130997,0.7969016,-1.1318307,-1.0426819,1.2180126,-1.0002655,-0.07595217,-0.7865853,0.6608533,-0.32709664,-1.2129439,0.0014210246,0.7750501,0.20888351,0.6598361,-0.5601842,-0.3856432,0.3305542,-0.33078662,-0.03219056,0.6468864,-0.37566474,0.15973963,-0.03716089,0.4116801,-0.28147376,0.3887109,1.0785846,-0.77565974,-1.201371,0.5919944,-1.4217415,0.78536546,0.17242552,0.5409589,0.4186117,1.6108661,0.3562183,-0.408289,-0.29786325,-1.0426595,-0.056459352,0.10617711,-0.63160294,0.25857562,1.0101109,-0.34534392,0.089218155,0.2366595,-1.1540681,-1.3050042,-0.6496698,0.9799359,-0.369477,0.9922974,-1.2342547,-0.3634646,-0.8072764,0.13148856,-1.4344077,-1.2499523,0.57814044,0.6833794,-0.10024224,0.2259267,-0.014411092,-1.1998664,0.06427985,0.98793745,-1.3634721,1.3993484,0.5012401,-0.44618884,-0.7741463,-0.43554193,0.15494232,0.9905956,0.26840708,0.8523617,1.0589163,1.1887873,0.2973809,0.058197096,-0.14239535,0.9068433,0.7797309,0.32769722,1.4366242,-0.12321577,-0.6880586,-0.7070706,1.1486155,-1.2466632,-0.27047327,0.56082803,0.28937694,-0.28962153,-0.375119,0.85310507,-0.24908055,0.093052536,0.15948823,0.4998997,-0.35994002,-0.613173,-0.44149682,0.34496439,-0.36638975,-0.14198512,1.00614,0.61207056,-0.92540336,-0.013628487,1.0718735,0.03260497,0.64072865,0.5374825,-0.106738806,0.015136495,0.759396,0.0072077103,-0.10662207,0.8321509,0.54127437,0.7221956,-0.38486755,-0.05906938,0.7932026,0.43510827,1.5475353,0.75717413,-0.24757884,-0.5796961,-0.6470737,0.6077887,0.85314846,-0.7039495,-0.23780678,0.7388577,0.10109416,0.1599991,-0.57678187,0.20151123,0.37239447,0.7172579,-0.6253025,-0.060686905,1.1015911,0.18824932,-0.90281385,-0.45399573,1.7580643,0.9939519,-0.37053075,-0.5973117,0.123766184,0.0028905533,-4.235181,-0.947807,-0.7243489,0.19503334,0.6011052,-0.9674809,-1.2181143,-1.4225845,-0.33662772,-0.9449643,-0.5319052,-0.90774643,-1.2151542,-0.6822821,0.70693886,0.42517018,-1.1472324,-0.06122283,-0.39273176,-1.2029055,0.72428066,-0.3997784,3.2907171,-1.5945513,-0.42721564,0.66827595,-0.86934423,-0.577147,-0.9762093,0.013657149,0.44202143,-0.3381917,-0.5593675,0.69388694,0.45976534,0.37543955,0.793666,-0.3303223,0.5193999,0.3946597,-0.026936114,0.9529431,-0.7069183,1.4450246,-0.86904013,-0.9486755,-0.24721153,-0.28425694,-1.0711483,-0.6055202,-0.017557293,-0.063842446,-0.59776556,0.052997,-1.1505158,0.020941637,-0.4742667,0.8616878,-1.756265,0.14638837,-0.43994594,-0.58545643,0.17639579,-0.3494472,-0.80082864,-0.5010849,0.9349805,-0.03451712,0.6681022,-0.08861574,1.5781865,-1.6336434,0.16252384,0.33293307,1.5503534,0.44171458,-0.0019409247,-0.56693023,0.3816007,-2.4534986,0.3176857,-0.32938066,0.77012146,-0.46076286,0.12360874,-0.35501117,1.2355922,-1.0892943,1.4662548,5.4940243,1.6937244,1.0358988,-1.0274612,0.48628312,-1.2208425,0.019854799,-0.1304892,-1.6910436,-0.73125076,-1.1844252,0.89375794,-0.1524174,0.9613371,-0.076710135,0.5005098,-0.88955534,0.032033682,1.2765948,-0.60462517,-0.63071084,-0.28026432,0.6428625,0.30931175,0.26945683,-0.08644271,0.017071385,0.27584127,-0.12619376,-0.2807607,-1.7540596,-0.13533388,1.1681219,-1.8404444,0.4226698,-0.23097107,-0.4766143,-1.287164,-0.17811659,1.6346798,0.31804696,-0.34468016,0.806423,-1.1040263,-0.38314855,-0.080147535,1.3383412,-0.30978715,-0.14252785,-0.009821678,-0.66089165,0.050485663,-0.33977062,0.062647164,-0.04651688,-0.40980932,-0.24349627,-0.09764714,-0.27556098,0.3267816,0.5688127,0.233771,-0.94388205,0.7028106,0.12691757,-0.18260449,0.007556703,-2.2724378,-0.50962627,0.15468378,0.63504636,0.007840708,1.1818101,0.26879916,0.65813774,0.61856616,-0.2632053,0.15585598,1.4651661,0.6341463,-0.61617184,-0.6817397,-0.10794247,0.14967574,0.21116975,0.27794555,-0.21295926,1.4643637,1.9549446,-0.39158413,0.80890316,0.21824515,-1.1770579,0.09176184,0.26775587,-1.147998,0.06556911,-0.13356838,-0.018331531,0.6285884,-0.5791367,-0.2113857,0.041820124,-1.3817959,0.6800815,-0.21812235,-1.0006804,-0.8401905,1.167225,0.930684,-0.16863312,0.16832997,0.1544781,0.09482092,0.63568026,0.47061658,0.10218933,0.054859333,0.003992196,0.6876607,-1.0191367,0.7541664,0.10998015,-0.35798457,-0.5221109,-0.81165874,0.7520962,-0.051315513,-0.21701793,0.38292524,-0.6795385,-0.9986202,-2.4847345,0.47936302,2.4420419,-0.9093966,0.96290755,-0.66813314,-0.5264349,-0.20768307,-0.3563281,1.429197,0.94908446,0.81450564,0.2952271,1.0167903,-0.8710171,0.90630555,0.35727093,0.6025015,0.629276,-0.60685813,0.06274272,-1.4110372,-1.5013945,-1.0262729,-0.40468463,-1.1977513,0.5686578,0.06304075,0.48522177,-0.5874908,0.81159574,1.1505332,0.8543787,1.8195134,-0.5252012,0.42484292,-0.9136691,-0.1632549,-0.15901193,0.21825221,-0.007882152,0.44027543,0.2354759,-0.09748387,-0.036004454,-0.30133998,-0.34823886,-0.42725167,-0.12521604,-0.618478,0.51007664,1.06206,0.68191195,0.61330634,-0.059448704,-0.2661882,-0.30808467,-0.40751395,-0.021945065,2.0845108,-1.2532469,-0.35706285,-0.19133325,0.7559908,1.1158932,1.5217931,0.07060978,-1.263779,-0.028037705,-1.2877666,-0.09972819,0.11589886,-1.763838,-1.3604677,0.59752715,0.21614312,0.13163766,0.05924011,-0.40241674,0.4105472,-2.1532648,-0.08778565,-1.2503392,-0.5064529,0.46909952,1.4318807,0.39738956,-1.3611999,0.5662576,0.39002886,0.3957147,-0.9672141,-0.52448714,-0.41341612,0.53506505,-0.985821,-0.72290206,-0.2761556,-0.18728738,-0.64602757,-0.2563599,0.027751654,0.69212824,-0.12122698,-0.3430737,-0.026016235,0.18878926,-0.034153488,-0.069694296,-1.0081296,0.09598693,1.8903861,0.120070025,0.6399927,-1.5999497,-0.566597,0.44570646,-0.25800577,-0.3399955,0.31019816,0.086458966,-1.9964051,-0.7435363,0.0960545,0.0072154924,0.88243425,-1.6936792,0.49167895,0.39087933,2.0996344,0.06815304,-0.16210684,0.45536083,-0.54312384,1.0263512,-0.9620986,-0.16562802,-0.26981774,-0.5579022,0.61173296,-0.22033392,-0.14774498,-0.8006998,0.27974316,0.5251686,0.7146559,1.5920548,-0.56946856,0.44352016,0.97424376,-0.724186,1.7298706,-0.93686026,-0.06223867,-1.6097202,0.8547873,-0.3433539,-0.58022964,0.18160348,-0.5926931,-1.0101278,-0.31714755,-0.5837498,-0.30710506,0.5344908,1.3538373,-0.040473763,0.16528487,-0.16875759,-0.6403184,-0.81839806,0.124028474,-0.1806048,-0.4497644,1.0106592,-0.18720593,1.1398433,-0.34204936,-0.1754973,-0.31337485,-0.43935913,-0.5541953,0.63795525,-0.7656761,0.33281896,-0.21396706,0.77064604,-0.13018376,-0.25000745,-0.5867358,-0.32394964,0.6467263,-1.0122864,0.45658556,0.107682526,0.9012311,-0.0408248,0.07507486,-0.03112955,-0.7826621,-0.91468954,0.19555792,0.30495805,-0.65906227,1.0544293,-0.7479298,1.5263618,0.033729732,0.4173747,1.3993729,0.19963157,-0.17956871,0.81259614,0.11634097,-0.23141527,-0.30561098,-0.7479707,-0.8231894,-1.2837166,0.8824474,-0.798016,-0.84655863,0.40529752,-0.12464897,-0.94347745,-0.42969912,0.88832116,-0.17498106,-0.9771132,0.80126995,-0.87968564,0.76308113,0.31793466,1.0116559,-0.8705973,-1.8772514,1.4821029,0.26383102,-0.26843712,-1.0352522,-0.039238527,-0.087381996,-1.0945333,1.552504,-0.9468695,-0.19292583,-0.22640659,0.78858,-1.0348148,-0.46106923,-1.2682126,0.044851318,0.44417793,-0.42722157,-0.086362965,0.91762567,-0.32089058,0.12206845,-0.2060961,0.4343209,-0.7880616,0.360298,-3.6224892,0.54742557,0.0107530635,1.1431122,-0.9058895,0.91341835,-0.9819576,-1.007246,0.016101196,-0.6053188,0.20140792,0.040751137,0.2095028,-0.6735691,0.19590315,0.473921,0.18096305,-0.4221621,-0.18117236,1.2120578,0.6631797,-0.33164003,-0.9086172,0.28235483,-0.4162609,-0.6525405,0.012973212,0.107301235,-1.2426498,0.34143987,0.23147172,-1.2575604,-0.37716573,-0.13904482,0.59839755,0.4476999,-0.17625569,0.0904336,0.8035183,0.8579968,1.2926818,0.48683614,-1.1465391,-0.7012897,-0.19420068,0.95998174,-0.72545767,0.04373043,-0.83716524,-0.32113382,-0.03692318,-0.76851153,0.26943535,0.68833303,0.9469618,0.73929834,-0.19564326,1.3237944,0.5541012,0.4993661,-0.2958428,-0.6295472,-0.58564967,-1.0304801,0.16867957,-0.29956532,-1.7958509,0.4560688,0.39315432,1.0268557,0.3878778,0.21645808,0.9623623,-0.41064984,0.0031017885,0.8811671,0.96040636,-0.37559918,-0.7214786,-1.2927364,-0.2062574,0.37647328,0.39467987,0.13522176,-1.0175183,0.70510143,-0.51756406,-1.1027728,-1.6363562,-0.95096546,-1.7186793,0.10813328,-0.35637212,0.85559785,-0.36418232,0.19849756,-0.827404,-0.69921845,0.22473001,-0.30391142,-0.49334905,-2.1085317,0.62093616,-0.1462846,-0.8531217,-0.4276665,0.44859266,-0.13848913,0.5019383,0.41493616,-1.6452137,0.35053292,-0.5380796,0.69552106,-0.4638299,-0.4399851,0.24040216,1.1159207,0.4249462,1.6686318,0.5661206,-0.96817595,1.2072734,-0.8660215,0.9037765,0.48698208,0.49329185,1.838227,0.14907032,1.3812099,0.8648381,-0.3712355,0.01583388,0.052852176,-0.06824909,0.0063043125,0.79098004,0.58957285,0.015521131,0.27501562,0.18991697,-0.17410317,-0.848758,-1.0147635,-1.1563921,-0.4227137,0.23532462,-0.56006885,-0.6649632,-0.52184355,0.65458703,-0.38722923,0.19610526,-0.14780068,-0.09993914,0.0910375,0.32012755,0.3528621,0.35550806,0.91911805,-0.6810005,-0.12217647,-0.7514939,-0.74535674,-0.22182156,0.5827307,-0.5733101,-0.6653582,0.12053524,0.9048883,0.6677109,0.68119586,-0.09444048,-0.29610854,0.783389,0.10153881,-0.3598134,0.19737624,0.8508226,-0.28756464,0.73628056,0.27435005,-0.44300765,0.2723486,1.1742002,2.0575852,-0.27702454,-0.72266257,1.7447113,-0.6580387,-0.22618091,-0.12326799,0.15903178,-0.48312253,1.2514181,-0.25993782,-0.33670908,0.90585625,0.3325496,0.29912478,1.763726,0.29384264,-0.13376789,-0.5496517,-0.16591653,-1.2303945,-0.4367743,0.21256495,-0.4487607,0.9146436,0.5202814,-0.2224991,-0.29871386,1.2054942,-0.0052627027,0.99557245,-1.2333318,-1.0085136,0.2955308,0.74609244,0.20625505,0.68457556,0.22334403,-0.2088155,-0.32287693,0.32337573,-1.269504,0.34398773,0.3757772,-0.20005779,-0.6492507,-0.47283927,0.36250678,0.5495347,-0.13063645,0.8585283,0.17710961,0.11031191,-1.4553566,-0.4074055,0.9992019,1.0607398,-0.16619158,-0.23452464]	2026-02-01 11:25:43.830724
2f8446b8-bb14-491b-ad89-139736ce5667	2688d0dd-cf73-48d5-9081-d721c08a8e59	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[-0.38659695,-0.061170477,-2.1396787,0.38395834,-0.043768473,0.4670881,0.34396645,1.2647157,0.80397105,0.11939946,0.7112397,-0.90429574,0.1426604,0.26655543,0.02470671,0.20634194,0.51549506,-0.63823503,0.3322979,0.26263657,-0.6860396,1.5388786,-0.32087433,0.5108274,-0.70795244,0.17872785,-0.76492554,-0.1086856,-0.008492983,0.6658201,-0.49065086,-1.3352776,-0.26852328,0.34191132,1.0534426,-0.84026206,-0.8574755,-0.7564718,-1.1417222,-0.52667165,0.44575167,-0.032986633,0.6942603,-2.0248375,-0.39210275,-0.84550506,-0.2562736,-0.2516929,-2.360107,-0.3368505,-0.574673,0.31680498,1.4425763,-0.6726678,0.054911748,1.0017663,1.0670981,-0.29095146,-2.084557,0.08515981,-0.91658413,0.8678769,0.039657198,-1.6020712,-0.7256337,1.2755402,0.18737201,1.1760631,-0.2828081,-0.64383084,0.11573088,-0.77851903,-0.26972502,-0.20996225,-0.69232595,-0.11625906,-0.75373614,1.0146906,-0.19973604,1.5445715,0.3056409,0.3978685,-0.26021457,-0.30141532,0.3789854,0.5636778,-0.38910824,1.5420961,0.19304723,-0.956087,-0.024114566,-0.25896555,1.1457789,0.057471946,-0.3234589,-0.22348893,-0.3908279,-0.42436993,0.115232825,0.31600755,-0.0851068,0.022535354,-0.010803362,-0.667202,-0.32458332,0.5077588,0.42341065,0.6194084,1.0402006,-0.17766745,0.8481466,-0.1746006,-0.36850256,-0.030282212,-0.13215624,0.16190559,-1.0613717,-1.9144573,-0.63633305,0.5725267,-0.34891573,0.05611421,0.2885299,-0.19033657,-0.23313324,0.20126833,0.6069193,0.56500536,0.24723235,-0.17196564,-0.5996647,-0.784886,-0.5465703,-0.50855136,0.8076048,-0.6369528,0.58777463,0.5062044,-0.35270238,-0.8460506,0.5940861,0.3497615,-0.69981706,-1.5727931,1.3171866,-0.0817745,-0.5087618,-0.8619591,-0.25339258,-0.17666343,-1.343125,-0.23974916,-0.0766784,-0.42855805,-0.12540859,-0.12300547,-0.3893017,1.3726376,-0.6122752,-0.029662974,0.501383,0.009989869,0.3164861,0.10469138,0.72176576,-0.69940233,0.4121832,0.8297754,-0.92265505,-1.2614893,0.35927793,-1.3036598,0.31135604,0.6527269,1.5537051,0.5749268,2.0474355,0.33696935,0.10038032,-0.714021,-2.0312781,-0.15588006,-0.1418932,-0.74593675,0.037827507,0.5965311,-0.9998365,-0.13152258,0.019044816,-0.6969427,-1.246307,-0.37461606,0.33924854,-0.8182714,0.67904955,-1.3946968,-0.19236213,-1.0602899,-0.26500392,-0.9044939,-0.7385837,0.11121601,-0.41784462,0.438996,0.42853412,-0.17516303,-0.82540375,0.22271845,1.4653182,-1.8542364,0.75242484,0.5109379,0.12097795,-1.0249735,-0.52647215,1.0410603,0.9673006,0.36453256,0.54352784,0.69974416,0.6246059,-0.2925185,1.3472922,0.14784713,1.1587633,-0.68983406,1.212978,0.8754383,-0.7996889,-1.1794586,-1.0524198,1.2958738,-0.4451821,-0.24560884,0.7370989,-0.16810927,-0.41099292,0.1375206,0.6174087,-0.4699511,-0.14900228,0.9209863,0.31803533,-0.1434229,-0.257633,-0.15141535,1.1297525,-0.29970577,-0.07977468,0.36538038,0.15274009,-0.30893674,-0.9607314,0.94551384,0.28469902,1.2711946,0.8128837,0.37023836,0.19790256,-0.13544992,-0.015703144,-0.12568717,0.9098622,0.74014276,0.8134074,-0.26253533,0.09200626,0.2582281,0.8515257,1.806914,0.43419123,-0.01505534,0.10913087,-0.08305527,1.6166004,1.152361,0.072616,0.3286512,0.61350447,-1.069274,0.1564442,-1.1244174,0.57406145,0.5392487,0.10348639,-0.3083953,-0.20723838,1.6300471,0.32785282,-0.7463201,-0.13214785,0.2977368,1.286606,-0.8750633,-0.62448627,-0.14391878,-0.17494534,-3.7547975,-0.3034939,0.911504,-0.35481033,0.63607824,-0.27483952,-1.2372134,-2.1364503,-0.8072013,-0.7713203,-0.31742424,-0.93766963,-0.92001826,-0.6259722,1.0489043,0.6329876,-0.8063621,0.39802322,-0.01576376,-1.0536904,-0.20294207,0.69239587,2.3751385,-0.36339736,-0.5183716,0.6369658,-0.96947896,-1.155201,-0.8824239,-0.56715006,-0.17511003,0.08314953,-0.43390545,0.19852598,-0.57516587,-0.08644183,0.3509045,-0.4971317,0.71633065,0.5471746,-0.4201573,2.1147459,-0.48910657,0.5875804,-0.49391836,-0.42913333,-0.19054632,0.5906662,-0.4643794,-0.47248572,-0.38513312,0.15449989,-1.1204098,0.26400036,-1.7064931,0.78174317,-0.68844205,0.8812037,-1.0899442,-0.51736736,-0.6660095,-0.27456096,0.21386214,-0.44035852,-0.5964497,-1.451067,0.30671582,-0.26259816,0.67678565,-0.89625484,2.1695263,-1.1864707,0.083395176,0.99955666,1.1897311,1.1325026,0.87686276,-0.7162645,0.45269907,-2.682273,-0.38165325,-0.30221012,1.1681504,-0.57916576,-0.36187842,-0.58636105,0.417469,-1.1141158,1.3395464,5.48073,2.144153,0.94407105,-1.5063269,1.573967,-0.55239856,-0.06543471,-0.89883846,-1.023165,-0.5503073,-0.8737075,1.1262821,-0.5700404,1.2063404,-1.13642,0.83221996,-1.5573003,0.25906232,1.1342995,0.3543675,-0.41467866,-0.70442843,0.41083035,0.13942803,-0.9356376,0.06339729,0.3867417,0.91894275,0.31647897,-0.39599052,-2.2605398,0.25143775,1.3278272,-1.601828,0.78228843,0.39993945,-0.4943028,-0.9978647,0.04276099,1.7604482,0.117626496,-0.4832756,-0.08217637,-0.8316804,-1.0689247,-0.34318438,1.0265509,0.5300932,-1.060059,-0.37633306,-0.54724467,-0.027100047,0.0030677672,-0.5711969,-0.09362524,-1.3386279,-0.74462277,-0.659932,0.62603825,1.278825,-0.30760643,0.21953449,-0.84994376,-0.1293907,-0.058332454,-0.4425169,-0.80275,-1.153013,-0.5418913,-0.0007530246,0.3757245,0.20768775,0.95635325,0.5640356,0.15012074,0.97274256,0.27342632,1.0410737,0.56973124,0.71510005,-0.5868858,-0.2956359,0.022756131,0.2355589,0.50212914,0.21353999,-0.23870508,1.0970478,1.8270198,-0.8717481,0.905264,-0.4008319,-1.1403344,0.5468474,-0.01981086,-1.3630168,0.35698247,-0.9050578,-0.21410339,0.30161628,-0.45732066,0.08701964,-0.08614878,-1.4967817,1.1154755,0.6433373,-1.5769767,0.1627804,1.086964,0.9270488,-0.4788198,-0.012134891,-0.4718651,-0.5747156,1.1374803,0.73308736,0.47013772,0.68640834,0.5414811,0.3423115,0.17469908,0.778525,-0.12218908,-0.15332483,0.025583416,-1.4497938,0.9737326,-1.0149674,-0.5509801,0.3225065,0.18992811,-1.0764872,-2.4994223,0.7578993,2.1642025,-0.29459482,1.1524408,-0.05420081,-1.1191752,0.6515436,-0.34697607,0.47303784,0.14090982,0.56666267,-0.25767177,1.4345627,-1.0328491,0.86388963,0.028054291,-0.31245112,1.1154755,0.0044392133,0.2986577,-1.6648217,-0.86062735,-1.5104712,-0.92074627,-1.537241,1.3910619,-0.093892515,-0.200788,-0.28406513,0.10622342,1.0811582,0.6717566,1.9317665,-0.63021934,0.0062415972,-1.1026611,-0.18843822,-0.024923306,-0.2445944,0.012336791,1.1437824,-1.455623,-1.0712252,-0.61040205,-0.28553945,0.31057566,-0.96935123,0.9084616,0.24145529,0.5062788,0.7612831,0.7283468,0.89887846,-0.3956284,-0.4972625,-0.17131189,-0.90231454,0.18419679,2.463843,-1.1863352,-0.22915296,0.32849234,0.19955619,1.858848,1.7002176,0.19134392,-1.5595318,-0.37523964,-0.59672844,-0.18281934,-0.26656592,-1.5182816,-1.097953,0.7252898,0.13822907,0.27442446,-0.378413,-0.42138132,0.7941541,-0.9723197,0.33850077,-0.65220416,-0.508494,0.7441714,0.66063166,-0.123743914,-1.485983,0.14936405,0.22244984,0.044503987,-0.33572996,-0.8714274,-0.30374184,0.25030115,-0.33073002,-1.5641333,-0.3074965,-0.26566613,-0.63774896,0.24865884,0.48321626,0.8081559,-0.3547888,-0.48145586,-0.072824866,0.81276864,-0.46587655,-0.3452559,-0.38020164,1.0590243,0.47391355,-0.049730733,-0.24744184,-1.3939358,-0.81246084,-0.15469554,0.18119584,-0.8515431,-0.42725784,0.5408052,-1.6544973,0.29255134,0.46269524,0.5031295,0.73498917,0.30145437,-0.14148138,0.67477983,1.6041356,0.26731914,0.38145128,-0.018892886,-0.95081735,0.730805,-0.2865764,-1.1128157,-0.10050264,-0.077247545,0.09941499,-0.19322234,-1.2782671,-0.64051014,0.59767735,0.055885706,0.53458136,1.2334689,-0.23556764,-0.41766545,0.97056043,0.11129893,1.2621685,-0.74651074,-0.18039289,-1.5730429,0.032143824,-0.03734052,-0.63860387,1.1212333,-0.32780248,-0.25678653,0.79906243,-0.7835143,-0.11225054,0.8145663,0.28522715,-0.444098,0.3333494,-0.4193683,-0.24419852,-0.2853852,-0.612379,0.19169585,-0.07684031,0.32182196,0.37915573,0.8822427,0.22810753,0.30856526,-0.7439109,-0.28613573,-0.95159394,-0.40019092,-0.756135,0.55359447,-0.5167238,0.54120463,0.67499775,0.7891309,-0.46157864,-0.04592953,0.6181623,-0.68259597,0.376103,-0.09072116,-0.16589905,0.35054174,1.0212672,-0.3980198,-0.58308357,-0.7114543,-0.44242555,-0.18301034,-0.065594345,0.6207152,-0.2151707,2.087174,-0.4631398,0.20305963,2.6092374,0.4621458,-0.22847086,0.9089157,-0.10871632,-0.5172524,-0.41015688,-0.37539172,-0.78664553,-0.16278769,0.8408572,-1.215038,-1.0488135,0.007348817,-1.1361498,-0.7125748,-0.66558737,-0.09138868,-0.10885827,-0.75132996,0.8366089,-0.60314894,0.4260915,0.3913014,0.8121383,-1.3555598,-2.2799876,1.2570629,0.448186,-0.07779601,-1.0031343,0.71051127,0.05710834,-1.7112981,1.636256,-0.9672122,0.6210685,-0.6069811,1.7425867,-1.042295,-0.33798426,-1.903072,-0.016054384,0.9008756,1.0942292,0.38721725,0.801855,0.14101242,0.58864534,-0.56533706,0.4530614,-0.4107787,0.59539753,-3.3886259,-0.09678436,0.7796808,0.6382787,-0.58545715,0.68811667,-1.5013963,-0.91322523,0.0435941,-0.750529,0.19762816,-0.14111769,0.52450085,-0.52363634,0.89285946,0.3871195,0.3044999,-0.4596852,-0.2661677,2.4856997,0.6771104,-0.31124088,-0.90116817,-0.8258361,0.1251473,-0.824739,-0.7893849,-0.0124177635,-1.070469,-0.28069884,-0.6619695,-1.8775078,-0.023067735,-0.3816497,0.62873536,0.4078113,-0.012853,0.11879386,0.481129,0.20144972,0.81159496,1.0664208,-1.5030806,0.7922754,-1.0180862,1.5176432,-0.92043495,0.16825598,-0.4067336,-0.49119347,0.36598405,0.2223838,0.31901503,0.38694736,0.2567046,0.5568862,0.4708804,0.45727274,0.91257,-0.21066457,0.19153462,-0.5985924,-1.6922982,-1.5012906,0.19860327,-0.1689121,-1.7664864,1.1195893,0.33219412,0.83574206,-0.23951253,1.128621,1.5986366,-0.33075246,0.58387405,0.54225063,0.6371453,-0.4962458,-0.712813,-1.2735775,-0.70107806,-0.114193656,1.7055782,0.39493215,0.12351225,0.80774987,-0.70699286,-1.6246963,-1.4478416,-0.2747648,-1.8847014,-0.20380215,-0.2763833,0.42880094,-0.33041656,0.38760597,-0.65045774,-0.47288632,0.38547793,-0.55586,-0.6830268,-1.4770486,-0.40547895,-0.23121403,-0.8059799,0.03910801,0.6396792,-0.31773052,0.9969367,0.31341633,-1.394462,1.2085627,-0.6887733,0.23162782,-0.51878506,0.22252843,0.3839733,1.1571342,0.561,1.2468632,0.839579,-1.5444605,0.75407064,-0.3963981,0.46520582,0.9876759,0.9791511,0.8478284,1.0420249,0.24877572,1.255366,-1.6993829,-0.48331794,-0.16656344,0.023376897,-0.06756851,-1.1481267,0.6916528,-0.606113,-0.32423452,0.15017259,-0.87822616,0.008285325,-1.286424,-0.8724627,-0.080893,0.10666853,0.42310753,-0.06487791,-0.3584011,0.2681349,-0.72960824,0.4439536,-0.041130506,-0.19030468,-0.051721975,0.5407041,0.7139402,0.8822535,0.8874052,-0.45907673,0.08982943,-0.87661916,-0.6449854,-1.4338012,1.7013083,-0.22217937,-0.29092383,0.29903376,0.11342032,1.1243744,0.65002,-0.40912613,-0.676025,0.4533865,-0.43605807,0.23107636,0.35797605,0.83761525,0.7446407,1.125553,0.6203227,-0.2890858,-0.30571574,0.5121305,2.520208,0.13096221,-0.40718535,1.8215917,-0.91136533,-0.56057733,-0.77710754,0.22452958,0.09425622,1.2191923,0.47335705,0.011578672,0.43073916,0.19254242,0.5534262,1.7482045,-0.06341339,0.19682676,-0.37252465,-1.0226684,-0.8615107,-0.30556595,0.2761905,-0.7483005,0.8681786,0.61086655,0.07874499,0.07951038,0.99642754,0.5789867,1.1549071,0.4575717,-0.78024083,0.18111205,0.3524469,0.55046564,-0.053807784,-0.49006927,0.06448611,0.0076410957,-0.25830698,-1.2542981,0.038218,-0.03752096,0.097056,-0.28527188,-0.05373988,0.15038194,0.30142215,0.3214552,0.14290942,0.7817242,0.43194252,-1.4077016,0.21550706,1.0867687,-0.36124536,-0.95624787,0.010868002]	2026-02-01 11:25:51.793125
2960f06c-ff9a-4d06-9ef7-92a9cc8e5959	9a521cb4-6c96-4d3f-bd1a-5a680a02dbf3	08f8df97-72e6-411a-8580-d0ae487accd4	clip	[0.37827224,-0.55878943,-2.4066222,0.21045509,-0.14933011,-0.10193455,0.20934342,1.5821074,1.2619444,0.94620943,0.17915092,-0.726728,-0.15395883,0.7673627,0.3454198,0.6836533,-0.26350114,-0.51150686,0.1955562,0.3692368,-0.67963445,1.1350275,-0.46875593,0.5761443,-0.79969496,-0.22370084,-0.76891226,-0.5242579,-0.20864834,1.080208,0.2612632,-0.22865787,0.4442628,0.6358742,0.7204345,-1.1039615,-1.0649765,-0.4107379,-1.2290187,-0.58035004,-0.23560973,-0.11581923,0.9574648,-1.5199755,-0.25499278,-1.0122824,-0.15157098,-0.49274227,-1.906855,-0.6895433,-0.25977296,0.84395564,0.74899435,-0.17604694,-0.73174226,-0.11531815,1.4041065,-0.8593933,-1.9069787,-0.33743414,-0.8015453,1.8671609,-0.3422264,-0.7902816,0.3121625,1.5124465,-0.17360815,1.3819253,-0.19445083,-1.4392049,0.2761219,-1.0447344,-0.99194306,-0.010024779,-1.3215212,0.26718462,-1.0912828,0.31677097,-0.026254449,0.309078,0.42327076,0.4105217,-0.124091916,-0.32537213,0.27405387,0.9557818,-0.25670624,1.8220578,-0.110875815,-0.63725084,-0.48575515,0.49009073,0.7314401,-0.2373648,-0.61779994,0.25969574,-0.64334226,-0.26041037,0.44221914,0.38453215,0.09186943,-0.030501762,0.0015836265,-0.12496441,-0.58536565,-0.55512804,0.11427669,1.5078559,0.2870552,-0.03386864,0.89765245,-0.17543383,0.27170372,0.09712868,0.12646274,-0.42223102,-0.97878736,-1.4051611,-0.28658897,0.42498025,-0.50197554,0.8562013,0.7898616,-0.54739195,-0.548267,-0.25498372,0.3880557,0.54151225,-0.65651613,-0.19891329,-0.5007749,-0.07766342,-0.49163342,-0.82695305,0.12975313,-0.99394226,0.76750773,1.0727458,0.24839252,-0.88903254,1.3995625,0.65755665,-0.44667447,-1.8237537,1.3807504,-0.23542824,-0.19229802,-0.9994046,0.41374967,-0.7821654,-0.84002274,-0.462984,0.2488806,-0.34801936,-0.1959364,-0.30952397,-0.073243886,1.1438973,-0.31360438,-0.27877676,0.20044735,0.57248384,-0.57219213,0.1078932,0.9445118,-0.24743745,0.75364107,1.2923912,-0.48308444,-0.76003075,0.38067278,-0.89531344,1.2524074,0.22997983,1.0349133,0.17290027,1.5840768,0.103049695,0.21759143,-0.6946428,-1.2691228,-0.66698074,0.07814786,-0.6249063,-0.792673,0.28679052,-1.245908,-0.051924963,-0.67477405,-0.909143,-1.2319579,-0.6418356,-0.11336346,-0.43270308,0.3168604,-0.048136033,-0.15625101,-1.3756844,0.682632,-2.034569,-0.41888294,0.803676,-0.081898294,-0.59187335,0.50439876,0.06021557,-1.7957058,0.2777341,0.94436914,-1.3860928,-0.12827463,0.6733961,0.2105929,-0.41497776,-1.0112823,0.40192118,0.65893924,1.3589584,0.6994131,0.29801103,0.8413159,-1.334694,0.7556618,-0.54177034,0.5304165,-0.17500755,1.1687406,0.7246984,-0.1814534,-0.5973762,-0.011576807,1.9563596,0.062497437,-0.57551575,0.521849,-0.40510973,0.07026463,0.565221,0.3717565,-0.9052098,-0.08141041,0.8520597,-0.7971133,-0.27178985,-0.18772161,0.36485517,0.47860837,-0.3944539,0.055866078,-0.69695246,0.60093904,0.57022566,-0.51687574,0.7008359,-0.060265742,1.0373262,0.713814,0.62400573,-0.36736718,0.31140238,-0.07485245,-0.71501666,1.880919,1.1853684,0.70952284,-0.40159252,0.6542284,0.09329556,-0.20237622,1.3573899,0.27750653,0.065748975,0.9143511,0.023293544,1.5684546,1.0503545,-0.24713252,-0.49035117,0.27693808,-0.9105157,0.32413644,-1.2088679,-0.25851667,0.06954608,0.49944955,-0.35416052,0.15694882,0.84516734,0.5362385,-0.82872593,0.71211976,0.4714333,0.8884562,-0.16745262,0.155167,0.24262118,0.16486587,-3.7753472,-0.6033815,0.90958536,-0.12196124,0.493395,-1.0315329,-1.4749969,-2.0997195,-0.31452826,0.33485496,-0.5133666,-0.43618315,-0.8659837,-0.57022357,0.11639325,0.6279095,-0.44752106,0.1778796,-0.40645972,-0.78109765,-0.06582581,-0.18044673,2.6332932,-0.70375437,-0.3507472,1.113001,-0.946104,-0.2163038,-0.4945328,-0.35442698,-0.75867736,0.4642071,-0.34332973,-0.20290175,-0.644807,-0.5115085,0.66855115,-0.7160194,-0.63279074,-0.24477758,-0.7430192,1.603235,-1.1208283,0.49450892,-0.54075754,-0.7410978,0.14778218,0.19475777,-0.110959664,-1.2452074,0.07949888,0.7364949,-1.1192416,-0.22227788,-1.8020203,0.7531085,0.67711276,0.42679715,-0.116757244,-0.18959194,-0.033394396,-1.2870841,0.48920357,-0.10028772,-0.6792861,-0.9337323,0.6155536,-0.47947022,-0.13504317,-1.161051,1.8243349,-0.92951906,-0.09513582,0.7619627,1.8059747,1.0950892,-0.253282,-0.28146365,-0.11864598,-2.115566,0.45709935,-0.39537376,0.41595495,0.5242991,0.010190934,-0.5502781,0.21082142,-1.0011228,2.0018218,5.36785,1.4764178,0.67146033,-2.2683933,1.7786973,-0.84825385,0.113399625,-0.05764106,-0.13967507,-1.3314148,-0.0778302,0.4903236,-0.86898625,0.7266095,-1.2071774,0.9395542,-1.3656185,-0.027057767,1.077817,-0.5673918,-1.0954362,-0.49726948,0.60324,0.11211309,-1.0418049,0.49020422,-0.35639685,1.0341609,0.33337966,-0.3908894,-2.433529,-0.17866082,1.7386118,-1.2314255,1.1726624,-0.30985305,-0.6190171,0.21817593,0.0141588375,1.4229642,-0.26066476,-0.41483766,0.40957618,0.10238038,-1.0602967,-0.07046887,1.0217819,-0.06488755,-0.22933172,0.31298757,-0.35478514,-1.0334136,-0.517392,0.16908687,0.06631617,-0.774115,-0.9194948,-0.62946206,0.42440146,1.055088,0.13362153,0.45770115,-0.4731525,0.258867,0.59256136,-0.79237115,0.043606058,-0.7277583,-0.19494143,0.26094347,1.5854508,0.9063389,0.29917705,0.22759172,0.5052207,0.6087638,0.71429,0.8052822,0.42805034,0.1317962,-0.59710157,-0.18474855,0.07199324,1.2810885,1.0157624,1.0166994,0.0846619,0.7430037,2.4300468,-0.99516374,0.53489095,0.65812707,-0.75078785,-0.5214386,0.54617214,-1.2153572,0.34752348,-0.9815292,-0.23855251,-0.08193232,-0.13265096,0.17357473,-0.096486285,-0.9244596,0.58307946,0.4123597,-2.0063562,0.19385475,1.2688805,1.3425087,-1.2343855,-0.59222436,-0.5670339,0.19746798,1.0089782,-0.2680605,1.1943774,0.70133525,-0.44920918,0.35129517,1.001908,0.9630119,-0.051634483,0.5633659,-0.376252,-1.4316022,0.4682383,-0.78360045,-0.91610324,0.8952518,-0.29910058,-0.7751716,-3.0750794,0.9139174,1.5598729,0.14180748,1.1579266,-0.44449416,-1.0364566,0.29763898,-0.8873657,0.40006426,0.029141016,0.90388733,-0.08422613,1.4147002,-0.9686224,1.2694942,-0.24096413,-0.58122075,0.99173844,0.8150177,-0.14429446,-1.3026001,-1.1380237,-0.5963437,-0.5700591,-0.41684225,1.1517664,-0.026280379,0.32859793,0.009909101,0.0055928975,1.2570392,1.6103832,1.1056454,-0.046075676,1.1175171,-1.5102214,-0.48067996,0.20634389,0.11213566,-0.25652212,1.7422714,-0.1276564,-0.5945728,0.37967703,0.45928913,-0.14198482,-0.4733309,0.28452408,-0.478812,-0.4146714,0.4714566,1.0392804,0.5280248,-0.517645,0.11640687,0.6215603,-0.9017616,-0.12894136,2.5790055,-1.2583778,-0.620075,0.7710888,0.68502474,1.2177415,1.1070024,0.3758825,-1.2101897,-0.34118757,-0.48107088,-0.41146857,-0.46681434,-0.98604953,-0.8549552,1.0174507,0.6796889,-0.5251632,0.15771207,-0.7645953,0.14249009,-1.3554578,0.016112212,-0.98102117,-0.034005404,-0.037703153,1.143855,-0.7928548,-0.73062086,0.6038855,0.16732533,-0.36953944,-0.21668966,-1.0951502,-0.3827039,1.0542899,0.73711485,-1.4232063,-0.23234743,-0.329203,-0.8184576,-0.63126475,0.14827447,1.2425795,-0.2357016,-0.2116149,0.56529224,-0.12069756,0.4052957,-0.21397749,-0.35372943,1.0468667,0.69725895,-0.6401583,-0.033714376,-0.9347884,-1.0118868,0.45469707,1.1367615,0.27121145,-0.36141163,-0.020491906,-2.6054294,-0.39975947,-0.0021828786,0.17526138,0.531083,-0.42105243,0.25303766,-0.016130697,1.225506,0.61726165,0.9137013,-0.5503661,-1.7556969,0.22372243,-0.77710813,-0.107255846,-0.5864591,-0.00517961,0.5007341,-0.0176358,-1.2184656,-0.087255314,-0.18161225,-0.18064952,0.9537018,-0.43983746,-0.20534346,-1.1193758,0.96305037,-0.42423815,1.2331132,-0.66232204,-1.3196638,-0.67614555,0.33533403,-0.038277786,0.24475104,-0.037264913,-0.66477424,-0.35907158,0.7699754,0.25600997,-0.18128645,0.11986363,-0.048207812,-0.15547013,0.17332345,-0.46998218,-0.043066707,0.27532467,-0.066144705,-0.015244201,-1.1462109,0.7924974,0.77220935,0.112650454,-0.10818843,-0.53311646,0.17149842,-0.7898552,-0.24191937,-0.08610416,-1.3566253,-0.16204177,-0.70497006,0.26330817,0.39726612,0.8680571,0.15968275,-0.20173822,0.4489928,-1.237294,1.3828596,-0.5461633,-0.4518088,0.15071876,1.1438429,-0.5065236,0.21256071,-0.06568748,-0.7313914,0.2557035,0.07968424,0.8544513,-0.017407987,2.0549438,0.2723417,0.12200862,1.1853367,0.5987156,-0.067077786,0.35632864,0.1484626,0.014312696,-0.24838376,-0.38326824,-0.83055454,0.208985,0.5087859,-0.675341,-1.1060368,0.18891448,-0.27674314,0.15492041,-0.3107687,0.3739723,0.8926243,-1.4944034,0.88699174,0.069460236,0.18653774,-0.19894958,0.8079076,-0.48538426,-2.5343945,1.3880613,-0.34327203,0.7835782,-0.4022461,-0.013133049,0.39636764,-1.8963015,0.16650999,-0.76685286,0.14865357,0.06939723,0.6010706,-1.2653255,-0.43533242,-1.9331164,-0.49401626,0.6034242,-0.48891923,-0.5698963,0.79058045,0.7726481,0.16109978,-1.1039987,0.15105893,-0.9024132,-0.6543348,-3.217008,0.057260618,0.47598284,1.1443837,-0.6146189,0.45774198,-0.6325445,-1.1322783,-0.35543504,-1.0897039,-0.22590245,-0.54161876,0.60523134,-0.66977465,1.9157882,0.6846886,-0.22602539,-0.27046785,-0.29148796,2.091684,0.48798302,-0.5366237,-0.032695852,-0.31541932,-0.43346286,-0.3557297,-0.50796443,0.37478596,-0.5230221,-0.61290944,-0.28631765,-1.0069737,0.4776103,-0.18784046,0.68561095,1.1108211,0.3717674,0.45726198,0.3887796,0.16032787,-0.16061069,0.76494765,-1.3972524,0.34585956,-0.68801486,1.595317,-1.1897651,-0.40102774,-1.0391855,-0.5710978,-0.068883345,-0.19466707,0.13100642,0.9460844,-0.01648745,0.7107945,1.0654454,-0.12540579,0.7095715,-0.51005876,0.12443577,-0.08803426,-1.6849443,-1.0450577,0.023041654,0.28038782,-1.0977795,0.8440332,0.47746193,1.102709,-0.7674734,1.3206254,1.3648928,-1.0696787,0.55031884,0.7091535,0.39455375,-0.39726147,-1.1729168,-1.1438451,0.16861866,-0.23675098,1.1727095,0.21551643,0.07110701,0.59774816,-1.0283315,-1.4827915,-1.6631062,-0.63604546,-1.9012266,-0.59547955,-1.073576,0.15208636,-1.0071512,0.55762297,-0.8799176,-0.38604975,1.0380654,-0.9069482,-0.44431308,-1.4181491,0.09424063,-0.476614,-0.6138069,-0.15429129,-0.120458156,-0.16052765,0.5558689,-0.1807371,0.3159261,0.26654795,-0.35288817,0.49522996,-0.27646384,-0.009997509,-0.21664396,1.1438348,0.44530597,0.88028795,0.1624123,-0.03896221,0.4372011,-0.8863447,1.0299926,1.5020066,0.957629,-0.051473,1.1947136,1.0822338,1.0358893,-1.420945,-0.71594584,-0.115940616,-0.25017524,0.15934184,0.042918418,0.23554197,-0.82978004,-0.04543767,0.24876371,-1.6785945,-0.9763379,-1.5107161,-0.7296976,-0.7818236,0.08567012,0.28094098,0.61798066,-0.79297405,-0.6580504,-0.66421825,-0.44498882,-0.18462607,0.16115642,0.59496474,0.3541607,1.3451046,0.8177404,1.4042642,0.27625778,0.73648125,-1.2898725,-0.4941518,-1.151376,1.6634169,0.20673123,-0.76873237,1.0164893,-0.57431513,0.2106287,0.56108505,-0.28516275,-1.6469364,0.31850028,0.10812356,0.26439655,0.9999273,1.0148742,0.10620688,0.8964886,0.98201746,-0.9853462,0.11470176,0.17669857,2.350904,0.9136808,-0.3674425,2.4050193,-0.7503365,-0.6016348,-0.7492741,0.6895938,0.2691985,0.91836053,0.2660835,-0.25809097,-0.43964824,0.31207216,0.22405025,1.3103834,-0.28599167,-0.7913004,-0.4833341,-0.08130019,-0.13399547,-0.78174216,0.97966635,0.25769433,1.4540921,0.71467125,-0.46069863,-0.116729654,0.63523906,1.4576255,0.8641457,-0.39515814,-0.057479143,-0.20666555,0.81043863,0.9077771,-0.636233,-1.3353302,-0.10638692,-0.49519816,-0.41427556,-2.2172294,0.52551,-0.39655784,0.6763595,0.0013669431,-0.5863091,0.13492641,0.0296584,0.05256197,0.6040456,-0.07115762,0.63875777,-0.66757894,0.120589316,1.2417111,-0.12739772,-0.23193872,-0.3926273]	2026-02-01 11:25:57.131084
e523a68b-dd08-4a91-97f7-d665e8c6b776	d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	clip	[-0.83383197,-0.8039037,-2.5300007,0.11641769,0.024185888,0.39490378,0.72242767,0.55740124,0.69511855,-0.14751929,0.7039766,0.16084819,0.0958074,-0.07882947,0.6359097,0.22392574,-0.37092963,-1.3692521,0.01815714,0.35179725,-0.89629054,0.27009207,-0.02466255,0.25995934,-0.46219164,0.49285623,-0.37313426,-0.43641484,-1.0322063,0.34262487,0.105335504,-1.8535475,-0.14493857,0.29778948,0.37738898,-0.58981925,-1.0960907,-1.2961203,-1.3583726,-0.35869816,0.719788,0.36554646,1.1862947,-1.1008286,-1.3882354,-0.9433214,-1.0257871,-0.2920918,-1.9119098,-0.46374494,0.2536931,1.3234751,1.0237803,0.2296503,0.5168813,1.0940353,1.1431247,-0.8441754,-2.6419485,-0.18991895,-0.8692935,1.0161701,-0.15002118,-0.8958493,-0.15760955,2.054774,0.27654034,0.56893355,-0.38783774,-1.0713985,0.06997759,-0.040521972,-0.51468766,-1.0464,-1.271865,0.4956988,-0.64331615,0.31470108,-1.1682936,1.2643723,0.6874754,0.34222293,0.15128644,-0.48439872,0.16221797,1.0381598,-0.7594128,0.7615337,-0.45017776,-1.0045542,0.30817118,0.33577698,0.7309013,-0.40354937,-1.2340757,0.33358318,-0.7810877,-0.5301441,0.20789555,0.22931054,0.33427063,0.11273502,0.30047935,-0.1560968,0.051042587,0.47764516,1.6073861,0.7318939,1.2616559,-0.4082511,1.5140538,0.7515898,0.07532234,-0.522765,-0.1695412,0.5711095,-0.29410037,-1.3736193,-0.16018552,0.47234145,-0.6162611,0.31238088,0.5118176,-0.29291007,-0.1253219,-0.7569823,0.5036075,1.2952576,-0.20001453,0.07496631,-0.3731634,0.24659508,-1.1305997,-0.6146165,0.28940478,-0.53734815,0.61815095,1.0291516,0.5532085,-0.32126525,0.41938716,1.4181558,-0.72040194,-1.2837987,1.4708601,-1.1541386,-0.1430271,-0.71485704,0.37673113,0.08163883,-0.89082724,0.05025997,0.52160877,0.27342042,0.068462536,-0.7262634,0.6506192,0.6914246,-0.5974453,-0.6193927,1.1914219,0.011511937,-0.5287857,-0.08252318,0.8546779,-0.12319623,0.21471125,1.1341145,-0.69211006,-1.4300485,0.6216178,-0.6052216,1.022861,0.04825288,0.6514536,0.003984548,2.04113,0.47047096,0.7384652,-0.71709937,-1.9763697,0.38139397,0.45107287,-0.97955185,0.12358457,0.04972577,-1.4127316,0.01748509,-0.04671201,-0.85672146,-0.53559524,-0.6966153,1.0885527,-0.7404128,0.29079118,-0.39803237,1.1047279,-1.1747689,0.01215725,-0.99996114,-1.0164479,0.5337749,0.27263406,-1.0007582,0.5122269,-0.34768242,-1.1514821,0.5688021,0.581491,-0.895266,1.3608468,0.91883713,0.25868705,-1.2593366,-0.7692246,0.05810897,0.26379153,0.19998872,0.3315756,1.2045661,0.9381527,-0.26944298,0.208474,-0.3330711,0.11932728,0.9990933,0.7011823,1.3096471,0.04921384,-1.19851,-0.5443045,0.91482943,-1.0610088,0.24006888,0.6835116,0.4985453,-0.68408304,0.3739133,1.1379299,-0.90967166,-0.17605747,0.8506377,0.24913567,-0.4867067,-0.46537304,-0.98232377,0.551388,0.33061612,-0.4874981,0.12290873,0.21969265,-0.25260395,-0.708082,0.15415345,0.02761709,1.0671366,0.33674708,0.5273822,0.28574118,0.67919147,-0.54297394,-0.6375149,0.5712697,0.79670644,1.5993395,-0.21287912,-0.107841216,-0.4419042,0.32881662,1.6800556,0.5218066,0.15979484,0.44117394,-0.09746327,0.87950677,0.9252957,0.016013537,-0.24987626,0.41084477,-0.052037135,-0.050972022,-1.0048711,0.30784395,0.5216088,0.8946492,-0.26805806,-0.34238517,1.4325762,0.80689657,-0.65677255,0.32773313,1.9646301,0.7821242,-0.123801544,0.24155718,0.2710816,-0.21992141,-3.8738813,-0.19874354,-0.3911716,-0.09724834,0.8539315,-0.6673337,-0.66652375,-1.4702291,-0.7646908,-0.047001455,0.5708656,-0.75750357,-0.8614904,-0.15725727,1.1665211,0.9361377,-0.40555388,-0.055712763,0.22059216,-1.1710098,0.3378179,-0.53591764,3.4176004,-0.56843597,-0.50754046,0.6056799,0.25240207,-0.9752612,-0.78453773,0.5703425,0.05387381,-0.17453535,-0.47615945,0.3257618,-0.18392257,-0.39316127,-0.00602575,-0.6026401,0.24700066,-0.10740456,-0.010239318,0.5318207,-0.15590687,1.831963,-0.1993005,-0.5230733,-0.23698208,0.5604517,-1.2821081,-0.9542118,0.43044057,-0.064180866,-1.2142816,0.7555616,-1.404154,0.23522341,-0.5239964,0.6350823,-1.3612254,0.37963298,0.32921693,-1.0375183,0.41651407,-0.66117406,-1.0573434,-0.6432705,0.99301076,0.18490386,-0.18319619,-0.5528736,1.7233404,-1.4701229,0.7854296,0.04946109,1.3526064,1.0508167,-0.5651957,-0.6131775,-0.27372107,-2.9178238,0.56242967,-0.519341,0.7008367,-0.09828107,0.0938551,0.31120938,0.48844123,-0.5481127,1.8866911,5.76903,1.3947176,1.0617281,-1.2734429,0.90018165,-1.089594,-0.78217274,-1.0395789,-0.72920275,-0.7045141,-1.0950601,0.5929338,0.2690922,0.6118989,-1.1405432,1.0432941,-1.0817897,0.32423714,0.60761636,0.13220227,-0.8499651,-0.9634609,0.6708307,0.517482,-0.8910829,0.36513048,-0.30354637,1.2193019,0.8479803,0.12410584,-1.5702963,0.03023468,0.9167356,-1.172384,0.2722217,-0.9400173,-0.3908272,-0.4214317,-0.29804114,2.3785677,-0.31520024,-0.57527685,0.19730936,-0.8562417,0.21947846,-0.35467333,1.4144349,-0.37495917,-1.2544174,-0.240046,-0.5595404,-0.25261623,0.45149404,0.57349664,-0.19564037,-0.63154846,-0.21018931,-0.85046375,-0.5377081,0.2246938,0.4723825,0.35899565,-0.5357662,-0.18099305,-1.0172232,0.008061282,0.1081468,-1.759762,-0.61773115,-0.5859355,0.24808174,0.298096,0.8384812,0.8373242,0.21891677,0.5455785,0.13490266,0.8276513,0.9287252,0.83448195,-1.0359075,-0.17821129,0.16330642,0.16266812,0.47537905,0.323624,-0.27631485,0.85627985,2.433494,-1.0356948,0.78489256,0.79267836,-1.1680933,0.46913403,0.86259323,-1.4092675,-0.060477544,-0.49290502,-0.22580142,1.2125975,-0.89175546,-0.32166484,0.008205757,-0.7120644,0.648915,-1.0949444,-0.93591136,-0.7883361,1.5652447,0.84663874,-0.19959483,-0.026149932,0.4577725,-0.054940794,0.89559275,1.0508224,-0.21541558,0.5689169,0.79072225,0.68514806,0.20312554,0.36514628,0.5217822,0.21734723,-0.03646373,-1.2909436,1.4778571,0.08513177,-0.15557027,0.5709589,-0.402112,-0.8531593,-2.5663695,0.112841025,2.430237,-0.53670114,1.2864584,-0.37722948,-0.35886246,0.04644914,-0.4229028,1.0326283,0.5406188,1.1285913,-0.18828759,0.3619023,-1.0072709,0.7548852,0.5844806,-0.2722062,0.65275085,-0.0969139,-0.049816728,-0.9056948,-0.624053,-1.2126602,-0.42315623,-1.1408141,0.8410027,0.11135572,-0.4123324,0.03682951,-0.1598558,0.8454884,0.5114943,1.1836392,-1.2226903,0.54285234,-0.6461636,-0.23783366,-0.6711891,0.47812235,0.35791954,1.1151296,0.31772876,-0.41928357,0.28533435,-0.7846381,-0.19965288,-0.5369616,0.13064459,-0.5741618,-0.12867615,1.5412146,0.8045723,0.6240138,-0.7584827,-0.07258027,0.116672814,-0.38561863,-0.84993774,2.2745192,-0.78257525,-0.18007079,-0.703388,0.7914158,1.8411069,1.8155601,-0.37103754,-1.3876951,-0.2635398,-1.0792412,-0.71900594,-0.22378957,-1.1705412,-1.5308058,0.79569924,0.3914901,-0.07820314,-0.5888498,-0.41188604,0.612566,-1.7893627,0.08578295,-1.5854962,-1.0878965,0.02769485,0.44005096,-0.049774297,-1.0828545,0.35355356,0.82457775,0.7389467,-0.62137043,-0.34808314,-1.1788398,-0.57937753,-1.2544829,-1.1865634,-0.20098461,-0.13352925,-0.58337307,0.04767298,0.38604844,1.3902088,0.044073828,0.044842627,0.12742889,0.42789054,-0.06762573,0.011240799,-0.5284064,0.84949034,0.7508038,-0.4765506,-0.2685538,-0.4493936,-0.42400333,0.69568956,-0.36817038,-0.8027842,0.21430308,0.16208003,-1.8075628,-0.9449267,0.029866533,1.260629,-0.2966406,-1.4422501,0.93280405,0.23223868,1.7722254,0.23068112,-0.19538835,0.8012487,-0.06577395,1.1642033,-0.29139614,-0.40595916,-0.69229215,-1.0480597,-0.02301038,-0.2899212,-0.028744508,-0.21905853,0.014483772,-0.0068520084,0.37988254,1.7843046,-0.61202085,-0.13831566,1.2522327,-0.58863014,1.0841719,-0.7215434,-0.40163952,-1.2120879,0.901153,0.14289202,-1.2887653,0.057357274,-0.75735426,-1.1976907,0.044009227,-1.2694304,-0.42614496,-0.15342365,0.5446861,-0.3059616,0.32134846,-0.39068088,-0.2814057,-1.1199524,-0.48023912,-0.119179934,-0.8726141,0.5439688,-0.37860006,0.96774256,-0.9225027,0.09233351,-0.92854255,-0.5134725,-0.5373237,0.3620961,-1.0113466,0.22429228,-0.65583396,0.06498637,0.25034332,-0.11054479,-0.49496007,-0.21020451,0.2869766,-0.8505461,0.74836075,-0.75108707,0.20602563,0.2180714,0.37408966,0.17556113,-1.0074644,0.20880547,-0.25919965,0.43562788,0.46450204,1.2092611,-0.31315652,1.4627002,0.58566874,-0.041836493,1.1375525,0.9791353,0.40184262,0.78335637,0.06659403,-0.4193704,-0.044180512,-0.22818075,-0.66626614,-0.38746607,0.58240974,-0.6096129,-0.7307497,0.6685608,-0.8067289,-0.5564002,-0.31464118,1.3384122,-0.39120954,-0.80838156,1.1476914,-0.86270237,-0.32560587,0.6510945,1.144468,-0.7970744,-2.5792983,1.0506021,0.06027069,-0.15806863,0.21531254,0.3038762,0.50417185,-1.2734332,0.80365306,-1.2837536,0.26588386,-0.77714527,0.20357627,-1.0403836,-0.98548156,-1.193996,-0.27938995,0.79270065,-0.3306419,-0.12040723,0.76114136,-0.43367213,-0.20863777,-1.3897274,-0.09559868,-0.70403177,0.18824321,-3.6358206,0.19576977,0.28275856,1.3022405,-0.7532181,0.72162265,-1.3583573,-0.26760006,0.5949272,-0.41989392,-0.14164667,-0.64809304,0.2970572,-0.58225083,0.66526765,0.04312423,0.09028514,-0.16069038,0.2132668,1.6177069,0.47451788,-0.15013626,-0.30835465,-0.33188313,-0.23217377,-0.51903033,0.36847714,0.040125504,-0.73504835,0.09342988,0.46237743,-2.0764475,-0.023096368,-0.5403733,0.6611474,0.24300194,-0.19934905,0.43767,1.3147081,0.44875586,0.9292495,0.45191643,-0.9913404,-0.67308295,-0.63067335,1.2543058,-0.9816196,-0.4965142,-0.6256054,-0.0024194382,-0.31479096,-0.6380667,-0.56208724,1.4029092,1.1831212,0.59502727,0.46028626,0.8987672,0.22838065,0.38389763,-0.12358216,-0.39515343,-0.43174797,-0.48096085,-0.124235764,-0.48708257,-2.4323788,0.11352441,0.12401722,1.6441952,-0.21920483,0.13158134,1.0171444,-0.6151996,-0.107677996,1.3797922,-0.03233008,-0.20682913,-0.432544,-0.850635,-0.19454375,0.46587983,-0.016673535,-0.18465725,-1.6190896,0.17949584,-1.1357223,-1.012857,-1.9826245,-0.6897469,-1.325437,-0.30096635,-0.24355453,0.7483263,-1.250282,0.7078048,-0.92523694,-0.7512496,-0.669197,-0.26530647,-0.32847825,-2.1780164,0.33679453,-0.34349334,-1.0081782,-0.27379376,0.5136135,-0.08498689,0.4963705,1.47562,-1.0811872,0.51729894,0.22515401,0.34641644,-0.4674426,-0.74931216,1.0109677,0.77422816,0.13397646,1.7731962,0.439888,0.08611362,1.303482,-0.9361313,0.43289283,1.0504929,0.740994,1.5959146,-0.0071135294,0.75970703,0.9567794,-0.5832499,-0.33688742,0.2337937,0.32900816,-0.104904026,0.04963524,0.35538125,-0.60206634,-0.6208026,0.8297774,-0.29718417,-0.41539314,-1.1307446,-1.1212814,0.12816553,-0.39721408,-0.76625043,-0.9244165,-0.25157928,0.27688253,0.33894747,0.5224868,0.5776298,-0.10320058,0.33077338,0.32210442,-0.24503969,0.581706,0.6846797,-1.0372077,0.37743664,-0.4886077,-0.7733748,-0.5863409,0.87630314,-0.74625397,-0.6662394,-0.57851046,0.35146296,0.39769414,0.6102239,-0.1557555,-0.42504674,1.1808013,0.1940324,-0.37366667,0.63869953,-0.23028444,0.44508085,0.4451122,0.08388232,-0.579545,0.6070939,0.47583866,1.7399279,0.7469469,-0.48495993,1.305983,-0.23854811,-0.027019864,-0.7886025,-0.05222117,0.04034707,1.6049486,-0.76865655,-0.19551492,0.9957546,0.27155375,0.6547615,1.6527685,-0.43229347,-0.63226104,-0.6775541,0.5493154,-1.5861112,0.07260961,0.47287345,-0.088005975,1.1132188,0.21831009,-0.33421054,-0.39406976,1.0998971,0.33209646,0.8180046,-0.498975,-1.1382215,0.500715,1.3223056,-0.42904204,0.80880964,0.4554869,0.111883596,0.17035742,-0.016073547,-1.0798737,0.9360561,-0.21734788,-0.04246762,-0.7816783,-0.95257103,0.22296631,0.58179295,0.5261347,0.5931654,0.07000006,0.28540742,-1.5383084,-0.072409436,0.8325172,1.0317655,-0.06870057,0.26376945]	2026-02-01 11:26:02.514516
\.


--
-- Data for Name: face_clusters; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.face_clusters (id, user_id, encrypted_name, relationship, photo_count, centroid, created_at, updated_at) FROM stdin;
09331b02-ba3a-4b80-9e60-ae81095b9785	71e1a917-d78e-4c3f-99d8-7df652b5c68b	encrypted_name_1	family	12	\N	2026-02-05 10:06:27.700498	2026-02-05 10:06:27.700498
e0cccf7b-40f3-4fb9-960b-d02fb7ab46a4	71e1a917-d78e-4c3f-99d8-7df652b5c68b	encrypted_name_2	friend	8	\N	2026-02-05 10:06:27.700498	2026-02-05 10:06:27.700498
1727308a-5af9-4cdc-8efd-1c2a12225392	71e1a917-d78e-4c3f-99d8-7df652b5c68b	encrypted_name_3	colleague	5	\N	2026-02-05 10:06:27.700498	2026-02-05 10:06:27.700498
\.


--
-- Data for Name: faces; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.faces (id, item_id, user_id, cluster_id, bbox_x, bbox_y, bbox_width, bbox_height, embedding, detection_confidence, created_at) FROM stdin;
a3334927-7f16-49ad-b9f1-be766a67c68e	0c0920ff-5e11-4ace-886c-0f4228749ec4	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.4719470143318176	0.20654648542404175	0.18180698156356812	0.13637852668762207	\N	0.9222094416618347	2026-02-01 11:25:09.663983
e700c8c7-1e29-461d-933c-4c9786289818	0c0920ff-5e11-4ace-886c-0f4228749ec4	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.2541566491127014	0.26062121987342834	0.14513665437698364	0.10886815190315247	\N	0.8336778879165649	2026-02-01 11:25:09.664885
0d0b5dd3-d218-4257-adb3-f8cc2eeec73a	49833632-082e-43c9-8ba5-a6b32d1600fb	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.5141909122467041	0.2549239993095398	0.23118728399276733	0.1733582615852356	\N	0.887686014175415	2026-02-01 11:25:15.414675
e2441dac-b695-42ab-bfb8-773265aaf2a6	78154705-8d87-493a-a684-618d5c73269e	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.240953728556633	0.22301742434501648	0.2343505173921585	0.17572659254074097	\N	0.7406436800956726	2026-02-01 11:25:20.888173
8ae0f8b3-ce6f-4851-9865-05b43f5f1197	d3d05a46-f61b-4bf5-97ff-f0f96114a21b	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.4661928713321686	0.23089870810508728	0.1996718943119049	0.3002925217151642	\N	0.9283572435379028	2026-02-01 11:25:27.768175
d6f2b697-224f-4742-9bb9-cdf9db5fbd82	d3d05a46-f61b-4bf5-97ff-f0f96114a21b	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.31169262528419495	0.17415514588356018	0.19723597168922424	0.29653215408325195	\N	0.8858068585395813	2026-02-01 11:25:27.768801
2d515118-693b-4a5a-9dcd-e7904f45ba8c	06ebd867-87c1-4f46-9ed7-0c8fe8c876b6	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.44670313596725464	0.2108629047870636	0.10418778657913208	0.07811826467514038	\N	0.7899028658866882	2026-02-01 11:25:34.070971
4f015cdd-829e-4f7d-a4e6-63259fd27158	f9c9b1a2-8172-47cf-adf8-2128ad1ba885	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.37981027364730835	0.2834383249282837	0.257570743560791	0.1931138038635254	\N	0.9337239861488342	2026-02-01 11:25:38.822709
d022c131-fb30-473b-98f4-8edc9e5b12c8	bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.14442402124404907	0.3643238842487335	0.22330781817436218	0.16747304797172546	\N	0.9216200709342957	2026-02-01 11:25:43.832595
f6cf8522-c3bd-4500-821b-b37a06c67b8b	bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.5719153881072998	0.3976689279079437	0.279762864112854	0.20979425311088562	\N	0.7875725030899048	2026-02-01 11:25:43.833121
83f35459-b81b-4386-9fd8-1fbdae924e70	bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.3980158269405365	0.3561580777168274	0.09968340396881104	0.07476872205734253	\N	0.6081299781799316	2026-02-01 11:25:43.833531
2f1694c7-c1f2-4308-b5c2-f2f0bc43affb	2688d0dd-cf73-48d5-9081-d721c08a8e59	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.240953728556633	0.22301742434501648	0.2343505173921585	0.17572659254074097	\N	0.7406436800956726	2026-02-01 11:25:51.795409
95f225bb-8523-437c-8a85-b19df107d175	9a521cb4-6c96-4d3f-bd1a-5a680a02dbf3	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.4719470143318176	0.20654648542404175	0.18180698156356812	0.13637852668762207	\N	0.9222094416618347	2026-02-01 11:25:57.132665
286a42ba-20f6-42fc-a5c5-ba252c8a945a	9a521cb4-6c96-4d3f-bd1a-5a680a02dbf3	08f8df97-72e6-411a-8580-d0ae487accd4	\N	0.2541566491127014	0.26062121987342834	0.14513665437698364	0.10886815190315247	\N	0.8336778879165649	2026-02-01 11:25:57.133303
d54dbebe-7d6f-4889-ac41-da647c6c470d	d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	\N	0.14442402124404907	0.3643238842487335	0.22330781817436218	0.16747304797172546	\N	0.9216200709342957	2026-02-01 11:26:02.517188
c98586de-528c-48a2-9c86-8ec2b5e0e2f0	d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	\N	0.5719153881072998	0.3976689279079437	0.279762864112854	0.20979425311088562	\N	0.7875725030899048	2026-02-01 11:26:02.517748
7b3e9ca3-553c-4b7d-8654-61a8d50df6e2	d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	\N	0.3980158269405365	0.3561580777168274	0.09968340396881104	0.07476872205734253	\N	0.6081299781799316	2026-02-01 11:26:02.518165
\.


--
-- Data for Name: import_connections; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_connections (id, user_id, provider, access_token, refresh_token, token_expires_at, credentials, files_imported, bytes_imported, last_sync, created_at, updated_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: import_history; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_history (id, user_id, provider, source_id, source_hash, vault_item_id, imported_at) FROM stdin;
\.


--
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_jobs (id, user_id, provider, paths, include_shared, preserve_folders, delete_after_import, status, total_files, imported_files, failed_files, total_bytes, imported_bytes, current_file, errors, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: item_places; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.item_places (id, item_id, cluster_id, latitude, longitude, created_at) FROM stdin;
\.


--
-- Data for Name: item_versions; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.item_versions (id, item_id, version_number, storage_key, file_size, encrypted_metadata, created_by, created_at, change_type, change_note) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.notifications (id, user_id, type, title, message, data, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
8eb3c947-93c1-47b3-9662-42a6faeef7dd	66c4567d-3e08-43e3-9a8f-4e57acc56f0e	QbNbk1SOjyOK8ybA3pULNUFdL8Ac2ZOWfW1FfhBcpec	2026-02-03 11:06:41.492391	2026-02-03 10:06:41.492442
\.


--
-- Data for Name: place_clusters; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.place_clusters (id, user_id, encrypted_name, place_type, latitude, longitude, radius_meters, city, country, photo_count, created_at, updated_at) FROM stdin;
3d43de93-2fa3-44e8-95b6-b83de1e83c81	71e1a917-d78e-4c3f-99d8-7df652b5c68b	Home	\N	48.7758	9.1829	100	\N	\N	45	2026-02-05 10:06:27.703638	2026-02-05 10:06:27.703638
4d362a73-e69e-4309-82d5-eeef27a6f17b	71e1a917-d78e-4c3f-99d8-7df652b5c68b	Office	\N	48.7833	9.1803	100	\N	\N	23	2026-02-05 10:06:27.703638	2026-02-05 10:06:27.703638
20bad4f1-31fb-4d8d-b334-ff260f7e9f8d	71e1a917-d78e-4c3f-99d8-7df652b5c68b	Vacation Italy	\N	43.7696	11.2558	100	\N	\N	18	2026-02-05 10:06:27.703638	2026-02-05 10:06:27.703638
51cb0dad-0329-4364-815e-4d64fe44a4cb	71e1a917-d78e-4c3f-99d8-7df652b5c68b	Beach	\N	43.3183	16.4325	100	\N	\N	12	2026-02-05 10:06:27.703638	2026-02-05 10:06:27.703638
\.


--
-- Data for Name: processing_queue; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.processing_queue (id, item_id, user_id, task_type, priority, status, attempts, max_attempts, error_message, created_at, started_at, completed_at) FROM stdin;
704993c0-08c1-480b-833c-74b0d893da2e	2688d0dd-cf73-48d5-9081-d721c08a8e59	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 11:15:50.499149	2026-02-01 11:25:46.103712	2026-02-01 11:25:51.796682
50e458d1-e295-48cc-a0b6-c036a4a67891	9a521cb4-6c96-4d3f-bd1a-5a680a02dbf3	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 11:15:50.887266	2026-02-01 11:25:51.797364	2026-02-01 11:25:57.13469
ccb1ae93-a095-4dfa-b58c-d7fb5b8ff5a7	d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	full_process	5	complete	1	3	Processing failed	2026-02-01 11:19:58.719213	2026-02-01 11:25:57.135372	2026-02-01 11:26:02.519234
af07669b-e4d0-4721-ae75-dc56343eee34	e3386dd5-71a4-4fe3-856f-cec908a3c7cd	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	failed	2	3	Processing failed	2026-02-01 08:16:24.015865	2026-02-01 11:24:46.797907	\N
013827f6-d7d9-49d0-9221-93aed0536be5	0c0920ff-5e11-4ace-886c-0f4228749ec4	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	2	3	Processing failed	2026-02-01 09:01:16.52185	2026-02-01 11:25:06.246477	2026-02-01 11:25:09.666543
7d16d8ea-c9df-45f1-a7fa-d59551fd788d	960c32a6-8bc0-4451-a3f8-e152115d79a7	bf8d4061-9334-4832-9ab2-323ab6b1c32a	full_process	5	failed	3	3	Processing failed	2026-02-03 22:20:56.122051	2026-02-03 22:20:56.320441	\N
3044c63c-8122-42da-a9dd-8f4dadfe621e	2d73ad13-87c6-4e1a-8f31-50bf1d770931	4ce083a9-4f18-45e3-ae08-710c2f0a44ef	full_process	5	failed	3	3	Processing failed	2026-02-03 09:40:42.743118	2026-02-03 09:40:44.414359	\N
cc398f8c-35e4-44f1-9572-c36de6a847cf	38c37c07-2625-4405-8f37-088c7a5f7419	7d5fb337-a497-43cb-a4c8-784c6b71658e	full_process	5	failed	3	3	Processing failed	2026-02-05 02:43:54.212065	2026-02-05 02:43:58.734913	\N
0147cc8c-4f97-4af8-8d1b-684e58088df7	67337173-c022-4b64-b9af-b74b6215106d	85417bbf-64e0-40d2-b75c-6c52bdd9120e	full_process	5	failed	3	3	Processing failed	2026-02-03 22:21:57.832558	2026-02-03 22:22:01.491007	\N
66620c2e-7760-4dd7-a8fa-34ac08fc97f4	7bfc4b8b-e487-4f90-a27a-13122a9428cc	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	full_process	5	failed	3	3	Processing failed	2026-02-03 14:21:11.70091	2026-02-03 14:21:13.575256	\N
5b0322bd-7a6d-4b4c-a6b8-a76d25cafa5f	7d47bfa1-a979-47b6-ba7c-b90909d7b16e	7d5fb337-a497-43cb-a4c8-784c6b71658e	full_process	5	failed	3	3	Processing failed	2026-02-05 02:43:54.728967	2026-02-05 02:43:58.750917	\N
ebeade1c-a8a0-491b-a9d2-40bdd480b702	49833632-082e-43c9-8ba5-a6b32d1600fb	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:16.873252	2026-02-01 11:25:09.66726	2026-02-01 11:25:15.416034
0af8a805-598d-41a8-be56-a4bf281c459f	c5017a61-2e4a-4559-b132-f9e307b068fe	32ecef26-dae9-4324-bc94-b27445211f69	full_process	5	failed	3	3	Processing failed	2026-02-03 22:29:43.217922	2026-02-03 22:29:47.089636	\N
12fe3032-b100-43a4-b0bd-3ae61c6cf8d4	99b532d3-e7f6-4cee-8d38-b41b8e45b749	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	full_process	5	failed	3	3	Processing failed	2026-02-03 14:21:23.903861	2026-02-03 14:21:28.639388	\N
c475ae2f-7885-40c2-baae-c7620c0ce2c2	a7242b12-ba7e-4798-9063-ccc74a586573	7d5fb337-a497-43cb-a4c8-784c6b71658e	full_process	5	failed	3	3	Processing failed	2026-02-05 02:43:55.290577	2026-02-05 02:43:58.767133	\N
62ebcd03-4335-4469-b3e1-1d3370327476	62a22d49-8e12-40cf-85d6-19fd7d11d68f	71b2b955-e4e5-49a0-99b6-b54cd8372e8b	full_process	5	failed	3	3	Processing failed	2026-02-03 22:30:14.226246	2026-02-03 22:30:17.154345	\N
eff31985-561a-4abb-b3d4-5d9355684c7a	d93f26c1-41de-4eba-aab4-72e24e1c5bb6	6d1d217c-59b1-40f8-a716-a36c2b69aaf5	full_process	5	failed	3	3	Processing failed	2026-02-03 23:34:10.049953	2026-02-03 23:34:11.54405	\N
0a0274ba-e980-4a24-8234-014a2ff5ca38	43ce2a5f-245d-4913-9ea4-db1e110f27cc	f7ac2bc6-f57d-444d-ad14-759d78a1b46e	full_process	5	failed	3	3	Processing failed	2026-02-03 23:34:21.367345	2026-02-03 23:34:21.59701	\N
84ebfb24-f89a-42c9-853e-4dd1856a0d30	78154705-8d87-493a-a684-618d5c73269e	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:16.188432	2026-02-01 11:25:15.64097	2026-02-01 11:25:20.889398
714fabc6-c8a6-4484-9955-157936a98d9f	d3d05a46-f61b-4bf5-97ff-f0f96114a21b	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:17.200325	2026-02-01 11:25:20.89011	2026-02-01 11:25:27.770225
f71dd3bd-2843-4b38-9ae2-9671e057494b	06ebd867-87c1-4f46-9ed7-0c8fe8c876b6	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:17.685846	2026-02-01 11:25:27.771032	2026-02-01 11:25:34.072714
c8524a34-d9aa-45f1-8807-b563c26e2754	f9c9b1a2-8172-47cf-adf8-2128ad1ba885	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:18.027461	2026-02-01 11:25:34.073446	2026-02-01 11:25:38.824187
60bbed57-dd8d-4845-8c36-6870d0d273f3	bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:18.366913	2026-02-01 11:25:38.824885	2026-02-01 11:25:43.834696
ec3dd76f-02ad-4057-9e4f-2eb50bb304ac	674a68b7-262f-42ac-9fd9-c009955f5686	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:24.336697	2026-02-01 11:25:43.835486	2026-02-01 11:25:44.396926
5f7bd4b3-d7f8-4acc-a8e9-b43413b0e394	022850ac-9d73-4bcb-8e16-89df8c0fa1c7	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:30.840229	2026-02-01 11:25:44.397775	2026-02-01 11:25:44.766583
703d4ba6-8e6f-4f47-9744-83fad61f01d4	f15abd00-7091-475c-b3e2-5c52d051bc48	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:31.078034	2026-02-01 11:25:44.767443	2026-02-01 11:25:45.353981
155216d4-228c-4002-889e-73a590367b11	1f1f7367-7982-43c0-9849-3849b919f9c6	66c4567d-3e08-43e3-9a8f-4e57acc56f0e	full_process	5	failed	3	3	Processing failed	2026-02-03 10:02:42.918136	2026-02-03 10:02:45.926262	\N
6cf4e021-31d7-4a6a-a12d-bc121f5b2a67	3f8c6cbc-1e97-41c0-8a2c-48b4e4a071b3	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:31.433557	2026-02-01 11:25:45.354988	2026-02-01 11:25:45.708597
685c367f-3e54-49bf-8751-a653cfed59a3	c0d02ee3-feb2-4dbd-9422-55002a368b8a	7eee445a-1fea-4a89-ab25-9f8b8613fa89	full_process	5	failed	3	3	Processing failed	2026-02-03 22:21:15.941054	2026-02-03 22:21:16.39079	\N
b5d6224e-2c2b-4ce0-9f34-cc7ccfb58b20	e6f8c74e-c839-4bea-b45d-aadd468c45f6	08f8df97-72e6-411a-8580-d0ae487accd4	full_process	5	complete	1	3	Processing failed	2026-02-01 09:01:31.601264	2026-02-01 11:25:45.709291	2026-02-01 11:25:46.10278
fe8ddf7a-f875-4622-9aa2-d4f43d00b741	7142c7d3-bb63-4bc8-9dd4-ea633ade7db9	57f22b83-44c9-4e26-8afb-ab9bada3b8c5	full_process	5	failed	3	3	Processing failed	2026-02-03 15:24:58.300134	2026-02-03 15:25:03.015309	\N
7df28761-c88f-4c31-ac44-9c2e111e8121	889c36e4-1543-4aea-8fce-693a6c2dc350	9bdd08b1-72e3-42a4-97d8-37b76dad26cd	full_process	5	failed	3	3	Processing failed	2026-02-03 22:23:01.819132	2026-02-03 22:23:06.591297	\N
5ac5e682-81d5-4a0d-9aca-ceb2d4124315	0f18de26-5f93-4fd3-a111-223f83cb2a4b	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c	full_process	5	failed	3	3	Processing failed	2026-02-03 15:25:21.800121	2026-02-03 15:25:23.082225	\N
7ffc8280-cce5-49a6-8416-c94c788cdd7d	4d8d3381-4627-4863-8968-884376a9caaf	b3bf0cea-478c-434e-929d-23edbddf3539	full_process	5	failed	3	3	Processing failed	2026-02-03 22:30:31.60472	2026-02-03 22:30:32.206859	\N
af19f5a5-56cb-45cf-a0dc-581c39fcd44f	2cabfbfb-f48a-49a2-8974-a15f2baab707	e1dad1fd-a1b5-4f56-9571-6aaa183d4285	full_process	5	failed	3	3	Processing failed	2026-02-03 22:30:52.617309	2026-02-03 22:30:57.282373	\N
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.rate_limits (id, key, requests, window_start) FROM stdin;
\.


--
-- Data for Name: share_links; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.share_links (id, user_id, share_token, item_id, album_id, encrypted_password, expires_at, max_downloads, download_count, allow_download, allow_preview, encrypted_message, created_at, last_accessed_at, revoked_at) FROM stdin;
959d1633-bf4a-4039-a466-e1f6a4fe660e	94ff25b3-0399-477f-b460-0dcda844f143	cwhZTVqXL8hbATPF6b_y-3Cp6p33FXKTmfzyM-fs_tU	\N	adc5b95b-bf2b-4685-8040-4f1f5b5b8ede	\N	2026-02-04 01:55:52.324586+00	\N	1	t	t	\N	2026-02-03 01:55:52.324665+00	2026-02-03 01:56:23.849869+00	\N
1ae529a1-dc20-4b31-9554-bc3007bd487c	53e3e0f5-7b76-40e5-97da-36b44892adeb	smfcSFsbU3eBC2hwC9WPjO8nHMQeVtTxDWcaLilk8ZM	\N	a25191c0-077f-4276-b16e-4baec7dc8477	\N	\N	\N	1	t	t	\N	2026-02-03 22:29:58.980012+00	2026-02-03 22:30:13.863443+00	\N
\.


--
-- Data for Name: shares; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.shares (id, item_id, user_id, share_token, expires_at, max_views, view_count, burn_after_view, created_at, last_accessed) FROM stdin;
\.


--
-- Data for Name: storage_access_log; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_access_log (id, bucket_name, object_key, operation, status_code, bytes_transferred, client_ip, user_agent, request_id, duration_ms, created_at) FROM stdin;
080cf769-0f3e-4bf8-8d2c-1426ce4534e8	vault	test/hello.txt	PUT	200	20	10.21.12.8	curl/8.7.1	\N	11	2026-02-03 01:50:30.387009+00
bd245fa6-421b-4819-82c0-a4d53b610522	vault	test/hello.txt	GET	200	20	10.21.12.8	curl/8.7.1	\N	1	2026-02-03 01:50:30.600724+00
5de6c856-317a-4ad4-a792-6dda272933ee	vault	4ce083a9-4f18-45e3-ae08-710c2f0a44ef/91bbf109-8cb6-4a27-938c-7c0199576076/file.png	PUT	200	19	192.168.145.10	curl/7.81.0	\N	45	2026-02-03 09:40:42.820938+00
bb3515e1-fbc9-4267-97ca-00111f8fb7eb	vault	66c4567d-3e08-43e3-9a8f-4e57acc56f0e/2ddd5bf2-171c-4462-bc01-5e66337cb0ac/file.jpeg	PUT	200	19	192.168.145.10	curl/7.81.0	\N	43	2026-02-03 10:02:51.573506+00
a16323e6-e323-4fd3-9628-ff6e847e6959	vault	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e/8ea6a0da-9109-4c02-9319-e822651ce741/file.plain	PUT	200	32	192.168.145.10	curl/7.81.0	\N	21	2026-02-03 14:21:23.97349+00
8541bc06-d6c9-4871-857c-404f320e3ce9	vault	57f22b83-44c9-4e26-8afb-ab9bada3b8c5/c372109d-8534-4441-9f91-2791ca5d3dd4/file.plain	PUT	200	75	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	46	2026-02-03 15:25:08.87619+00
e08edb2c-a9f3-4b70-9f1c-210779cae9cf	vault	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c/7a2c7e38-9e98-426c-95f9-804f1c5042ca/file.plain	PUT	200	62	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	6	2026-02-03 15:25:21.909577+00
42a75618-ba9a-4d21-9ab5-63e20c2830f2	vault	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c/7a2c7e38-9e98-426c-95f9-804f1c5042ca/file.plain	GET	200	62	10.21.12.8	curl/8.7.1	\N	2	2026-02-03 15:25:22.189716+00
78f30d34-842d-417b-ab89-9db59f7d8b60	vault	32ecef26-dae9-4324-bc94-b27445211f69/be6b11b5-cac7-420d-8dd4-f9e23c3d1c1d/file.jpeg	PUT	200	36	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	44	2026-02-03 22:29:43.362503+00
a4c82610-f622-4a0f-8fd3-b37316550fa1	vault	71b2b955-e4e5-49a0-99b6-b54cd8372e8b/5431f662-e115-4d89-a080-c40ade08ff4c/file.octet-stream	PUT	200	10485760	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	274	2026-02-03 22:30:14.648308+00
b7b98d68-12f8-4344-a440-b99b420f6ce6	vault	b3bf0cea-478c-434e-929d-23edbddf3539/a88ff194-3487-40a0-b167-d27c7e0a1c86/file.mp4	PUT	200	104857600	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	2392	2026-02-03 22:30:34.182709+00
5f0253f7-23a4-41db-a25c-311e7f219d85	vault	e1dad1fd-a1b5-4f56-9571-6aaa183d4285/3f3686ee-add9-4f0a-82ab-e1089a43229b/file.octet-stream	PUT	200	52428800	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	1276	2026-02-03 22:30:54.030041+00
bc68b079-fbce-4b1a-88d4-b0dd4358b03f	vault	e1dad1fd-a1b5-4f56-9571-6aaa183d4285/3f3686ee-add9-4f0a-82ab-e1089a43229b/file.octet-stream	GET	200	52428800	2001:bc8:701:609:1a4a:53ff:fe05:85c5	curl/8.7.1	\N	1	2026-02-03 22:30:54.18828+00
5288a3ad-bce6-42d8-8010-8295407a4000	vault	7d5fb337-a497-43cb-a4c8-784c6b71658e/b9835d7e-316f-44ba-bdb0-04c1d3d4876a/file.jpeg	PUT	200	2588067	2001:bc8:701:604:1a4a:53ff:fe0a:f3ee	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	\N	282	2026-02-05 02:43:54.693161+00
3fb819e5-38ec-4fa4-b485-53f689418d64	vault	7d5fb337-a497-43cb-a4c8-784c6b71658e/7c18dd23-76a0-4555-b11b-a10969b0ae6b/file.jpeg	PUT	200	6256895	2001:bc8:701:604:1a4a:53ff:fe0a:f3ee	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	\N	413	2026-02-05 02:43:55.256082+00
cc51ec5b-c86a-44ee-bb49-430e232a11df	vault	7d5fb337-a497-43cb-a4c8-784c6b71658e/e9aaf732-4e28-485a-a1f8-e2ae18d1d00f/file.markdown	PUT	200	7848	2001:bc8:701:604:1a4a:53ff:fe0a:f3ee	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	\N	4	2026-02-05 02:43:55.349733+00
\.


--
-- Data for Name: storage_buckets; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_buckets (id, name, owner_id, quota_bytes, used_bytes, object_count, created_at, deleted_at) FROM stdin;
241f3151-b486-4e47-838e-286410075aeb	vault	\N	0	176625233	13	2026-02-03 01:49:52.094556+00	\N
\.


--
-- Data for Name: storage_chunks; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_chunks (hash, size, ref_count, compressed, stored_at) FROM stdin;
1994a0eaae032b2bba5e495bd11887a7355c77be707cf609e2d4eef6437e4ef7	20	1	f	2026-02-03 01:50:30.380015+00
1e51f19befa5eb7f3699bb69a34309b102c07e7b153be7c9841fdc7fe4a746c6	19	1	f	2026-02-03 09:40:42.814856+00
702fb11aedfc01670ba12b36223b6d37ff477cd05a5b846ebe6802c1e36039e8	19	1	f	2026-02-03 10:02:51.568795+00
4266cd7d10b317b15cd963a6ef2eda206e224647382ea2f4b546db1dba269a97	32	1	f	2026-02-03 14:21:23.970204+00
3901fd1c950f45266cac4616328a23dac0e4133f5c05d8e53e6fdb5e3e7d652e	75	1	f	2026-02-03 15:25:08.869068+00
479d144b3b9ca17a43900547d1c239b99f39c62cddc8e02ef538ba9cc117c23a	62	1	f	2026-02-03 15:25:21.905934+00
524a11c0908a92917717daa7eeb3517dceaad98dee9eb1358c029b58d2fa3f48	36	1	f	2026-02-03 22:29:43.357724+00
fe18ffdba2d587f9cdd340fb9c6e6da8c6278f5614b33424db32a4ef21aa7867	4194304	1	f	2026-02-03 22:30:14.63096+00
6c25ea29b3eadbd9089c1173855874d7ffcecc8da3198ac86d446b69c23429bc	4194304	1	f	2026-02-03 22:30:14.640141+00
20f3511a326925921831cfa4e36d4141b9699c07118c3441842c69a637172d2e	2097152	1	f	2026-02-03 22:30:14.644781+00
6b3f95bd7132340727d3feb2c4ce5f0a0f8472ed4b58c704eb8b2574e5df0ed4	4194304	1	f	2026-02-03 22:30:34.006099+00
e68d199701c2d25489acd8d59f828b483308ab5eb361a82ac0f73c5423908c1b	4194304	1	f	2026-02-03 22:30:34.01303+00
b6e41bca92e561f912171e1e76d2f89edd1402f1b25e00e3e263d40df3a738f5	4194304	1	f	2026-02-03 22:30:34.019596+00
acddeb97cfe3863e2c4116cbcd53eee1eb37d4c322f31793523fd6f26a9c8331	4194304	1	f	2026-02-03 22:30:34.02568+00
b7fd0cb0a0324a3c8213360cba253f1cc283c7cbc776b6c989e486bca95e69e9	4194304	1	f	2026-02-03 22:30:34.031955+00
1e3b22a3a9c3ff234cb574de8f4375bc4df0b92faea99db8349989488a4a8831	4194304	1	f	2026-02-03 22:30:34.038876+00
11b7af067cca3c826d9562d41efadd9d3249639c8136064d882552fb3f560b36	4194304	1	f	2026-02-03 22:30:34.045149+00
25f1872706add8ec48e926207c1409790194dc34b55846aa606ae2ab652a3db9	4194304	1	f	2026-02-03 22:30:34.051161+00
f7396cd4c842229563e8abef774573e619110ed653f151c290e963d1dc748cb7	4194304	1	f	2026-02-03 22:30:34.057433+00
1e6b7cc12bd04bc66921ae51249427bef8aa6fcc43f40d0547ebd7f726f44e1d	4194304	1	f	2026-02-03 22:30:34.063447+00
4e71130f2f40e6156fc40ad96259383c65895c77f6dff62e57db46281c1aa730	4194304	1	f	2026-02-03 22:30:34.070155+00
c1788582d5f6472a88e264152254410f4e67969e2fd15a233e0c6e3463a64855	4194304	1	f	2026-02-03 22:30:34.076186+00
5947943b07a6932616a4c689f917086cad8ef87111ca27c2ff962021b38645e8	4194304	1	f	2026-02-03 22:30:34.082467+00
2c7680cbffb1e37563bedfa8a0b573b22bffb4e162dc05c5b606b57c6c0b670a	4194304	1	f	2026-02-03 22:30:34.088825+00
d1a80efdffdf6f414865a6c64adae59bf7002bbba424725567772bffabc99b57	4194304	1	f	2026-02-03 22:30:34.096352+00
d496a3ba24daaafba3ddebf8fa3480eb1a0a2c52cff80daf912ee7dd292b30aa	4194304	1	f	2026-02-03 22:30:34.102474+00
88be099eeef780be97bb439dd8f0deeb4f979aa4d98dfdbd905df67d981363de	4194304	1	f	2026-02-03 22:30:34.108767+00
6d5b0938b942b5f7552592a3e7edb8c77a2734d68df873b8399491d0707bccda	4194304	1	f	2026-02-03 22:30:34.114931+00
87959e2a2dcdaf9819013639931da24cefdfc0d65f5820a086d7d49dd16baa2a	4194304	1	f	2026-02-03 22:30:34.123187+00
08b6426b14891dc7275cca609d560a9c2e153b11aa338cea7d11571a5c1cf21d	4194304	1	f	2026-02-03 22:30:34.131006+00
1e14ab348420a88b743f2328c504091b764d5eb42eca5281d64b955700a2c21f	4194304	1	f	2026-02-03 22:30:34.138933+00
7b57147c0acc41a182c52c9a53f75dce4c0c1425c265141c29940a6b9f49d049	4194304	1	f	2026-02-03 22:30:34.147001+00
a8de88770e3621808a6a5235a9ef8ac2a826be2c69460432765fdacfe7111f04	4194304	1	f	2026-02-03 22:30:34.154947+00
9d52aef4df61d95c41704282114ceb42b692068e0fe2a28c6e93df32ff88d598	4194304	1	f	2026-02-03 22:30:34.162675+00
4a0153b1f86f8801e5d01e1f13b103d0d85697197390095bec1a8d453fa892c2	4194304	1	f	2026-02-03 22:30:34.170633+00
62776091cb6cb03cf3e015c567c8b0e8fcc3f2ab6d09956a522153f674aa527f	4194304	1	f	2026-02-03 22:30:53.948152+00
6d2acbcca5eed7ae0587e069fd3f0bea5ef15d57a17039342ba0eca91bcbc865	4194304	1	f	2026-02-03 22:30:53.95542+00
bfc9c2f60a8efeab586dc04dfaaf11d8a3da6df37ed01081f5c2dd0c7fd82c0d	4194304	1	f	2026-02-03 22:30:53.961575+00
30189b4839145c85b9a78a6a70bab0643dd22d0f0e851f6e430ef297e06d3f75	4194304	1	f	2026-02-03 22:30:53.967613+00
5ab6889a54cff197971aca7249c7999746305c31b72a702b6e49e53ca2d6919e	4194304	1	f	2026-02-03 22:30:53.974865+00
edcf9a5492e9a6908430a8f4341c73a5c13e75881a43c3aa96b6e0725a000a32	4194304	1	f	2026-02-03 22:30:53.980978+00
97bff1a82bdcbbcc4d49fffd541fd82af69523daa43d30b7041e3c11197ee7c6	4194304	1	f	2026-02-03 22:30:53.986963+00
392fff597c98c57f1d415269e89ec6514d75b88297df39a2a1a42eb3a6e44609	4194304	1	f	2026-02-03 22:30:53.994378+00
c0a4b518df476aa945b66cf0fab25fc26ad724e1bfd6fbcd2e416962b17d9e9c	4194304	1	f	2026-02-03 22:30:54.000428+00
7b93cbfdd6a53e3c5547e11896bfa4394d9e4053f4905798658e395da572ae1c	4194304	1	f	2026-02-03 22:30:54.006373+00
bc9a460ef879e79538db202a985e83ea30e5d200eba6b9dfc51c4d2bf81e5690	4194304	1	f	2026-02-03 22:30:54.012362+00
20c6cfe496eec29f8f1102e7ba0ba87dcd92bb8508cd61e7354ed5f806fa460b	4194304	1	f	2026-02-03 22:30:54.01991+00
0515441c7506944b102621857c0fdc0e48572a2406c2c0458336eb8d3fa60a1b	2097152	1	f	2026-02-03 22:30:54.023333+00
4bbc87b12eaad1f277213d3155e042fe54aefee033457f761c61b1959dc697b4	2588067	1	f	2026-02-05 02:43:54.688944+00
8de6d5f3b9b95722706d35422c9f47d81ec4d7e06ee44073425c005020eee70c	4194304	1	f	2026-02-05 02:43:55.245981+00
66ca4d2b2a297e87d9c6da4c5a24f9614f7e53c53eb63682fea846507807698b	2062591	1	f	2026-02-05 02:43:55.252901+00
e9e4308a75acd28fe2018925d95a31ad586697c9633ebb7501462e5c2b6bcf29	7848	1	f	2026-02-05 02:43:55.346712+00
\.


--
-- Data for Name: storage_multipart_parts; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_multipart_parts (upload_id, part_number, chunk_hash, size, etag, uploaded_at) FROM stdin;
\.


--
-- Data for Name: storage_multipart_uploads; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_multipart_uploads (id, bucket_id, key, content_type, metadata, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: storage_object_chunks; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_object_chunks (object_id, chunk_hash, chunk_index, chunk_offset, chunk_size) FROM stdin;
7ccaa367-4367-4c3d-b036-77de55f1cbd7	1994a0eaae032b2bba5e495bd11887a7355c77be707cf609e2d4eef6437e4ef7	0	0	20
4e414f6b-c2ac-47d3-b349-e88927ed6cfe	1e51f19befa5eb7f3699bb69a34309b102c07e7b153be7c9841fdc7fe4a746c6	0	0	19
5e481696-8dd3-4a9c-a2dc-aa49d19a7cb0	702fb11aedfc01670ba12b36223b6d37ff477cd05a5b846ebe6802c1e36039e8	0	0	19
134521d0-3b57-4dd3-b046-25875840365a	4266cd7d10b317b15cd963a6ef2eda206e224647382ea2f4b546db1dba269a97	0	0	32
9a0d9c25-a1c9-4693-a4ee-f1b932c91aa2	3901fd1c950f45266cac4616328a23dac0e4133f5c05d8e53e6fdb5e3e7d652e	0	0	75
8a0cc5a9-99dd-4111-9870-33a8f2346249	479d144b3b9ca17a43900547d1c239b99f39c62cddc8e02ef538ba9cc117c23a	0	0	62
9c662248-d09b-4547-8a05-9f529535e5ab	524a11c0908a92917717daa7eeb3517dceaad98dee9eb1358c029b58d2fa3f48	0	0	36
9b12be5c-677c-4991-8453-ed38a3f6c890	fe18ffdba2d587f9cdd340fb9c6e6da8c6278f5614b33424db32a4ef21aa7867	0	0	4194304
9b12be5c-677c-4991-8453-ed38a3f6c890	6c25ea29b3eadbd9089c1173855874d7ffcecc8da3198ac86d446b69c23429bc	1	4194304	4194304
9b12be5c-677c-4991-8453-ed38a3f6c890	20f3511a326925921831cfa4e36d4141b9699c07118c3441842c69a637172d2e	2	8388608	2097152
32de2068-d467-475f-901c-1e3f5b8bad02	6b3f95bd7132340727d3feb2c4ce5f0a0f8472ed4b58c704eb8b2574e5df0ed4	0	0	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	e68d199701c2d25489acd8d59f828b483308ab5eb361a82ac0f73c5423908c1b	1	4194304	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	b6e41bca92e561f912171e1e76d2f89edd1402f1b25e00e3e263d40df3a738f5	2	8388608	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	acddeb97cfe3863e2c4116cbcd53eee1eb37d4c322f31793523fd6f26a9c8331	3	12582912	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	b7fd0cb0a0324a3c8213360cba253f1cc283c7cbc776b6c989e486bca95e69e9	4	16777216	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	1e3b22a3a9c3ff234cb574de8f4375bc4df0b92faea99db8349989488a4a8831	5	20971520	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	11b7af067cca3c826d9562d41efadd9d3249639c8136064d882552fb3f560b36	6	25165824	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	25f1872706add8ec48e926207c1409790194dc34b55846aa606ae2ab652a3db9	7	29360128	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	f7396cd4c842229563e8abef774573e619110ed653f151c290e963d1dc748cb7	8	33554432	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	1e6b7cc12bd04bc66921ae51249427bef8aa6fcc43f40d0547ebd7f726f44e1d	9	37748736	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	4e71130f2f40e6156fc40ad96259383c65895c77f6dff62e57db46281c1aa730	10	41943040	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	c1788582d5f6472a88e264152254410f4e67969e2fd15a233e0c6e3463a64855	11	46137344	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	5947943b07a6932616a4c689f917086cad8ef87111ca27c2ff962021b38645e8	12	50331648	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	2c7680cbffb1e37563bedfa8a0b573b22bffb4e162dc05c5b606b57c6c0b670a	13	54525952	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	d1a80efdffdf6f414865a6c64adae59bf7002bbba424725567772bffabc99b57	14	58720256	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	d496a3ba24daaafba3ddebf8fa3480eb1a0a2c52cff80daf912ee7dd292b30aa	15	62914560	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	88be099eeef780be97bb439dd8f0deeb4f979aa4d98dfdbd905df67d981363de	16	67108864	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	6d5b0938b942b5f7552592a3e7edb8c77a2734d68df873b8399491d0707bccda	17	71303168	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	87959e2a2dcdaf9819013639931da24cefdfc0d65f5820a086d7d49dd16baa2a	18	75497472	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	08b6426b14891dc7275cca609d560a9c2e153b11aa338cea7d11571a5c1cf21d	19	79691776	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	1e14ab348420a88b743f2328c504091b764d5eb42eca5281d64b955700a2c21f	20	83886080	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	7b57147c0acc41a182c52c9a53f75dce4c0c1425c265141c29940a6b9f49d049	21	88080384	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	a8de88770e3621808a6a5235a9ef8ac2a826be2c69460432765fdacfe7111f04	22	92274688	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	9d52aef4df61d95c41704282114ceb42b692068e0fe2a28c6e93df32ff88d598	23	96468992	4194304
32de2068-d467-475f-901c-1e3f5b8bad02	4a0153b1f86f8801e5d01e1f13b103d0d85697197390095bec1a8d453fa892c2	24	100663296	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	62776091cb6cb03cf3e015c567c8b0e8fcc3f2ab6d09956a522153f674aa527f	0	0	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	6d2acbcca5eed7ae0587e069fd3f0bea5ef15d57a17039342ba0eca91bcbc865	1	4194304	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	bfc9c2f60a8efeab586dc04dfaaf11d8a3da6df37ed01081f5c2dd0c7fd82c0d	2	8388608	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	30189b4839145c85b9a78a6a70bab0643dd22d0f0e851f6e430ef297e06d3f75	3	12582912	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	5ab6889a54cff197971aca7249c7999746305c31b72a702b6e49e53ca2d6919e	4	16777216	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	edcf9a5492e9a6908430a8f4341c73a5c13e75881a43c3aa96b6e0725a000a32	5	20971520	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	97bff1a82bdcbbcc4d49fffd541fd82af69523daa43d30b7041e3c11197ee7c6	6	25165824	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	392fff597c98c57f1d415269e89ec6514d75b88297df39a2a1a42eb3a6e44609	7	29360128	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	c0a4b518df476aa945b66cf0fab25fc26ad724e1bfd6fbcd2e416962b17d9e9c	8	33554432	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	7b93cbfdd6a53e3c5547e11896bfa4394d9e4053f4905798658e395da572ae1c	9	37748736	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	bc9a460ef879e79538db202a985e83ea30e5d200eba6b9dfc51c4d2bf81e5690	10	41943040	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	20c6cfe496eec29f8f1102e7ba0ba87dcd92bb8508cd61e7354ed5f806fa460b	11	46137344	4194304
60b75125-f2fa-46c3-90dd-397dd139b785	0515441c7506944b102621857c0fdc0e48572a2406c2c0458336eb8d3fa60a1b	12	50331648	2097152
31fb0198-e23e-4396-aec6-cdddc7a4d4b1	4bbc87b12eaad1f277213d3155e042fe54aefee033457f761c61b1959dc697b4	0	0	2588067
243916b0-d210-4ea9-b88e-0f83af836274	8de6d5f3b9b95722706d35422c9f47d81ec4d7e06ee44073425c005020eee70c	0	0	4194304
243916b0-d210-4ea9-b88e-0f83af836274	66ca4d2b2a297e87d9c6da4c5a24f9614f7e53c53eb63682fea846507807698b	1	4194304	2062591
ac4e7457-3a9b-465e-b3cb-e427fa61cff5	e9e4308a75acd28fe2018925d95a31ad586697c9633ebb7501462e5c2b6bcf29	0	0	7848
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_objects (id, bucket_id, key, version, size, content_type, etag, metadata, is_current, created_at, deleted_at) FROM stdin;
7ccaa367-4367-4c3d-b036-77de55f1cbd7	241f3151-b486-4e47-838e-286410075aeb	test/hello.txt	1	20	text/plain	b0e516b26083208b6e5f69a43f4aa0fd	{}	t	2026-02-03 01:50:30.383694+00	\N
4e414f6b-c2ac-47d3-b349-e88927ed6cfe	241f3151-b486-4e47-838e-286410075aeb	4ce083a9-4f18-45e3-ae08-710c2f0a44ef/91bbf109-8cb6-4a27-938c-7c0199576076/file.png	1	19	image/png	3b4b8a192c7a8a700e0cc7094c360625	{}	t	2026-02-03 09:40:42.817561+00	\N
5e481696-8dd3-4a9c-a2dc-aa49d19a7cb0	241f3151-b486-4e47-838e-286410075aeb	66c4567d-3e08-43e3-9a8f-4e57acc56f0e/2ddd5bf2-171c-4462-bc01-5e66337cb0ac/file.jpeg	1	19	image/jpeg	9737f7698e783646268369bb98cebad5	{}	t	2026-02-03 10:02:51.570823+00	\N
134521d0-3b57-4dd3-b046-25875840365a	241f3151-b486-4e47-838e-286410075aeb	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e/8ea6a0da-9109-4c02-9319-e822651ce741/file.plain	1	32	text/plain	3dbc96f12cd73083386418a10835b92a	{}	t	2026-02-03 14:21:23.971609+00	\N
9a0d9c25-a1c9-4693-a4ee-f1b932c91aa2	241f3151-b486-4e47-838e-286410075aeb	57f22b83-44c9-4e26-8afb-ab9bada3b8c5/c372109d-8534-4441-9f91-2791ca5d3dd4/file.plain	1	75	text/plain	ba69f53e58a03b7497134e79e143be7b	{}	t	2026-02-03 15:25:08.87197+00	\N
8a0cc5a9-99dd-4111-9870-33a8f2346249	241f3151-b486-4e47-838e-286410075aeb	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c/7a2c7e38-9e98-426c-95f9-804f1c5042ca/file.plain	1	62	text/plain	c4ab1794a32a0f386c3bf756c42c0f21	{}	t	2026-02-03 15:25:21.907586+00	\N
9c662248-d09b-4547-8a05-9f529535e5ab	241f3151-b486-4e47-838e-286410075aeb	32ecef26-dae9-4324-bc94-b27445211f69/be6b11b5-cac7-420d-8dd4-f9e23c3d1c1d/file.jpeg	1	36	image/jpeg	f935df5d2f2bbd4fcada733999efcc54	{}	t	2026-02-03 22:29:43.359739+00	\N
9b12be5c-677c-4991-8453-ed38a3f6c890	241f3151-b486-4e47-838e-286410075aeb	71b2b955-e4e5-49a0-99b6-b54cd8372e8b/5431f662-e115-4d89-a080-c40ade08ff4c/file.octet-stream	1	10485760	application/octet-stream	f7221159d46ce6c8ac7783d7489cc45a	{}	t	2026-02-03 22:30:14.645882+00	\N
32de2068-d467-475f-901c-1e3f5b8bad02	241f3151-b486-4e47-838e-286410075aeb	b3bf0cea-478c-434e-929d-23edbddf3539/a88ff194-3487-40a0-b167-d27c7e0a1c86/file.mp4	1	104857600	video/mp4	62bab04c68b174fd9a51e3bbdd763a7d	{}	t	2026-02-03 22:30:34.17178+00	\N
60b75125-f2fa-46c3-90dd-397dd139b785	241f3151-b486-4e47-838e-286410075aeb	e1dad1fd-a1b5-4f56-9571-6aaa183d4285/3f3686ee-add9-4f0a-82ab-e1089a43229b/file.octet-stream	1	52428800	application/octet-stream	dfbf39b70148081501915409528924bb	{}	t	2026-02-03 22:30:54.024237+00	\N
31fb0198-e23e-4396-aec6-cdddc7a4d4b1	241f3151-b486-4e47-838e-286410075aeb	7d5fb337-a497-43cb-a4c8-784c6b71658e/b9835d7e-316f-44ba-bdb0-04c1d3d4876a/file.jpeg	1	2588067	image/jpeg	f9bfbcaa81673caa6d07eb8a1342e6f5	{}	t	2026-02-05 02:43:54.691692+00	\N
243916b0-d210-4ea9-b88e-0f83af836274	241f3151-b486-4e47-838e-286410075aeb	7d5fb337-a497-43cb-a4c8-784c6b71658e/7c18dd23-76a0-4555-b11b-a10969b0ae6b/file.jpeg	1	6256895	image/jpeg	71954f546060a275872a0e52ba64c3a1	{}	t	2026-02-05 02:43:55.253868+00	\N
ac4e7457-3a9b-465e-b3cb-e427fa61cff5	241f3151-b486-4e47-838e-286410075aeb	7d5fb337-a497-43cb-a4c8-784c6b71658e/e9aaf732-4e28-485a-a1f8-e2ae18d1d00f/file.markdown	1	7848	text/markdown	34ed06a20653a5bda53e3f5f8cd4eb7c	{}	t	2026-02-05 02:43:55.347986+00	\N
\.


--
-- Data for Name: storage_quotas; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_quotas (id, user_id, plan_name, quota_bytes, used_bytes, file_count, max_file_size, max_versions_per_file, updated_at) FROM stdin;
b5e9dff5-dba4-48fc-b6f7-a96a22968d7b	4ce083a9-4f18-45e3-ae08-710c2f0a44ef	free	5368709120	100	1	104857600	10	2026-02-03 09:40:42.739612+00
77d782ef-5fd9-45dc-a323-337c24cdf68b	66c4567d-3e08-43e3-9a8f-4e57acc56f0e	free	5368709120	2048	1	104857600	10	2026-02-03 10:02:42.914489+00
185d2969-eebe-43ef-9fee-d59eae8c0293	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	free	5368709120	1280	2	104857600	10	2026-02-03 14:21:23.90263+00
02d9eff2-eb50-4216-ae98-c2e9d1f6f5a4	57f22b83-44c9-4e26-8afb-ab9bada3b8c5	free	5368709120	100	1	104857600	10	2026-02-03 15:24:58.297806+00
eefae903-af68-41e9-8f27-b8e95feff0e9	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c	free	5368709120	50	1	104857600	10	2026-02-03 15:25:21.798383+00
70967c67-5f41-4584-8636-9b4bfaa4c219	bf8d4061-9334-4832-9ab2-323ab6b1c32a	free	5368709120	50	1	104857600	10	2026-02-03 22:20:56.120174+00
41ee0204-a610-48b3-8b40-c1af43749a45	7eee445a-1fea-4a89-ab25-9f8b8613fa89	free	5368709120	50	1	104857600	10	2026-02-03 22:21:15.938236+00
494a051a-2115-4aca-b9b6-d63bde79eebe	85417bbf-64e0-40d2-b75c-6c52bdd9120e	free	5368709120	50	1	104857600	10	2026-02-03 22:21:57.829885+00
29190d1f-ce23-40c3-b4bb-0bfd3090ba82	9bdd08b1-72e3-42a4-97d8-37b76dad26cd	free	5368709120	50	1	104857600	10	2026-02-03 22:23:01.816087+00
0ace4054-e11c-4890-9490-a980aea375e7	32ecef26-dae9-4324-bc94-b27445211f69	free	5368709120	1024	1	104857600	10	2026-02-03 22:29:43.214993+00
bfdfe16e-324a-4c47-9613-c1aba4e03d99	71b2b955-e4e5-49a0-99b6-b54cd8372e8b	free	5368709120	10485760	1	104857600	10	2026-02-03 22:30:14.225074+00
d4af554e-be53-45c9-bf1c-85dbd03e0f98	b3bf0cea-478c-434e-929d-23edbddf3539	free	5368709120	104857600	1	104857600	10	2026-02-03 22:30:31.602175+00
22703923-2f91-417d-850d-7d78855111da	e1dad1fd-a1b5-4f56-9571-6aaa183d4285	free	5368709120	52428800	1	104857600	10	2026-02-03 22:30:52.615689+00
59cba122-2886-47d1-a5d0-956d8ae05dcd	6d1d217c-59b1-40f8-a716-a36c2b69aaf5	free	5368709120	1073741824	1	104857600	10	2026-02-03 23:34:10.047278+00
f40a4f19-6f2a-454b-8023-a76b2d4b8d58	f7ac2bc6-f57d-444d-ad14-759d78a1b46e	free	5368709120	1073741824	1	104857600	10	2026-02-03 23:34:21.366009+00
95443464-552c-4c6f-aff4-5f7071ea4911	7d5fb337-a497-43cb-a4c8-784c6b71658e	free	5368709120	8852810	3	104857600	10	2026-02-05 02:43:55.289494+00
621ca4fe-088b-4cb9-a14b-3be16eeccecd	71e1a917-d78e-4c3f-99d8-7df652b5c68b	free	5368709120	17090000	8	104857600	10	2026-02-05 10:06:18.628685+00
\.


--
-- Data for Name: sync_tokens; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.sync_tokens (id, user_id, device_id, device_name, device_public_key, last_sync_version, last_sync_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.user_sessions (id, user_id, token_hash, device_name, device_type, ip_address, user_agent, last_active_at, created_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.users (id, email, auth_hash, salt, encrypted_master_key, created_at, updated_at, last_login, storage_quota_bytes, storage_used_bytes, email_verified_at, display_name, language, timezone, deletion_requested_at, deletion_scheduled_at, deletion_reason, login_attempts, locked_until, totp_secret, totp_enabled_at, recovery_codes, stripe_customer_id, stripe_subscription_id, subscription_status, subscription_ends_at, email_verified, email_verification_token, email_verification_expires_at) FROM stdin;
71e1a917-d78e-4c3f-99d8-7df652b5c68b	test@0711.io	e2c373b6a88b720b0eb41499dac21932b5c46e973807b41561e69a0b0db4f6db	505f28ec32f0c28e5aebddfb7e70d35609e00011714c55ce56128ce8a79a399a	Bh47dPd7v/foYteb5zZGpxDfUbxNrdd3amQ2ZJdXlAGrh+9PJvDdInQph0kPB0BIW/4AtgLuEajFoRTp	2026-01-30 11:50:37.201087	2026-02-05 10:06:44.178277	2026-02-05 10:06:44.178277	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	t	\N	\N
66c4567d-3e08-43e3-9a8f-4e57acc56f0e	upload-test-1770112890@0711.io	b9d9ba2076ffcda65458108100ae6362a059f1305bfc771c3ddcfbbe1c037b13	f528beb62c98a65139e4caef87d266f2	b6307dbdfda442f3e26f8208968496abfa12488f1cbcf48402457bf296fa4ad3	2026-02-03 10:01:30.134152	2026-02-03 10:02:42.887256	2026-02-03 10:02:42.887256	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
3105c1e6-a60e-495f-9139-7047edfc684d	upload-test-1770132248@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	6cb6e5063c495da1b76c27434afa2e15	824c67248eeefb4916b1df993b4b57a2eb5695db74a5ae4982465b4f11fdcd59	2026-02-03 15:24:08.746619	2026-02-03 15:24:09.42156	2026-02-03 15:24:09.42156	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	L_lA_X3LbOln597nohKITWtSo7zqpjHt9t0Zh87dMkU	2026-02-04 15:24:08.746478
cc99ac5a-410e-46db-959f-2afc2189f2cd	test-e77e7da5@0711.io	ac11848d7777719a8b121599bda7a39d8e5e3eda666fd4b2a5b161a05c150b5f	3cc646ee2573d0fe816789efd86b13d24825d376b666fd933db8640a7f0a8f77	kxmdDnTfnVs05FNQTKFhFGb1Z803cgCcEFeb9dmP4m0=	2026-01-31 18:09:08.389215	2026-01-31 18:09:08.389215	\N	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
e73fbe8b-8450-48df-9826-1e2dfcd90f1b	test-a775db79@0711.io	082b11e7cfa1e14d940c3f789ce83b4c108296e81bc677dbe718046830631cc4	6dd2e7c50c28da95d5aaee00b0f485b1f84117b4a98befed10960657f6049fab	7PnqIb0+RHDm1Me7eWd6Zwt+SGK9bTRt+wjfJ+Y4HJ8=	2026-01-31 18:09:19.785357	2026-01-31 18:09:19.785357	\N	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
f7d3bf07-170e-4ad0-b004-701db52453c2	test-5248e574@0711.io	4bc6eb097d8700909024184cd9c3138683b65047d143242c60d6f964ca9bfa7c	aad7c4d4b18327daf3cb821358f5f3fe4d9aac213447fefbb1e0b9671f39921d	MkUQ3yMtk8xulO3uaw6cBLT0csETLqbTEsM+D/rq3h0=	2026-01-31 18:09:34.381041	2026-01-31 18:09:34.413622	2026-01-31 18:09:34.413622	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
1af4402a-131f-4773-b22b-cf6d74c5acff	verify-test-1770126842@0711.io	9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08	9a16bb8fd69086583e9017fc2d828987	56cec037eb457c3ed82f2dc72a4442ad98bccd0594d8a1c9a31255e86a340a3b	2026-02-03 13:54:02.887447	2026-02-03 13:54:12.225199	\N	10737418240	0	2026-02-03 13:54:12.225199+00	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	t	\N	\N
4db8c6fa-1e4d-49eb-a667-6a37e6374814	pipeline-test-01084737@0711.io	HB8Gf6OCJMGvQcQ14bpr47KlcmhS1BNrerUAroH1z6Y=	KmApKMr0/+e56zNRytcKiReFWfSVSU/LMjAVlrXjlFc=	wdhJcG0Z8VCBKqrAzmV31J6UWG4IutyMtBUYAhMvr1Y=	2026-02-01 11:19:50.592055	2026-02-01 11:19:50.671953	2026-02-01 11:19:50.671953	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
c71d0efa-07e4-4c8d-b149-165fdf38d046	test@example.com	test123hash	randomsalt	encryptedkey123	2026-01-31 16:42:57.970479	2026-02-01 11:48:56.585347	2026-02-01 11:48:56.585347	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
08f8df97-72e6-411a-8580-d0ae487accd4	test-01b6672c@0711.io	neID63aZNfZGZ6syrUzt3ax6/peTZxpVou5o4icRKK8=	8FmeiCVXlparuXeyEhkZPu6AnY3huxtvvXrl09+oL4s=	YTdt4ScvdMEUdyEhk5vIK5XUiOwLtKuydfyBugHWOyg=	2026-02-01 08:12:43.546352	2026-02-01 11:51:05.862527	2026-02-01 11:51:05.862527	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
94ff25b3-0399-477f-b460-0dcda844f143	test-flow@0711.io	test_auth_hash_12345	test_salt_12345	test_encrypted_key_12345	2026-02-03 01:55:51.464383	2026-02-03 01:55:51.684305	2026-02-03 01:55:51.684305	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
566662ee-f631-4e62-9b60-5252342ee1ec	test-e2e-1770109597@0711.io	testauth123	testsalt123	testkey123	2026-02-03 09:06:38.440804	2026-02-03 09:06:38.440804	\N	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
94c53d7a-fcdc-42ee-83b3-c6a5cb4c5c60	e2e-test-1770109782@0711.io	testhash123	testsalt456	testkey789	2026-02-03 09:09:42.696158	2026-02-03 09:09:42.696158	\N	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
2e052d50-9ab0-48d6-a27b-5a840f043e27	storage-test-1770111524@0711.io	testhash	testsalt	testkey	2026-02-03 09:38:44.346541	2026-02-03 09:38:44.346541	\N	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
d6def4d4-1f37-404c-ae3d-62393c742f02	storage-test-1770111536@0711.io	testhash	testsalt	testkey	2026-02-03 09:38:56.107234	2026-02-03 09:38:56.114956	2026-02-03 09:38:56.114956	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
c370365d-49e9-482d-b2db-3fba9809ee83	storage-final-1770111573@0711.io	hash123	salt123	key123	2026-02-03 09:39:33.603702	2026-02-03 09:39:33.616711	2026-02-03 09:39:33.616711	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
e58c1623-ee20-476a-8a3b-8274bacecdf1	direct-test-1770111583@0711.io	hash	salt	key	2026-02-03 09:39:43.878205	2026-02-03 09:39:43.889876	2026-02-03 09:39:43.889876	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
4ce083a9-4f18-45e3-ae08-710c2f0a44ef	final-storage-1770111642@0711.io	hash	salt	key	2026-02-03 09:40:42.699239	2026-02-03 09:40:42.71086	2026-02-03 09:40:42.71086	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N
57f22b83-44c9-4e26-8afb-ab9bada3b8c5	upload-test-1770132297@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	777d4ddd94cbf73d15b9fb77d48034b6	d1287d224d63d5485a09caf1bda7abda3d4f340c14e18913e9b8ddd770444f4c	2026-02-03 15:24:58.038617	2026-02-03 15:24:58.204461	2026-02-03 15:24:58.204461	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	zHvrNTbvN_xMpo_S45Rg1ko_y0MJIMaIfNbuLlUTzdw	2026-02-04 15:24:58.038431
7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	e2e-1770128471@0711.io	13d249f2cb4127b40cfa757866850278793f814ded3c587fe5889e889a7a9f6c	c7fe2a47b0d1689c078de50bbd5ec0c3	81e8d73bcbb460ef3f5e0511b4bf426b8af96bcd1c8f4a9f41e03bfcaf05ac03	2026-02-03 14:21:11.149334	2026-02-03 14:21:23.875111	2026-02-03 14:21:23.875111	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	GRCqkTQZ1_uos-hatz2o7MTwQ64pzBpYSJs5y8hsAVA	2026-02-04 14:21:11.149159
20be2d28-2cdf-4eb6-bd95-aa07873fe00a	e2e-test-1770131947@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	9e82cdf15ed66bb8fdbc7ff7d776935c	cdf63f525ad448874bf0251d592ed0a4f9de456993c0d38d137355c5473f39a6	2026-02-03 15:19:07.126784	2026-02-03 15:19:07.761349	2026-02-03 15:19:07.761349	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	Q135enbJ1a5XwLrPlkmmHotpyfpdn2PZ5m-t85ljmgg	2026-02-04 15:19:07.12662
e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c	upload-test-1770132320@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	a7d08b9b7b0c394d5ae3e4851e32fa2c	d9c53dea5183ec624e5376a325c4f21431c9a5a91b8ae5bbb2c553113981d856	2026-02-03 15:25:21.080121	2026-02-03 15:25:21.699256	2026-02-03 15:25:21.699256	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	2lMbkHwcqvEcVCQBCFo_Mxl_Jq45DKYA1Bl3Jks3wSQ	2026-02-04 15:25:21.079936
bf8d4061-9334-4832-9ab2-323ab6b1c32a	stripe-test-1770157255@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	10f37de6bc2e20abd864cd5d5b0ef5cd	3e198fdf803630ab58759d7efb5494199a3aed46c2676a027cfe43b45291ad0d	2026-02-03 22:20:55.431243	2026-02-03 22:20:56.015451	2026-02-03 22:20:56.015451	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	X4lRSecYN5R2612HblWTC8b9-WAOYZuVZruXdqLpPtA	2026-02-04 22:20:55.431033
7eee445a-1fea-4a89-ab25-9f8b8613fa89	stripe-test2-1770157275@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	decbd6a488da86839dbadda0972603bf	c66dbc6870bf0bac6ee7e4598bd60a50ab28c29a1657896996cbba458e79dfc3	2026-02-03 22:21:15.595594	2026-02-03 22:21:15.832712	2026-02-03 22:21:15.832712	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	teVLpaRA7fOIMQlAZ4l13VFmQaTiKaWOKTP9mpN6Hg0	2026-02-04 22:21:15.595391
85417bbf-64e0-40d2-b75c-6c52bdd9120e	final-test-1770157317@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	d43ec1c6e2314222267f959f05994752	45c6008953678ec5e518bccdb1cc7bd7bfbc2fe12c6761ed5dbf8e48ef14988b	2026-02-03 22:21:57.555588	2026-02-03 22:21:57.754842	2026-02-03 22:21:57.754842	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	463DNhQG0XYlbdZLgf0bPCCPvz0bQceg5WVdtdihLCw	2026-02-04 22:21:57.555421
9bdd08b1-72e3-42a4-97d8-37b76dad26cd	final-test2-1770157380@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	20f40ac52ba4cdd9f188087110ccbb18	63cad986f6e56ebdfa81c9e6f7e25f768444a0936d3d25f0c6b1e7d1b49c73dc	2026-02-03 22:23:01.125881	2026-02-03 22:23:01.710937	2026-02-03 22:23:01.710937	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	mmOe86ZXqEzLemocl5doKk_DWhr5KO4DGqoKDFXmE7E	2026-02-04 22:23:01.1257
122c19fa-7602-4977-9568-08919a1903e3	checkout-test-1770157389@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	6860b7e77893bef513ea41141e8ca3d5	0c888db84028a28b8e2a163b0aed5762d2e5d9e2a3a6488cb38828133835ac90	2026-02-03 22:23:09.734403	2026-02-03 22:23:10.40578	2026-02-03 22:23:10.40578	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	5rGyzTBx60niimV7JU0y8QnIiZ8KNVRTrarZhFbVmgg	2026-02-04 22:23:09.734206
e1046e95-8806-4038-967a-c74f7653faef	checkout-test2-1770157396@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	72dad68d9bdf1003b96ac1379a08c13f	a4b9e69070cd7b6779a484c209dcb85038e18f6d505c6cbc473f5d65daaaa55e	2026-02-03 22:23:16.323697	2026-02-03 22:23:16.632108	2026-02-03 22:23:16.632108	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	VPFlGy95PztC5shnMZMKIZKmiov5Cm5qR_wH9YT95cE	2026-02-04 22:23:16.323532
92bbdae3-2ef4-40ed-adf7-541c6ade38b2	checkout-test3-1770157450@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	4eb9e5375a012405c422a6e4f27ad1aa	432b03285338158f5efaf9091795e49a6f870ed5b0358708f4fb44647d307fce	2026-02-03 22:24:10.562976	2026-02-03 22:24:10.789218	2026-02-03 22:24:10.789218	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	Oylpa6c_18QkLMPHq6r-_3xP-jHzLrjMRn9L6KH5m5Q	2026-02-04 22:24:10.56277
5e388e70-0394-460c-9b03-5db5c8e2c6b3	checkout-test4-1770157457@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	57cbcd88c35ce903725936d645b679a8	1281cee2b844e0151d38754205804ec188cc679428b1fbd53ef7aaafbc638eb0	2026-02-03 22:24:17.268384	2026-02-03 22:24:17.492005	2026-02-03 22:24:17.492005	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	ezJ4-LEQg-exMrRE3J4qv_CEdQjwdXVMe7bjwX5mdDE	2026-02-04 22:24:17.268181
3f91a13a-0a92-421e-8fc4-b9218688d309	checkout-final-1770157489@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	de720fa6450a99d9b62b6a7e1dc882b3	edb056e25f3c280b0174d1accd7df9636255e8cc4eaf9e46801ec50df13ca63a	2026-02-03 22:24:49.575069	2026-02-03 22:24:50.195683	2026-02-03 22:24:50.195683	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	IZK5Zdafk32eVq8WsXcdeP25dtKtYv7ITUFIjZNt9js	2026-02-04 22:24:49.574895
993b59df-74c6-4556-ae44-ef4ce437084d	checkout-debug-1770157496@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	8dd4bc9d842b8589dba8a988d9921d47	66cfeedb75b461444ff8fa582cddf83af0b7df30291a48cdb4b741754b3b3f04	2026-02-03 22:24:56.918933	2026-02-03 22:24:57.050252	2026-02-03 22:24:57.050252	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	aCBsDDVlqMiiAL4j2qYcc6swRcbZ2zWS0FqnkLHXBs0	2026-02-04 22:24:56.918744
084c10b8-387c-4407-b324-b97b783b5bd2	checkout-ok-1770157524@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	fa078ef1b6b3adafb08db00a6d29edf3	3d92f930a4eb83d9fce71aee2b7428f384b3025072c6a5fa7a2ad62f8c4ba54f	2026-02-03 22:25:24.775579	2026-02-03 22:25:25.674385	2026-02-03 22:25:25.108264	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	cus_TuhR3fIAwgqnw1	\N	free	\N	f	61rjx-j_U10WJcDKC-C6dc9qvSHcFxJut0GEjy-5B58	2026-02-04 22:25:24.775373
32ecef26-dae9-4324-bc94-b27445211f69	comprehensive-test-1770157782@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	dce410ae3a68c0354e4c76f5dd326317	dc30a62fc49a3fed39caed37d64f468b537e7b4ef4ff514273d9506595a55528	2026-02-03 22:29:42.744342	2026-02-03 22:29:43.107151	2026-02-03 22:29:43.107151	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	shd8HmTSIu4kOmgdDojBOgKTWSx_0K-C-pJovxL23go	2026-02-04 22:29:42.744158
53e3e0f5-7b76-40e5-97da-36b44892adeb	test2-1770157798@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	b5f4db03f5e0f19f1f54f670d010b242	b0c8e78d7cdd176295ab1a96a12cb36b9a007e66892f57b48c19430c3bf47757	2026-02-03 22:29:58.189423	2026-02-03 22:29:58.763047	2026-02-03 22:29:58.763047	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	kORX9TXoFU_2ognrkE2ywd6pGsnj1OcPH5maX8hbQmE	2026-02-04 22:29:58.189254
71b2b955-e4e5-49a0-99b6-b54cd8372e8b	large-1770157813@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	55d738053c4cbcb91c18f6b34db626ca	82af2dca69e17651d4a7dbc4ce603f796c016aaa16784f5980b14138fbce8ae5	2026-02-03 22:30:13.997572	2026-02-03 22:30:14.155847	2026-02-03 22:30:14.155847	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	nzbMTyXgFu9a-kIq99V0c4e2VL22vmAEBhkJYBRLbcs	2026-02-04 22:30:13.997403
b3bf0cea-478c-434e-929d-23edbddf3539	huge-1770157831@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	c86130ee704b6b62b5f450609f69af5c	e420b13a0ecca8e95191f9397ab59a389a4e24e60516132c3170d40d787d3e3d	2026-02-03 22:30:31.082797	2026-02-03 22:30:31.535085	2026-02-03 22:30:31.535085	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	cc7pp-3CSV9SbdqI_wckcvlby4QA1FnpnblxK5KxjwE	2026-02-04 22:30:31.082603
e1dad1fd-a1b5-4f56-9571-6aaa183d4285	download-1770157851@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	eb19f8c29ff576e048aa894b5310875d	2a07977b430d1966e06f8612c6487284afa5bdcce061d2a0056fdd3b400bef04	2026-02-03 22:30:51.918899	2026-02-03 22:30:52.426451	2026-02-03 22:30:52.426451	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	q0qbBQQOp3f1hgFfZvT0vV0qp0o5YtYVJCUufqf19V0	2026-02-04 22:30:51.918735
a4658917-3cd4-4fd9-b4ca-8ed2878dca28	final-test-1770157881@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	83c5746a63f095edac73e5cfad6b0ec4	71b2eb92ce2b6e6d1b8e09feece6937af50a0503c2c811e26f956b40d5ac24a2	2026-02-03 22:31:21.52887	2026-02-03 22:31:21.736953	2026-02-03 22:31:21.736953	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	dcwSX3p-irFE3C8CTdG8MPkwYjoczmY-kZQrCDzVZ0Q	2026-02-04 22:31:21.528661
f7ac2bc6-f57d-444d-ad14-759d78a1b46e	1gb-test2-1770161660@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	f5f8d4aa9e9a7e79ddf5a6258d6d0ee8	5ac3b49db170db31a1cee8310989dc05300f1eca46b2aeeb66699a8e86d32251	2026-02-03 23:34:20.583067	2026-02-03 23:34:21.285517	2026-02-03 23:34:21.285517	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	TTvyWf4YHbYLgG0F-pKHnBYj-HCmi5oy1-9sH-NpdEk	2026-02-04 23:34:20.58288
f56b2c90-8e7b-4914-9ca1-63ee7317f134	delete-test-1770157894@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	90b94ee36f4e54610cd9c4e8b38f233a	1016da3ca106e61d679e98c382fc93b3429959e59a47714d9ebc0601b17dba36	2026-02-03 22:31:34.39274	2026-02-03 22:31:34.776991	2026-02-03 22:31:34.592362	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	w3yFpjur5u6AtnXGlZ2K4jP2mqpQ9Mhgt-OJmTyq2Eo	2026-02-04 22:31:34.392573
6d1d217c-59b1-40f8-a716-a36c2b69aaf5	1gb-test-1770161649@0711.io	b55c8792d1ce458e279308835f8a97b580263503e76e1998e279703e35ad0c2e	e5b7ba9a83fa2ebdbda68789155133c6	d565d8bfe4c80fb22272fcc85265de952c3139d4ec883adaf375cfc0ed25db09	2026-02-03 23:34:09.342325	2026-02-03 23:34:09.945981	2026-02-03 23:34:09.945981	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	fr7Wco0u_X3ualzxrBA98_z_iPiBcgVZyeLrUXqcfZw	2026-02-04 23:34:09.3422
d988183c-5917-4371-899c-3e1af0960b21	christoph@0711.io	d440554e69f8ab4c5104d197df3ddcea8a0093cd052569971d209c6eed25931b	30d6a15f2277368dc59140c107626ef659185658f1dea8dbb96c0d39029c631e	kMop2d1nu3n7shQgNViXBGretW1OK14KhlI3wSzOuY4=	2026-02-04 02:43:55.825134	2026-02-05 07:45:43.423819	2026-02-05 07:45:43.423819	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	RbtadE24oEXWQMl5IDCP7olONuygHO9IkkOla-I5QXU	2026-02-05 02:43:55.824988
1f4aaa47-0cce-48bb-85cf-4f024bca4ccc	christop@0711.io	a7ec2339c9098f2e9a0a86a4b95bd6ab878d52f995391b01c1b3aad4b9225bb9	dc5fa4cb7c8f863f4c2aff1b1e97ca3d369b4cec813e273f4ff67ced021ac9fe	MWZmYmU2MjRjYjU5NjM0ZTM3NzhiZDExMDg4NTM0ZTM1ZDQ5YTY4MWRhODEyNGVkZjdlY2Q3YjEzYjM4ZDgwOA==	2026-02-04 03:13:39.820022	2026-02-04 03:14:12.663427	2026-02-04 03:14:12.663427	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	LJeRZeT72aw-cCGeCR_00CrUrm79FDQExQbZt-QCfyI	2026-02-05 03:13:39.819882
df030b91-65dd-4b65-8866-b146510e151d	bombas-test@0711.io	10bd9b20a8571fac774e9e98b492469f56711fab0437b22f6edcded908255b6c	0f40fb1ad1a80479796d44e88edf887f2372d248eee667d9ef32f81412cfcbfa	MWJhNGM4OGY1NzZmYzFmZmRkOTk3ZTdjMDBhZGYzOGUxMTM3MWE2ZWY2Y2Y4NTRkNWQ5NzM1YWNmNDNhODA1NQ==	2026-02-05 02:33:35.886022	2026-02-05 02:39:54.695674	2026-02-05 02:39:54.695674	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	9DS562LSVMWUOlNui3D3Rujdu9ZY_OSrVKuJUcNuiw4	2026-02-06 02:33:35.885889
7d5fb337-a497-43cb-a4c8-784c6b71658e	bombas2@0711.io	be40adc4a6687f883641f396f1e0d2374ec9ed2f10bc3f158e1e0b7e0e91c24e	f1694dbb341299c7dd4578dc473a9341cb44144cec5aa2e62a2d3e1ff9df5625	OTc2YWE0ZjU2YzFmMzZkM2Y4ODM5MzM5MDA2OWZjOTgyNmJhMWI3NWYyYmZjZTVjYWM3MWE5MjFkMzAxNzUxMQ==	2026-02-05 02:43:11.630868	2026-02-05 17:27:50.75859	2026-02-05 17:27:50.75859	10737418240	0	\N	\N	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	Fd_7OpjhpU9y1yor3zNy3yTeepNAiezJUJHdhDeQo9M	2026-02-06 02:43:11.63071
\.


--
-- Data for Name: vault_content; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.vault_content (id, storage_key, user_id, encrypted_content, original_size, encrypted_size, checksum, created_at, accessed_at) FROM stdin;
\.


--
-- Data for Name: vault_items; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.vault_items (id, user_id, item_type, encrypted_metadata, storage_key, file_size, mime_type, created_at, updated_at, captured_at, deleted_at, sync_version, device_id, processing_status, processed_at, current_version, source_provider, source_path) FROM stdin;
3cb2fb7a-0db4-4286-b170-003e9db8b72c	c71d0efa-07e4-4c8d-b149-165fdf38d046	photo	\N	c71d0efa-07e4-4c8d-b149-165fdf38d046/e5b95e68-cf2f-4e1a-9f9b-214a145fa015.jpeg	1024	image/jpeg	2026-01-31 16:43:08.871072	2026-01-31 16:43:08.871072	\N	\N	1	\N	pending	\N	1	\N	\N
e3386dd5-71a4-4fe3-856f-cec908a3c7cd	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/019c237f-ad1b-4314-9097-6bc795277082.jpeg	825	image/jpeg	2026-02-01 08:16:24.013474	2026-02-01 08:16:24.013474	\N	\N	1	\N	pending	\N	1	\N	\N
bc6189d3-b8cb-4f3e-8c98-3b694838d73c	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/50b688a0-a845-4cfa-929f-bc8d62c1883e.jpeg	1000	image/jpeg	2026-02-01 08:16:10.313412	2026-02-01 08:16:37.329398	\N	2026-02-01 08:16:37.329398	1	\N	pending	\N	1	\N	\N
0c0920ff-5e11-4ace-886c-0f4228749ec4	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/c6f7e191-4f19-4bdd-b341-119b3e88d718.jpeg	6495921	image/jpeg	2026-02-01 09:01:16.520977	2026-02-01 11:25:09.665622	\N	\N	1	\N	complete	2026-02-01 11:25:09.665622	1	\N	\N
49833632-082e-43c9-8ba5-a6b32d1600fb	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/049e84ff-d0d7-45d4-8769-1e61013af20e.jpeg	5064265	image/jpeg	2026-02-01 09:01:16.871722	2026-02-01 11:25:15.415474	\N	\N	1	\N	complete	2026-02-01 11:25:15.415474	1	\N	\N
78154705-8d87-493a-a684-618d5c73269e	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/8401065b-2214-4216-81c4-85ad2300af9e.jpeg	6383019	image/jpeg	2026-02-01 09:01:16.184617	2026-02-01 11:25:20.888839	\N	\N	1	\N	complete	2026-02-01 11:25:20.888839	1	\N	\N
d3d05a46-f61b-4bf5-97ff-f0f96114a21b	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/f47d0b28-774e-472b-aa53-3dc6c719d5a5.jpeg	13577173	image/jpeg	2026-02-01 09:01:17.199449	2026-02-01 11:25:27.769538	\N	\N	1	\N	complete	2026-02-01 11:25:27.769538	1	\N	\N
06ebd867-87c1-4f46-9ed7-0c8fe8c876b6	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/f1f24bef-33c0-4a80-91f6-fa08ce6f38b6.jpeg	6256895	image/jpeg	2026-02-01 09:01:17.685054	2026-02-01 11:25:34.071967	\N	\N	1	\N	complete	2026-02-01 11:25:34.071967	1	\N	\N
f9c9b1a2-8172-47cf-adf8-2128ad1ba885	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/b40b986a-91f7-45a5-b3b5-ec664675f16c.jpeg	5920569	image/jpeg	2026-02-01 09:01:18.024495	2026-02-01 11:25:38.823591	\N	\N	1	\N	complete	2026-02-01 11:25:38.823591	1	\N	\N
bd43f7eb-34b2-41e9-9133-f4d4bdd612de	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/90991e04-9409-40ec-a040-1ebe7ebfbd89.jpeg	2588067	image/jpeg	2026-02-01 09:01:18.366219	2026-02-01 11:25:43.834233	\N	\N	1	\N	complete	2026-02-01 11:25:43.834233	1	\N	\N
674a68b7-262f-42ac-9fd9-c009955f5686	08f8df97-72e6-411a-8580-d0ae487accd4	document	\N	08f8df97-72e6-411a-8580-d0ae487accd4/4641006b-bb32-4bb5-a042-d55a8dd52409.pdf	6865492	application/pdf	2026-02-01 09:01:24.335045	2026-02-01 11:25:44.39604	\N	\N	1	\N	complete	2026-02-01 11:25:44.39604	1	\N	\N
022850ac-9d73-4bcb-8e16-89df8c0fa1c7	08f8df97-72e6-411a-8580-d0ae487accd4	document	\N	08f8df97-72e6-411a-8580-d0ae487accd4/957bc1cd-f995-4e99-9fa1-9ca433b6d9cc.pdf	636574	application/pdf	2026-02-01 09:01:30.838541	2026-02-01 11:25:44.764692	\N	\N	1	\N	complete	2026-02-01 11:25:44.764692	1	\N	\N
f15abd00-7091-475c-b3e2-5c52d051bc48	08f8df97-72e6-411a-8580-d0ae487accd4	document	\N	08f8df97-72e6-411a-8580-d0ae487accd4/863d4b14-fd82-4263-81d5-32dc9eb4dd96.pdf	7452057	application/pdf	2026-02-01 09:01:31.077398	2026-02-01 11:25:45.3521	\N	\N	1	\N	complete	2026-02-01 11:25:45.3521	1	\N	\N
3f8c6cbc-1e97-41c0-8a2c-48b4e4a071b3	08f8df97-72e6-411a-8580-d0ae487accd4	document	\N	08f8df97-72e6-411a-8580-d0ae487accd4/4d8e1478-75c5-4d78-946c-2d8165df69cb.pdf	163230	application/pdf	2026-02-01 09:01:31.432955	2026-02-01 11:25:45.707684	\N	\N	1	\N	complete	2026-02-01 11:25:45.707684	1	\N	\N
e6f8c74e-c839-4bea-b45d-aadd468c45f6	08f8df97-72e6-411a-8580-d0ae487accd4	document	\N	08f8df97-72e6-411a-8580-d0ae487accd4/69560557-c839-401e-b58e-1a655a6ead8a.pdf	1491250	application/pdf	2026-02-01 09:01:31.600374	2026-02-01 11:25:46.101689	\N	\N	1	\N	complete	2026-02-01 11:25:46.101689	1	\N	\N
2688d0dd-cf73-48d5-9081-d721c08a8e59	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/9953bab8-5097-42b5-86ea-6a9e00509586.jpeg	6383019	image/jpeg	2026-02-01 11:15:50.495832	2026-02-01 11:25:51.796184	\N	\N	1	\N	complete	2026-02-01 11:25:51.796184	1	\N	\N
9a521cb4-6c96-4d3f-bd1a-5a680a02dbf3	08f8df97-72e6-411a-8580-d0ae487accd4	photo	\N	08f8df97-72e6-411a-8580-d0ae487accd4/d6328064-6e30-4418-8ba5-2370f1a33d78.jpeg	6495921	image/jpeg	2026-02-01 11:15:50.886451	2026-02-01 11:25:57.134003	\N	\N	1	\N	complete	2026-02-01 11:25:57.134003	1	\N	\N
d4ccc940-2f10-41de-952b-ee82ef82fd0b	4db8c6fa-1e4d-49eb-a667-6a37e6374814	photo	\N	4db8c6fa-1e4d-49eb-a667-6a37e6374814/e23a4385-01a1-4167-91fa-f486a58c42e5.jpeg	2588067	image/jpeg	2026-02-01 11:19:58.718152	2026-02-01 11:26:02.518782	\N	\N	1	\N	complete	2026-02-01 11:26:02.518782	1	\N	\N
2d73ad13-87c6-4e1a-8f31-50bf1d770931	4ce083a9-4f18-45e3-ae08-710c2f0a44ef	photo	\N	4ce083a9-4f18-45e3-ae08-710c2f0a44ef/91bbf109-8cb6-4a27-938c-7c0199576076/file.png	100	image/png	2026-02-03 09:40:42.739612	2026-02-03 09:40:42.739612	\N	\N	1	\N	pending	\N	1	\N	\N
1f1f7367-7982-43c0-9849-3849b919f9c6	66c4567d-3e08-43e3-9a8f-4e57acc56f0e	photo	test-encrypted	66c4567d-3e08-43e3-9a8f-4e57acc56f0e/2ddd5bf2-171c-4462-bc01-5e66337cb0ac/file.jpeg	2048	image/jpeg	2026-02-03 10:02:42.914489	2026-02-03 10:02:42.914489	\N	\N	1	\N	pending	\N	1	\N	\N
7bfc4b8b-e487-4f90-a27a-13122a9428cc	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	photo	test	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e/329bb672-cf3d-4b1e-a9f3-aee616d7e73c/file.jpeg	1024	image/jpeg	2026-02-03 14:21:11.698552	2026-02-03 14:21:11.698552	\N	\N	1	\N	pending	\N	1	\N	\N
99b532d3-e7f6-4cee-8d38-b41b8e45b749	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e	document	test-doc	7a7a0bd6-4e28-4fec-9fea-17cfd95f944e/8ea6a0da-9109-4c02-9319-e822651ce741/file.plain	256	text/plain	2026-02-03 14:21:23.90263	2026-02-03 14:21:23.90263	\N	\N	1	\N	pending	\N	1	\N	\N
7142c7d3-bb63-4bc8-9dd4-ea633ade7db9	57f22b83-44c9-4e26-8afb-ab9bada3b8c5	document	encrypted-test-metadata	57f22b83-44c9-4e26-8afb-ab9bada3b8c5/c372109d-8534-4441-9f91-2791ca5d3dd4/file.plain	100	text/plain	2026-02-03 15:24:58.297806	2026-02-03 15:24:58.297806	\N	\N	1	\N	pending	\N	1	\N	\N
0f18de26-5f93-4fd3-a111-223f83cb2a4b	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c	document	test-encrypted	e5d7498b-a8c6-4cf3-abb7-a3ddec38af6c/7a2c7e38-9e98-426c-95f9-804f1c5042ca/file.plain	50	text/plain	2026-02-03 15:25:21.798383	2026-02-03 15:25:21.798383	\N	\N	1	\N	pending	\N	1	\N	\N
960c32a6-8bc0-4451-a3f8-e152115d79a7	bf8d4061-9334-4832-9ab2-323ab6b1c32a	document	test	bf8d4061-9334-4832-9ab2-323ab6b1c32a/4b39f00e-23a6-4be5-9bc3-18931217262c/file.plain	50	text/plain	2026-02-03 22:20:56.120174	2026-02-03 22:20:56.120174	\N	\N	1	\N	pending	\N	1	\N	\N
c0d02ee3-feb2-4dbd-9422-55002a368b8a	7eee445a-1fea-4a89-ab25-9f8b8613fa89	document	test	7eee445a-1fea-4a89-ab25-9f8b8613fa89/3086333b-555b-4c0a-95e4-a936b0212f6d/file.plain	50	text/plain	2026-02-03 22:21:15.938236	2026-02-03 22:21:15.938236	\N	\N	1	\N	pending	\N	1	\N	\N
67337173-c022-4b64-b9af-b74b6215106d	85417bbf-64e0-40d2-b75c-6c52bdd9120e	document	test	85417bbf-64e0-40d2-b75c-6c52bdd9120e/6c2acf2a-4ce8-4596-a32b-826c9c2cbf10/file.plain	50	text/plain	2026-02-03 22:21:57.829885	2026-02-03 22:21:57.829885	\N	\N	1	\N	pending	\N	1	\N	\N
889c36e4-1543-4aea-8fce-693a6c2dc350	9bdd08b1-72e3-42a4-97d8-37b76dad26cd	document	test	9bdd08b1-72e3-42a4-97d8-37b76dad26cd/178d1d6b-f87b-4580-88e6-35cf6837034a/file.plain	50	text/plain	2026-02-03 22:23:01.816087	2026-02-03 22:23:01.816087	\N	\N	1	\N	pending	\N	1	\N	\N
c5017a61-2e4a-4559-b132-f9e307b068fe	32ecef26-dae9-4324-bc94-b27445211f69	photo	test-metadata	32ecef26-dae9-4324-bc94-b27445211f69/be6b11b5-cac7-420d-8dd4-f9e23c3d1c1d/file.jpeg	1024	image/jpeg	2026-02-03 22:29:43.214993	2026-02-03 22:29:43.214993	\N	\N	1	\N	pending	\N	1	\N	\N
62a22d49-8e12-40cf-85d6-19fd7d11d68f	71b2b955-e4e5-49a0-99b6-b54cd8372e8b	document	large-file-test	71b2b955-e4e5-49a0-99b6-b54cd8372e8b/5431f662-e115-4d89-a080-c40ade08ff4c/file.octet-stream	10485760	application/octet-stream	2026-02-03 22:30:14.225074	2026-02-03 22:30:14.225074	\N	\N	1	\N	pending	\N	1	\N	\N
4d8d3381-4627-4863-8968-884376a9caaf	b3bf0cea-478c-434e-929d-23edbddf3539	video	100mb-test	b3bf0cea-478c-434e-929d-23edbddf3539/a88ff194-3487-40a0-b167-d27c7e0a1c86/file.mp4	104857600	video/mp4	2026-02-03 22:30:31.602175	2026-02-03 22:30:31.602175	\N	\N	1	\N	pending	\N	1	\N	\N
2cabfbfb-f48a-49a2-8974-a15f2baab707	e1dad1fd-a1b5-4f56-9571-6aaa183d4285	document	download-test	e1dad1fd-a1b5-4f56-9571-6aaa183d4285/3f3686ee-add9-4f0a-82ab-e1089a43229b/file.octet-stream	52428800	application/octet-stream	2026-02-03 22:30:52.615689	2026-02-03 22:30:52.615689	\N	\N	1	\N	pending	\N	1	\N	\N
d93f26c1-41de-4eba-aab4-72e24e1c5bb6	6d1d217c-59b1-40f8-a716-a36c2b69aaf5	video	1gb-stress-test	6d1d217c-59b1-40f8-a716-a36c2b69aaf5/48a0fc83-6f54-4398-b264-3fa7c2665ca7/file.mp4	1073741824	video/mp4	2026-02-03 23:34:10.047278	2026-02-03 23:34:10.047278	\N	\N	1	\N	pending	\N	1	\N	\N
43ce2a5f-245d-4913-9ea4-db1e110f27cc	f7ac2bc6-f57d-444d-ad14-759d78a1b46e	video	1gb-stress-test	f7ac2bc6-f57d-444d-ad14-759d78a1b46e/6ae4a83f-a08d-4dd2-b516-e99ddad43469/file.mp4	1073741824	video/mp4	2026-02-03 23:34:21.366009	2026-02-03 23:34:21.366009	\N	\N	1	\N	pending	\N	1	\N	\N
38c37c07-2625-4405-8f37-088c7a5f7419	7d5fb337-a497-43cb-a4c8-784c6b71658e	photo	\N	7d5fb337-a497-43cb-a4c8-784c6b71658e/b9835d7e-316f-44ba-bdb0-04c1d3d4876a/file.jpeg	2588067	image/jpeg	2026-02-05 02:43:54.208185	2026-02-05 02:43:54.208185	\N	\N	1	\N	pending	\N	1	\N	\N
7d47bfa1-a979-47b6-ba7c-b90909d7b16e	7d5fb337-a497-43cb-a4c8-784c6b71658e	photo	\N	7d5fb337-a497-43cb-a4c8-784c6b71658e/7c18dd23-76a0-4555-b11b-a10969b0ae6b/file.jpeg	6256895	image/jpeg	2026-02-05 02:43:54.727623	2026-02-05 02:43:54.727623	\N	\N	1	\N	pending	\N	1	\N	\N
a7242b12-ba7e-4798-9063-ccc74a586573	7d5fb337-a497-43cb-a4c8-784c6b71658e	document	\N	7d5fb337-a497-43cb-a4c8-784c6b71658e/e9aaf732-4e28-485a-a1f8-e2ae18d1d00f/file.markdown	7848	text/markdown	2026-02-05 02:43:55.289494	2026-02-05 02:43:55.289494	\N	\N	1	\N	pending	\N	1	\N	\N
237b53fe-0a57-4351-b7e2-66ef8b618fd4	71e1a917-d78e-4c3f-99d8-7df652b5c68b	photo	\N	test/photo1.jpg	2500000	image/jpeg	2026-02-04 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
120d1d6a-f7a0-44b6-b223-3c14ab2062c4	71e1a917-d78e-4c3f-99d8-7df652b5c68b	photo	\N	test/photo2.jpg	3200000	image/jpeg	2026-02-03 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
3bab16ed-3e7d-490e-99ae-7e84974ec51a	71e1a917-d78e-4c3f-99d8-7df652b5c68b	photo	\N	test/photo3.jpg	1800000	image/jpeg	2026-02-02 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
7fa61d4c-b42a-4514-aef4-03f27847636a	71e1a917-d78e-4c3f-99d8-7df652b5c68b	photo	\N	test/vacation1.jpg	4100000	image/jpeg	2026-01-29 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
974b30d6-b5ca-47b6-83ca-74d23db97f39	71e1a917-d78e-4c3f-99d8-7df652b5c68b	photo	\N	test/vacation2.jpg	3900000	image/jpeg	2026-01-29 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
24c2916c-b85b-42d8-b0eb-d5f0e53f51bf	71e1a917-d78e-4c3f-99d8-7df652b5c68b	document	\N	test/contract.pdf	520000	application/pdf	2026-01-22 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
9bed03d2-24d9-4deb-9ea1-dd65576b7703	71e1a917-d78e-4c3f-99d8-7df652b5c68b	document	\N	test/invoice.pdf	180000	application/pdf	2026-01-05 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
040ea252-3d01-4a5d-ad2d-f624b6703462	71e1a917-d78e-4c3f-99d8-7df652b5c68b	document	\N	test/tax_2025.pdf	890000	application/pdf	2025-12-05 10:06:18.628685	2026-02-05 10:06:18.628685	\N	\N	1	\N	complete	\N	1	\N	\N
\.


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vault
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: vault_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vault
--

SELECT pg_catalog.setval('public.vault_content_id_seq', 1, false);


--
-- Name: album_items album_items_album_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_album_id_item_id_key UNIQUE (album_id, item_id);


--
-- Name: album_items album_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_pkey PRIMARY KEY (id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: collaborators collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_pkey PRIMARY KEY (id);


--
-- Name: data_exports data_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_pkey PRIMARY KEY (id);


--
-- Name: document_metadata document_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_pkey PRIMARY KEY (id);


--
-- Name: embeddings embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_pkey PRIMARY KEY (id);


--
-- Name: face_clusters face_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.face_clusters
    ADD CONSTRAINT face_clusters_pkey PRIMARY KEY (id);


--
-- Name: faces faces_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_pkey PRIMARY KEY (id);


--
-- Name: import_connections import_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_pkey PRIMARY KEY (id);


--
-- Name: import_connections import_connections_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_user_id_provider_key UNIQUE (user_id, provider);


--
-- Name: import_history import_history_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_pkey PRIMARY KEY (id);


--
-- Name: import_history import_history_user_id_provider_source_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_user_id_provider_source_id_key UNIQUE (user_id, provider, source_id);


--
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- Name: item_places item_places_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_pkey PRIMARY KEY (id);


--
-- Name: item_versions item_versions_item_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_item_id_version_number_key UNIQUE (item_id, version_number);


--
-- Name: item_versions item_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: place_clusters place_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.place_clusters
    ADD CONSTRAINT place_clusters_pkey PRIMARY KEY (id);


--
-- Name: processing_queue processing_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_key_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_key_key UNIQUE (key);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: share_links share_links_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_pkey PRIMARY KEY (id);


--
-- Name: share_links share_links_share_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_share_token_key UNIQUE (share_token);


--
-- Name: shares shares_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_pkey PRIMARY KEY (id);


--
-- Name: shares shares_share_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_share_token_key UNIQUE (share_token);


--
-- Name: storage_access_log storage_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_access_log
    ADD CONSTRAINT storage_access_log_pkey PRIMARY KEY (id);


--
-- Name: storage_buckets storage_buckets_name_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_buckets
    ADD CONSTRAINT storage_buckets_name_key UNIQUE (name);


--
-- Name: storage_buckets storage_buckets_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_buckets
    ADD CONSTRAINT storage_buckets_pkey PRIMARY KEY (id);


--
-- Name: storage_chunks storage_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_chunks
    ADD CONSTRAINT storage_chunks_pkey PRIMARY KEY (hash);


--
-- Name: storage_multipart_parts storage_multipart_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_parts
    ADD CONSTRAINT storage_multipart_parts_pkey PRIMARY KEY (upload_id, part_number);


--
-- Name: storage_multipart_uploads storage_multipart_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_uploads
    ADD CONSTRAINT storage_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: storage_object_chunks storage_object_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_pkey PRIMARY KEY (object_id, chunk_index);


--
-- Name: storage_objects storage_objects_bucket_id_key_version_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_bucket_id_key_version_key UNIQUE (bucket_id, key, version);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: storage_quotas storage_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_pkey PRIMARY KEY (id);


--
-- Name: storage_quotas storage_quotas_user_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_user_id_key UNIQUE (user_id);


--
-- Name: sync_tokens sync_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_pkey PRIMARY KEY (id);


--
-- Name: sync_tokens sync_tokens_user_id_device_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_user_id_device_id_key UNIQUE (user_id, device_id);


--
-- Name: password_reset_tokens unique_user_reset; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT unique_user_reset UNIQUE (user_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vault_content vault_content_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content
    ADD CONSTRAINT vault_content_pkey PRIMARY KEY (id);


--
-- Name: vault_content vault_content_storage_key_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content
    ADD CONSTRAINT vault_content_storage_key_key UNIQUE (storage_key);


--
-- Name: vault_items vault_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_items
    ADD CONSTRAINT vault_items_pkey PRIMARY KEY (id);


--
-- Name: idx_access_log_bucket; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_access_log_bucket ON public.storage_access_log USING btree (bucket_name);


--
-- Name: idx_access_log_time; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_access_log_time ON public.storage_access_log USING btree (created_at);


--
-- Name: idx_album_items_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_album_items_album ON public.album_items USING btree (album_id);


--
-- Name: idx_album_items_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_album_items_item ON public.album_items USING btree (item_id);


--
-- Name: idx_albums_parent; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_albums_parent ON public.albums USING btree (parent_id);


--
-- Name: idx_albums_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_albums_user ON public.albums USING btree (user_id);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_resource ON public.audit_log USING btree (resource_type, resource_id);


--
-- Name: idx_audit_time; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_time ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_collaborators_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_album ON public.collaborators USING btree (album_id);


--
-- Name: idx_collaborators_email; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_email ON public.collaborators USING btree (collaborator_email);


--
-- Name: idx_collaborators_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_user ON public.collaborators USING btree (collaborator_id);


--
-- Name: idx_content_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_content_key ON public.vault_content USING btree (storage_key);


--
-- Name: idx_content_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_content_user ON public.vault_content USING btree (user_id);


--
-- Name: idx_document_metadata_category; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_document_metadata_category ON public.document_metadata USING btree (category);


--
-- Name: idx_document_metadata_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_document_metadata_item ON public.document_metadata USING btree (item_id);


--
-- Name: idx_embeddings_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_item ON public.embeddings USING btree (item_id);


--
-- Name: idx_embeddings_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_user ON public.embeddings USING btree (user_id);


--
-- Name: idx_embeddings_vector; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_vector ON public.embeddings USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_exports_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_exports_user ON public.data_exports USING btree (user_id);


--
-- Name: idx_face_clusters_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_face_clusters_user ON public.face_clusters USING btree (user_id);


--
-- Name: idx_faces_cluster; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_cluster ON public.faces USING btree (cluster_id);


--
-- Name: idx_faces_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_item ON public.faces USING btree (item_id);


--
-- Name: idx_faces_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_user ON public.faces USING btree (user_id);


--
-- Name: idx_faces_vector; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_vector ON public.faces USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_import_connections_provider; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_connections_provider ON public.import_connections USING btree (provider);


--
-- Name: idx_import_connections_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_connections_user ON public.import_connections USING btree (user_id);


--
-- Name: idx_import_history_lookup; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_history_lookup ON public.import_history USING btree (user_id, provider, source_id);


--
-- Name: idx_import_jobs_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_jobs_status ON public.import_jobs USING btree (status);


--
-- Name: idx_import_jobs_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_jobs_user ON public.import_jobs USING btree (user_id);


--
-- Name: idx_item_places_cluster; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_item_places_cluster ON public.item_places USING btree (cluster_id);


--
-- Name: idx_item_places_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_item_places_item ON public.item_places USING btree (item_id);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id, read_at) WHERE (read_at IS NULL);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id);


--
-- Name: idx_objects_bucket_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_objects_bucket_key ON public.storage_objects USING btree (bucket_id, key) WHERE (is_current = true);


--
-- Name: idx_password_reset_tokens_expires; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_expires ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token);


--
-- Name: idx_password_reset_tokens_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_user ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_place_clusters_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_place_clusters_user ON public.place_clusters USING btree (user_id);


--
-- Name: idx_processing_queue_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_processing_queue_item ON public.processing_queue USING btree (item_id);


--
-- Name: idx_processing_queue_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_processing_queue_status ON public.processing_queue USING btree (status, priority);


--
-- Name: idx_quotas_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_quotas_user ON public.storage_quotas USING btree (user_id);


--
-- Name: idx_rate_limits_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_rate_limits_key ON public.rate_limits USING btree (key);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sessions_token ON public.user_sessions USING btree (token_hash);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: idx_share_links_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_album ON public.share_links USING btree (album_id);


--
-- Name: idx_share_links_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_item ON public.share_links USING btree (item_id);


--
-- Name: idx_share_links_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_token ON public.share_links USING btree (share_token);


--
-- Name: idx_share_links_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_user ON public.share_links USING btree (user_id);


--
-- Name: idx_shares_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_shares_item ON public.shares USING btree (item_id);


--
-- Name: idx_shares_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_shares_token ON public.shares USING btree (share_token);


--
-- Name: idx_sync_tokens_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sync_tokens_user ON public.sync_tokens USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_verification_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_users_email_verification_token ON public.users USING btree (email_verification_token) WHERE (email_verification_token IS NOT NULL);


--
-- Name: idx_vault_items_source; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_source ON public.vault_items USING btree (source_provider) WHERE (source_provider IS NOT NULL);


--
-- Name: idx_vault_items_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_status ON public.vault_items USING btree (processing_status);


--
-- Name: idx_vault_items_sync; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_sync ON public.vault_items USING btree (user_id, sync_version);


--
-- Name: idx_vault_items_type; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_type ON public.vault_items USING btree (item_type);


--
-- Name: idx_vault_items_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_user ON public.vault_items USING btree (user_id);


--
-- Name: idx_versions_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_versions_item ON public.item_versions USING btree (item_id);


--
-- Name: face_clusters face_clusters_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER face_clusters_updated_at BEFORE UPDATE ON public.face_clusters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: place_clusters place_clusters_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER place_clusters_updated_at BEFORE UPDATE ON public.place_clusters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: album_items trigger_update_album_count; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER trigger_update_album_count AFTER INSERT OR DELETE ON public.album_items FOR EACH ROW EXECUTE FUNCTION public.update_album_count();


--
-- Name: vault_items trigger_update_quota; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER trigger_update_quota AFTER INSERT OR DELETE ON public.vault_items FOR EACH ROW EXECUTE FUNCTION public.update_storage_quota();


--
-- Name: users users_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: vault_items vault_items_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER vault_items_updated_at BEFORE UPDATE ON public.vault_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: album_items album_items_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: album_items album_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: albums albums_cover_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_cover_item_id_fkey FOREIGN KEY (cover_item_id) REFERENCES public.vault_items(id);


--
-- Name: albums albums_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.albums(id);


--
-- Name: albums albums_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: collaborators collaborators_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: collaborators collaborators_collaborator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_collaborator_id_fkey FOREIGN KEY (collaborator_id) REFERENCES public.users(id);


--
-- Name: collaborators collaborators_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: data_exports data_exports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: document_metadata document_metadata_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: document_metadata document_metadata_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: embeddings embeddings_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: embeddings embeddings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: face_clusters face_clusters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.face_clusters
    ADD CONSTRAINT face_clusters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: faces faces_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.face_clusters(id) ON DELETE SET NULL;


--
-- Name: faces faces_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: faces faces_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_connections import_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: import_history import_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: import_history import_history_vault_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_vault_item_id_fkey FOREIGN KEY (vault_item_id) REFERENCES public.vault_items(id);


--
-- Name: import_jobs import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: item_places item_places_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.place_clusters(id) ON DELETE SET NULL;


--
-- Name: item_places item_places_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: item_versions item_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: item_versions item_versions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: place_clusters place_clusters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.place_clusters
    ADD CONSTRAINT place_clusters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: processing_queue processing_queue_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: processing_queue processing_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: share_links share_links_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: share_links share_links_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id);


--
-- Name: share_links share_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shares shares_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: shares shares_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: storage_multipart_parts storage_multipart_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_parts
    ADD CONSTRAINT storage_multipart_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.storage_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: storage_multipart_uploads storage_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_uploads
    ADD CONSTRAINT storage_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.storage_buckets(id);


--
-- Name: storage_object_chunks storage_object_chunks_chunk_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_chunk_hash_fkey FOREIGN KEY (chunk_hash) REFERENCES public.storage_chunks(hash);


--
-- Name: storage_object_chunks storage_object_chunks_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.storage_objects(id) ON DELETE CASCADE;


--
-- Name: storage_objects storage_objects_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.storage_buckets(id);


--
-- Name: storage_quotas storage_quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sync_tokens sync_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vault_items vault_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_items
    ADD CONSTRAINT vault_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xNKtVxFdM8tDxSxPmgid5RdMmZEZtahqwPMlapmnFXap9u0gpuyqFE0vhvpbNKY

