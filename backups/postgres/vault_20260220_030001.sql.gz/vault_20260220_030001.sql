--
-- PostgreSQL database dump
--

\restrict PbBrvzVjEMz5FBq3OWfQSBpK1u3QWtUjHatrVNKZHakMSsWdw7gmiIbGQUClJK0

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg12+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: cleanup_expired_reset_tokens(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.cleanup_expired_reset_tokens() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM password_reset_tokens
    WHERE expires_at < NOW();

    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


ALTER FUNCTION public.cleanup_expired_reset_tokens() OWNER TO vault;

--
-- Name: FUNCTION cleanup_expired_reset_tokens(); Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON FUNCTION public.cleanup_expired_reset_tokens() IS 'Deletes expired password reset tokens';


--
-- Name: find_similar_faces(uuid, public.vector, double precision, integer); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.find_similar_faces(p_user_id uuid, p_face_embedding public.vector, p_threshold double precision DEFAULT 0.6, p_limit integer DEFAULT 10) RETURNS TABLE(face_id uuid, item_id uuid, cluster_id uuid, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        f.id as face_id,
        f.item_id,
        f.cluster_id,
        1 - (f.embedding <=> p_face_embedding) as similarity
    FROM faces f
    WHERE f.user_id = p_user_id
      AND 1 - (f.embedding <=> p_face_embedding) > p_threshold
    ORDER BY f.embedding <=> p_face_embedding
    LIMIT p_limit;
END;
$$;


ALTER FUNCTION public.find_similar_faces(p_user_id uuid, p_face_embedding public.vector, p_threshold double precision, p_limit integer) OWNER TO vault;

--
-- Name: semantic_search(uuid, public.vector, integer); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.semantic_search(p_user_id uuid, p_query_embedding public.vector, p_limit integer DEFAULT 20) RETURNS TABLE(item_id uuid, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        e.item_id,
        1 - (e.embedding <=> p_query_embedding) as similarity
    FROM embeddings e
    JOIN vault_items v ON e.item_id = v.id
    WHERE e.user_id = p_user_id
      AND v.deleted_at IS NULL
    ORDER BY e.embedding <=> p_query_embedding
    LIMIT p_limit;
END;
$$;


ALTER FUNCTION public.semantic_search(p_user_id uuid, p_query_embedding public.vector, p_limit integer) OWNER TO vault;

--
-- Name: update_album_count(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_album_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE albums SET item_count = item_count + 1, updated_at = NOW()
        WHERE id = NEW.album_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE albums SET item_count = GREATEST(0, item_count - 1), updated_at = NOW()
        WHERE id = OLD.album_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_album_count() OWNER TO vault;

--
-- Name: update_storage_quota(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_storage_quota() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO storage_quotas (user_id, used_bytes, file_count)
        VALUES (NEW.user_id, NEW.file_size, 1)
        ON CONFLICT (user_id) DO UPDATE
        SET used_bytes = storage_quotas.used_bytes + NEW.file_size,
            file_count = storage_quotas.file_count + 1,
            updated_at = NOW();
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE storage_quotas 
        SET used_bytes = GREATEST(0, used_bytes - OLD.file_size),
            file_count = GREATEST(0, file_count - 1),
            updated_at = NOW()
        WHERE user_id = OLD.user_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_storage_quota() OWNER TO vault;

--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: vault
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at() OWNER TO vault;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: album_items; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.album_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    album_id uuid NOT NULL,
    item_id uuid NOT NULL,
    sort_order integer DEFAULT 0,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.album_items OWNER TO vault;

--
-- Name: albums; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.albums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    parent_id uuid,
    encrypted_name text NOT NULL,
    encrypted_description text,
    cover_item_id uuid,
    item_count integer DEFAULT 0,
    is_smart_album boolean DEFAULT false,
    smart_criteria jsonb,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.albums OWNER TO vault;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(64) NOT NULL,
    key_prefix character varying(8) NOT NULL,
    scopes text[] DEFAULT ARRAY['read'::text],
    rate_limit integer DEFAULT 1000,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_keys OWNER TO vault;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id uuid,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO vault;

--
-- Name: chat_conversations; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.chat_conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(20) NOT NULL,
    encrypted_name bytea,
    encrypted_avatar bytea,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chat_conversations_type_check CHECK (((type)::text = ANY ((ARRAY['direct'::character varying, 'group'::character varying, 'channel'::character varying])::text[])))
);


ALTER TABLE public.chat_conversations OWNER TO vault;

--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.chat_members (
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying,
    encrypted_conversation_key bytea NOT NULL,
    joined_at timestamp with time zone DEFAULT now(),
    last_read_at timestamp with time zone,
    muted_until timestamp with time zone
);


ALTER TABLE public.chat_members OWNER TO vault;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid,
    sender_id uuid,
    encrypted_content bytea NOT NULL,
    encrypted_media_ref bytea,
    message_type character varying(20) DEFAULT 'text'::character varying,
    reply_to_id uuid,
    forwarded_from_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.chat_messages OWNER TO vault;

--
-- Name: chat_reactions; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.chat_reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    user_id uuid,
    emoji character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.chat_reactions OWNER TO vault;

--
-- Name: chat_read_receipts; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.chat_read_receipts (
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    last_read_message_id uuid,
    read_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.chat_read_receipts OWNER TO vault;

--
-- Name: collaborators; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.collaborators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    album_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    collaborator_id uuid,
    collaborator_email character varying(255),
    can_view boolean DEFAULT true,
    can_add boolean DEFAULT false,
    can_remove boolean DEFAULT false,
    can_edit boolean DEFAULT false,
    can_share boolean DEFAULT false,
    encrypted_album_key text,
    status character varying(20) DEFAULT 'pending'::character varying,
    invited_at timestamp with time zone DEFAULT now(),
    accepted_at timestamp with time zone,
    CONSTRAINT collaborator_has_identity CHECK (((collaborator_id IS NOT NULL) OR (collaborator_email IS NOT NULL)))
);


ALTER TABLE public.collaborators OWNER TO vault;

--
-- Name: data_exports; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.data_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    file_path text,
    file_size bigint,
    download_count integer DEFAULT 0,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    error_message text
);


ALTER TABLE public.data_exports OWNER TO vault;

--
-- Name: document_metadata; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.document_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    encrypted_summary text,
    encrypted_entities text,
    category character varying(100),
    encrypted_ocr_text text,
    document_date date,
    expiry_date date,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.document_metadata OWNER TO vault;

--
-- Name: embeddings; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.embeddings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    embedding_type character varying(50) NOT NULL,
    embedding public.vector(1024),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.embeddings OWNER TO vault;

--
-- Name: face_clusters; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.face_clusters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    encrypted_name text,
    relationship character varying(50),
    photo_count integer DEFAULT 0,
    centroid public.vector(512),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.face_clusters OWNER TO vault;

--
-- Name: faces; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.faces (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    cluster_id uuid,
    bbox_x double precision NOT NULL,
    bbox_y double precision NOT NULL,
    bbox_width double precision NOT NULL,
    bbox_height double precision NOT NULL,
    embedding public.vector(512),
    detection_confidence double precision,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.faces OWNER TO vault;

--
-- Name: import_connections; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    access_token text,
    refresh_token text,
    token_expires_at timestamp with time zone,
    credentials jsonb,
    files_imported integer DEFAULT 0,
    bytes_imported bigint DEFAULT 0,
    last_sync timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


ALTER TABLE public.import_connections OWNER TO vault;

--
-- Name: import_history; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    source_id text NOT NULL,
    source_hash text,
    vault_item_id uuid,
    imported_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.import_history OWNER TO vault;

--
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.import_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    paths text[],
    include_shared boolean DEFAULT false,
    preserve_folders boolean DEFAULT true,
    delete_after_import boolean DEFAULT false,
    status character varying(20) DEFAULT 'pending'::character varying,
    total_files integer DEFAULT 0,
    imported_files integer DEFAULT 0,
    failed_files integer DEFAULT 0,
    total_bytes bigint DEFAULT 0,
    imported_bytes bigint DEFAULT 0,
    current_file text,
    errors text[] DEFAULT '{}'::text[],
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.import_jobs OWNER TO vault;

--
-- Name: item_places; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.item_places (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    cluster_id uuid,
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.item_places OWNER TO vault;

--
-- Name: item_versions; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.item_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    version_number integer NOT NULL,
    storage_key text NOT NULL,
    file_size bigint NOT NULL,
    encrypted_metadata text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    change_type character varying(50),
    change_note text
);


ALTER TABLE public.item_versions OWNER TO vault;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title text NOT NULL,
    message text,
    data jsonb,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO vault;

--
-- Name: oauth_accounts; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.oauth_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(20) NOT NULL,
    provider_user_id character varying(255) NOT NULL,
    email character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.oauth_accounts OWNER TO vault;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.password_reset_tokens OWNER TO vault;

--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON TABLE public.password_reset_tokens IS 'Stores password reset tokens with expiration';


--
-- Name: COLUMN password_reset_tokens.token; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.password_reset_tokens.token IS 'Secure random token sent via email';


--
-- Name: COLUMN password_reset_tokens.expires_at; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.password_reset_tokens.expires_at IS 'Token expiration (typically 1 hour)';


--
-- Name: place_clusters; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.place_clusters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    encrypted_name text,
    place_type character varying(50),
    latitude double precision,
    longitude double precision,
    radius_meters double precision DEFAULT 100,
    city character varying(100),
    country character varying(100),
    photo_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.place_clusters OWNER TO vault;

--
-- Name: processing_queue; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.processing_queue (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    task_type character varying(50) NOT NULL,
    priority integer DEFAULT 5,
    status character varying(50) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.processing_queue OWNER TO vault;

--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    key character varying(200) NOT NULL,
    requests integer DEFAULT 1,
    window_start timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rate_limits OWNER TO vault;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: vault
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_limits_id_seq OWNER TO vault;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vault
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: share_links; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.share_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    share_token character varying(64) NOT NULL,
    item_id uuid,
    album_id uuid,
    encrypted_password text,
    expires_at timestamp with time zone,
    max_downloads integer,
    download_count integer DEFAULT 0,
    allow_download boolean DEFAULT true,
    allow_preview boolean DEFAULT true,
    encrypted_message text,
    created_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone,
    revoked_at timestamp with time zone,
    CONSTRAINT share_has_target CHECK (((item_id IS NOT NULL) OR (album_id IS NOT NULL)))
);


ALTER TABLE public.share_links OWNER TO vault;

--
-- Name: shares; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.shares (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    share_token character varying(100) NOT NULL,
    expires_at timestamp without time zone,
    max_views integer,
    view_count integer DEFAULT 0,
    burn_after_view boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed timestamp without time zone
);


ALTER TABLE public.shares OWNER TO vault;

--
-- Name: storage_access_log; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_access_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_name character varying(63),
    object_key text,
    operation character varying(20),
    status_code integer,
    bytes_transferred bigint,
    client_ip inet,
    user_agent text,
    request_id uuid,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_access_log OWNER TO vault;

--
-- Name: storage_buckets; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_buckets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(63) NOT NULL,
    owner_id uuid,
    quota_bytes bigint DEFAULT 0,
    used_bytes bigint DEFAULT 0,
    object_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.storage_buckets OWNER TO vault;

--
-- Name: storage_chunks; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_chunks (
    hash character varying(64) NOT NULL,
    size bigint NOT NULL,
    ref_count integer DEFAULT 1,
    compressed boolean DEFAULT false,
    stored_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_chunks OWNER TO vault;

--
-- Name: storage_multipart_parts; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_multipart_parts (
    upload_id uuid NOT NULL,
    part_number integer NOT NULL,
    chunk_hash character varying(64) NOT NULL,
    size bigint NOT NULL,
    etag character varying(64),
    uploaded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_multipart_parts OWNER TO vault;

--
-- Name: storage_multipart_uploads; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_multipart_uploads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    key text NOT NULL,
    content_type character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '24:00:00'::interval)
);


ALTER TABLE public.storage_multipart_uploads OWNER TO vault;

--
-- Name: storage_object_chunks; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_object_chunks (
    object_id uuid NOT NULL,
    chunk_hash character varying(64) NOT NULL,
    chunk_index integer NOT NULL,
    chunk_offset bigint NOT NULL,
    chunk_size bigint NOT NULL
);


ALTER TABLE public.storage_object_chunks OWNER TO vault;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    key text NOT NULL,
    version integer DEFAULT 1,
    size bigint NOT NULL,
    content_type character varying(255),
    etag character varying(64),
    metadata jsonb DEFAULT '{}'::jsonb,
    is_current boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone
);


ALTER TABLE public.storage_objects OWNER TO vault;

--
-- Name: storage_quotas; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.storage_quotas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_name character varying(50) DEFAULT 'free'::character varying,
    quota_bytes bigint DEFAULT '5368709120'::bigint,
    used_bytes bigint DEFAULT 0,
    file_count integer DEFAULT 0,
    max_file_size bigint DEFAULT 104857600,
    max_versions_per_file integer DEFAULT 10,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.storage_quotas OWNER TO vault;

--
-- Name: sync_tokens; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.sync_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    device_id character varying(100) NOT NULL,
    device_name character varying(255),
    device_public_key text NOT NULL,
    last_sync_version bigint DEFAULT 0,
    last_sync_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sync_tokens OWNER TO vault;

--
-- Name: user_keys; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.user_keys (
    user_id uuid NOT NULL,
    identity_public_key bytea NOT NULL,
    signed_prekey bytea NOT NULL,
    signed_prekey_signature bytea NOT NULL,
    one_time_prekeys bytea[],
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_keys OWNER TO vault;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    device_name character varying(100),
    device_type character varying(50),
    ip_address inet,
    user_agent text,
    last_active_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


ALTER TABLE public.user_sessions OWNER TO vault;

--
-- Name: users; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    auth_hash character varying(255),
    salt character varying(255),
    encrypted_master_key text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_login timestamp without time zone,
    storage_quota_bytes bigint DEFAULT '10737418240'::bigint,
    storage_used_bytes bigint DEFAULT 0,
    email_verified_at timestamp with time zone,
    display_name character varying(100),
    language character varying(10) DEFAULT 'de'::character varying,
    timezone character varying(50) DEFAULT 'Europe/Berlin'::character varying,
    deletion_requested_at timestamp with time zone,
    deletion_scheduled_at timestamp with time zone,
    deletion_reason text,
    login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    totp_secret text,
    totp_enabled_at timestamp with time zone,
    recovery_codes text,
    stripe_customer_id character varying(100),
    stripe_subscription_id character varying(100),
    subscription_status character varying(50) DEFAULT 'free'::character varying,
    subscription_ends_at timestamp with time zone,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    email_verification_expires_at timestamp without time zone,
    deleted_at timestamp without time zone,
    last_login_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO vault;

--
-- Name: COLUMN users.email_verified; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.users.email_verified IS 'Whether user has verified their email address';


--
-- Name: COLUMN users.email_verification_token; Type: COMMENT; Schema: public; Owner: vault
--

COMMENT ON COLUMN public.users.email_verification_token IS 'Token for email verification';


--
-- Name: vault_content; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.vault_content (
    id integer NOT NULL,
    storage_key text NOT NULL,
    user_id text NOT NULL,
    encrypted_content bytea NOT NULL,
    original_size integer NOT NULL,
    encrypted_size integer NOT NULL,
    checksum text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    accessed_at timestamp without time zone
);


ALTER TABLE public.vault_content OWNER TO vault;

--
-- Name: vault_content_id_seq; Type: SEQUENCE; Schema: public; Owner: vault
--

CREATE SEQUENCE public.vault_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vault_content_id_seq OWNER TO vault;

--
-- Name: vault_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vault
--

ALTER SEQUENCE public.vault_content_id_seq OWNED BY public.vault_content.id;


--
-- Name: vault_items; Type: TABLE; Schema: public; Owner: vault
--

CREATE TABLE public.vault_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    item_type character varying(50) NOT NULL,
    encrypted_metadata text,
    storage_key character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    captured_at timestamp without time zone,
    deleted_at timestamp without time zone,
    sync_version bigint DEFAULT 1,
    device_id character varying(100),
    processing_status character varying(50) DEFAULT 'pending'::character varying,
    processed_at timestamp without time zone,
    current_version integer DEFAULT 1,
    source_provider character varying(50),
    source_path text
);


ALTER TABLE public.vault_items OWNER TO vault;

--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: vault_content id; Type: DEFAULT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content ALTER COLUMN id SET DEFAULT nextval('public.vault_content_id_seq'::regclass);


--
-- Data for Name: album_items; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.album_items (id, album_id, item_id, sort_order, added_at) FROM stdin;
\.


--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.albums (id, user_id, parent_id, encrypted_name, encrypted_description, cover_item_id, item_count, is_smart_album, smart_criteria, sort_order, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.api_keys (id, user_id, name, key_hash, key_prefix, scopes, rate_limit, last_used_at, expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.audit_log (id, user_id, action, resource_type, resource_id, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: chat_conversations; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.chat_conversations (id, type, encrypted_name, encrypted_avatar, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.chat_members (conversation_id, user_id, role, encrypted_conversation_key, joined_at, last_read_at, muted_until) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.chat_messages (id, conversation_id, sender_id, encrypted_content, encrypted_media_ref, message_type, reply_to_id, forwarded_from_id, created_at, edited_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: chat_reactions; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.chat_reactions (id, message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: chat_read_receipts; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.chat_read_receipts (conversation_id, user_id, last_read_message_id, read_at) FROM stdin;
\.


--
-- Data for Name: collaborators; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.collaborators (id, album_id, owner_id, collaborator_id, collaborator_email, can_view, can_add, can_remove, can_edit, can_share, encrypted_album_key, status, invited_at, accepted_at) FROM stdin;
\.


--
-- Data for Name: data_exports; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.data_exports (id, user_id, status, file_path, file_size, download_count, expires_at, created_at, completed_at, error_message) FROM stdin;
\.


--
-- Data for Name: document_metadata; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.document_metadata (id, item_id, user_id, encrypted_summary, encrypted_entities, category, encrypted_ocr_text, document_date, expiry_date, created_at) FROM stdin;
\.


--
-- Data for Name: embeddings; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.embeddings (id, item_id, user_id, embedding_type, embedding, created_at) FROM stdin;
\.


--
-- Data for Name: face_clusters; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.face_clusters (id, user_id, encrypted_name, relationship, photo_count, centroid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: faces; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.faces (id, item_id, user_id, cluster_id, bbox_x, bbox_y, bbox_width, bbox_height, embedding, detection_confidence, created_at) FROM stdin;
\.


--
-- Data for Name: import_connections; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_connections (id, user_id, provider, access_token, refresh_token, token_expires_at, credentials, files_imported, bytes_imported, last_sync, created_at, updated_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: import_history; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_history (id, user_id, provider, source_id, source_hash, vault_item_id, imported_at) FROM stdin;
\.


--
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.import_jobs (id, user_id, provider, paths, include_shared, preserve_folders, delete_after_import, status, total_files, imported_files, failed_files, total_bytes, imported_bytes, current_file, errors, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: item_places; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.item_places (id, item_id, cluster_id, latitude, longitude, created_at) FROM stdin;
\.


--
-- Data for Name: item_versions; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.item_versions (id, item_id, version_number, storage_key, file_size, encrypted_metadata, created_by, created_at, change_type, change_note) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.notifications (id, user_id, type, title, message, data, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_accounts; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.oauth_accounts (id, user_id, provider, provider_user_id, email, created_at) FROM stdin;
66ae9fc9-a544-4300-b40b-04fd6a7efd9a	38af4a58-060d-45c4-bd94-03306c51ddb4	github	257727251	christoph@0711.io	2026-02-17 20:23:14.704767
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: place_clusters; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.place_clusters (id, user_id, encrypted_name, place_type, latitude, longitude, radius_meters, city, country, photo_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: processing_queue; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.processing_queue (id, item_id, user_id, task_type, priority, status, attempts, max_attempts, error_message, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.rate_limits (id, key, requests, window_start) FROM stdin;
\.


--
-- Data for Name: share_links; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.share_links (id, user_id, share_token, item_id, album_id, encrypted_password, expires_at, max_downloads, download_count, allow_download, allow_preview, encrypted_message, created_at, last_accessed_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: shares; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.shares (id, item_id, user_id, share_token, expires_at, max_views, view_count, burn_after_view, created_at, last_accessed) FROM stdin;
\.


--
-- Data for Name: storage_access_log; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_access_log (id, bucket_name, object_key, operation, status_code, bytes_transferred, client_ip, user_agent, request_id, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: storage_buckets; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_buckets (id, name, owner_id, quota_bytes, used_bytes, object_count, created_at, deleted_at) FROM stdin;
241f3151-b486-4e47-838e-286410075aeb	vault	\N	0	176625233	13	2026-02-03 01:49:52.094556+00	\N
\.


--
-- Data for Name: storage_chunks; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_chunks (hash, size, ref_count, compressed, stored_at) FROM stdin;
\.


--
-- Data for Name: storage_multipart_parts; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_multipart_parts (upload_id, part_number, chunk_hash, size, etag, uploaded_at) FROM stdin;
\.


--
-- Data for Name: storage_multipart_uploads; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_multipart_uploads (id, bucket_id, key, content_type, metadata, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: storage_object_chunks; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_object_chunks (object_id, chunk_hash, chunk_index, chunk_offset, chunk_size) FROM stdin;
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_objects (id, bucket_id, key, version, size, content_type, etag, metadata, is_current, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: storage_quotas; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.storage_quotas (id, user_id, plan_name, quota_bytes, used_bytes, file_count, max_file_size, max_versions_per_file, updated_at) FROM stdin;
\.


--
-- Data for Name: sync_tokens; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.sync_tokens (id, user_id, device_id, device_name, device_public_key, last_sync_version, last_sync_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_keys; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.user_keys (user_id, identity_public_key, signed_prekey, signed_prekey_signature, one_time_prekeys, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.user_sessions (id, user_id, token_hash, device_name, device_type, ip_address, user_agent, last_active_at, created_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.users (id, email, auth_hash, salt, encrypted_master_key, created_at, updated_at, last_login, storage_quota_bytes, storage_used_bytes, email_verified_at, display_name, language, timezone, deletion_requested_at, deletion_scheduled_at, deletion_reason, login_attempts, locked_until, totp_secret, totp_enabled_at, recovery_codes, stripe_customer_id, stripe_subscription_id, subscription_status, subscription_ends_at, email_verified, email_verification_token, email_verification_expires_at, deleted_at, last_login_at) FROM stdin;
38af4a58-060d-45c4-bd94-03306c51ddb4	christoph@0711.io	$2b$12$kCosd5COI92VSIJIymOmAui4XQGboWdkxMbn69ASPj7/JEo6F.7pm	\N	\N	2026-02-17 20:05:23.981641	2026-02-17 20:55:31.885826	\N	10737418240	0	\N	christoph	de	Europe/Berlin	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	free	\N	f	\N	\N	\N	2026-02-17 20:55:31.885826
\.


--
-- Data for Name: vault_content; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.vault_content (id, storage_key, user_id, encrypted_content, original_size, encrypted_size, checksum, created_at, accessed_at) FROM stdin;
\.


--
-- Data for Name: vault_items; Type: TABLE DATA; Schema: public; Owner: vault
--

COPY public.vault_items (id, user_id, item_type, encrypted_metadata, storage_key, file_size, mime_type, created_at, updated_at, captured_at, deleted_at, sync_version, device_id, processing_status, processed_at, current_version, source_provider, source_path) FROM stdin;
\.


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vault
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: vault_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vault
--

SELECT pg_catalog.setval('public.vault_content_id_seq', 1, false);


--
-- Name: album_items album_items_album_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_album_id_item_id_key UNIQUE (album_id, item_id);


--
-- Name: album_items album_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_pkey PRIMARY KEY (id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: chat_conversations chat_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_pkey PRIMARY KEY (id);


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (conversation_id, user_id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_reactions chat_reactions_message_id_user_id_emoji_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_message_id_user_id_emoji_key UNIQUE (message_id, user_id, emoji);


--
-- Name: chat_reactions chat_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_pkey PRIMARY KEY (id);


--
-- Name: chat_read_receipts chat_read_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_read_receipts
    ADD CONSTRAINT chat_read_receipts_pkey PRIMARY KEY (conversation_id, user_id);


--
-- Name: collaborators collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_pkey PRIMARY KEY (id);


--
-- Name: data_exports data_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_pkey PRIMARY KEY (id);


--
-- Name: document_metadata document_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_pkey PRIMARY KEY (id);


--
-- Name: embeddings embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_pkey PRIMARY KEY (id);


--
-- Name: face_clusters face_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.face_clusters
    ADD CONSTRAINT face_clusters_pkey PRIMARY KEY (id);


--
-- Name: faces faces_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_pkey PRIMARY KEY (id);


--
-- Name: import_connections import_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_pkey PRIMARY KEY (id);


--
-- Name: import_connections import_connections_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_user_id_provider_key UNIQUE (user_id, provider);


--
-- Name: import_history import_history_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_pkey PRIMARY KEY (id);


--
-- Name: import_history import_history_user_id_provider_source_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_user_id_provider_source_id_key UNIQUE (user_id, provider, source_id);


--
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- Name: item_places item_places_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_pkey PRIMARY KEY (id);


--
-- Name: item_versions item_versions_item_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_item_id_version_number_key UNIQUE (item_id, version_number);


--
-- Name: item_versions item_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_accounts oauth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_pkey PRIMARY KEY (id);


--
-- Name: oauth_accounts oauth_accounts_provider_provider_user_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_provider_provider_user_id_key UNIQUE (provider, provider_user_id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: place_clusters place_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.place_clusters
    ADD CONSTRAINT place_clusters_pkey PRIMARY KEY (id);


--
-- Name: processing_queue processing_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_key_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_key_key UNIQUE (key);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: share_links share_links_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_pkey PRIMARY KEY (id);


--
-- Name: share_links share_links_share_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_share_token_key UNIQUE (share_token);


--
-- Name: shares shares_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_pkey PRIMARY KEY (id);


--
-- Name: shares shares_share_token_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_share_token_key UNIQUE (share_token);


--
-- Name: storage_access_log storage_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_access_log
    ADD CONSTRAINT storage_access_log_pkey PRIMARY KEY (id);


--
-- Name: storage_buckets storage_buckets_name_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_buckets
    ADD CONSTRAINT storage_buckets_name_key UNIQUE (name);


--
-- Name: storage_buckets storage_buckets_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_buckets
    ADD CONSTRAINT storage_buckets_pkey PRIMARY KEY (id);


--
-- Name: storage_chunks storage_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_chunks
    ADD CONSTRAINT storage_chunks_pkey PRIMARY KEY (hash);


--
-- Name: storage_multipart_parts storage_multipart_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_parts
    ADD CONSTRAINT storage_multipart_parts_pkey PRIMARY KEY (upload_id, part_number);


--
-- Name: storage_multipart_uploads storage_multipart_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_uploads
    ADD CONSTRAINT storage_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: storage_object_chunks storage_object_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_pkey PRIMARY KEY (object_id, chunk_index);


--
-- Name: storage_objects storage_objects_bucket_id_key_version_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_bucket_id_key_version_key UNIQUE (bucket_id, key, version);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: storage_quotas storage_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_pkey PRIMARY KEY (id);


--
-- Name: storage_quotas storage_quotas_user_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_user_id_key UNIQUE (user_id);


--
-- Name: sync_tokens sync_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_pkey PRIMARY KEY (id);


--
-- Name: sync_tokens sync_tokens_user_id_device_id_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_user_id_device_id_key UNIQUE (user_id, device_id);


--
-- Name: password_reset_tokens unique_user_reset; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT unique_user_reset UNIQUE (user_id);


--
-- Name: user_keys user_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_pkey PRIMARY KEY (user_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vault_content vault_content_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content
    ADD CONSTRAINT vault_content_pkey PRIMARY KEY (id);


--
-- Name: vault_content vault_content_storage_key_key; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_content
    ADD CONSTRAINT vault_content_storage_key_key UNIQUE (storage_key);


--
-- Name: vault_items vault_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_items
    ADD CONSTRAINT vault_items_pkey PRIMARY KEY (id);


--
-- Name: idx_access_log_bucket; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_access_log_bucket ON public.storage_access_log USING btree (bucket_name);


--
-- Name: idx_access_log_time; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_access_log_time ON public.storage_access_log USING btree (created_at);


--
-- Name: idx_album_items_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_album_items_album ON public.album_items USING btree (album_id);


--
-- Name: idx_album_items_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_album_items_item ON public.album_items USING btree (item_id);


--
-- Name: idx_albums_parent; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_albums_parent ON public.albums USING btree (parent_id);


--
-- Name: idx_albums_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_albums_user ON public.albums USING btree (user_id);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_resource ON public.audit_log USING btree (resource_type, resource_id);


--
-- Name: idx_audit_time; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_time ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_chat_members_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_chat_members_user ON public.chat_members USING btree (user_id);


--
-- Name: idx_chat_messages_conversation; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_chat_messages_conversation ON public.chat_messages USING btree (conversation_id, created_at DESC);


--
-- Name: idx_chat_messages_sender; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_chat_messages_sender ON public.chat_messages USING btree (sender_id);


--
-- Name: idx_chat_reactions_message; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_chat_reactions_message ON public.chat_reactions USING btree (message_id);


--
-- Name: idx_collaborators_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_album ON public.collaborators USING btree (album_id);


--
-- Name: idx_collaborators_email; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_email ON public.collaborators USING btree (collaborator_email);


--
-- Name: idx_collaborators_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_collaborators_user ON public.collaborators USING btree (collaborator_id);


--
-- Name: idx_content_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_content_key ON public.vault_content USING btree (storage_key);


--
-- Name: idx_content_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_content_user ON public.vault_content USING btree (user_id);


--
-- Name: idx_document_metadata_category; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_document_metadata_category ON public.document_metadata USING btree (category);


--
-- Name: idx_document_metadata_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_document_metadata_item ON public.document_metadata USING btree (item_id);


--
-- Name: idx_embeddings_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_item ON public.embeddings USING btree (item_id);


--
-- Name: idx_embeddings_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_user ON public.embeddings USING btree (user_id);


--
-- Name: idx_embeddings_vector; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_embeddings_vector ON public.embeddings USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_exports_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_exports_user ON public.data_exports USING btree (user_id);


--
-- Name: idx_face_clusters_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_face_clusters_user ON public.face_clusters USING btree (user_id);


--
-- Name: idx_faces_cluster; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_cluster ON public.faces USING btree (cluster_id);


--
-- Name: idx_faces_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_item ON public.faces USING btree (item_id);


--
-- Name: idx_faces_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_user ON public.faces USING btree (user_id);


--
-- Name: idx_faces_vector; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_faces_vector ON public.faces USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_import_connections_provider; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_connections_provider ON public.import_connections USING btree (provider);


--
-- Name: idx_import_connections_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_connections_user ON public.import_connections USING btree (user_id);


--
-- Name: idx_import_history_lookup; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_history_lookup ON public.import_history USING btree (user_id, provider, source_id);


--
-- Name: idx_import_jobs_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_jobs_status ON public.import_jobs USING btree (status);


--
-- Name: idx_import_jobs_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_import_jobs_user ON public.import_jobs USING btree (user_id);


--
-- Name: idx_item_places_cluster; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_item_places_cluster ON public.item_places USING btree (cluster_id);


--
-- Name: idx_item_places_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_item_places_item ON public.item_places USING btree (item_id);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id, read_at) WHERE (read_at IS NULL);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id);


--
-- Name: idx_oauth_accounts_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_oauth_accounts_user ON public.oauth_accounts USING btree (user_id);


--
-- Name: idx_objects_bucket_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_objects_bucket_key ON public.storage_objects USING btree (bucket_id, key) WHERE (is_current = true);


--
-- Name: idx_password_reset_tokens_expires; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_expires ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token);


--
-- Name: idx_password_reset_tokens_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_password_reset_tokens_user ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_place_clusters_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_place_clusters_user ON public.place_clusters USING btree (user_id);


--
-- Name: idx_processing_queue_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_processing_queue_item ON public.processing_queue USING btree (item_id);


--
-- Name: idx_processing_queue_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_processing_queue_status ON public.processing_queue USING btree (status, priority);


--
-- Name: idx_quotas_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_quotas_user ON public.storage_quotas USING btree (user_id);


--
-- Name: idx_rate_limits_key; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_rate_limits_key ON public.rate_limits USING btree (key);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sessions_token ON public.user_sessions USING btree (token_hash);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: idx_share_links_album; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_album ON public.share_links USING btree (album_id);


--
-- Name: idx_share_links_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_item ON public.share_links USING btree (item_id);


--
-- Name: idx_share_links_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_token ON public.share_links USING btree (share_token);


--
-- Name: idx_share_links_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_share_links_user ON public.share_links USING btree (user_id);


--
-- Name: idx_shares_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_shares_item ON public.shares USING btree (item_id);


--
-- Name: idx_shares_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_shares_token ON public.shares USING btree (share_token);


--
-- Name: idx_sync_tokens_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_sync_tokens_user ON public.sync_tokens USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_verification_token; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_users_email_verification_token ON public.users USING btree (email_verification_token) WHERE (email_verification_token IS NOT NULL);


--
-- Name: idx_vault_items_source; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_source ON public.vault_items USING btree (source_provider) WHERE (source_provider IS NOT NULL);


--
-- Name: idx_vault_items_status; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_status ON public.vault_items USING btree (processing_status);


--
-- Name: idx_vault_items_sync; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_sync ON public.vault_items USING btree (user_id, sync_version);


--
-- Name: idx_vault_items_type; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_type ON public.vault_items USING btree (item_type);


--
-- Name: idx_vault_items_user; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_vault_items_user ON public.vault_items USING btree (user_id);


--
-- Name: idx_versions_item; Type: INDEX; Schema: public; Owner: vault
--

CREATE INDEX idx_versions_item ON public.item_versions USING btree (item_id);


--
-- Name: face_clusters face_clusters_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER face_clusters_updated_at BEFORE UPDATE ON public.face_clusters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: place_clusters place_clusters_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER place_clusters_updated_at BEFORE UPDATE ON public.place_clusters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: album_items trigger_update_album_count; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER trigger_update_album_count AFTER INSERT OR DELETE ON public.album_items FOR EACH ROW EXECUTE FUNCTION public.update_album_count();


--
-- Name: vault_items trigger_update_quota; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER trigger_update_quota AFTER INSERT OR DELETE ON public.vault_items FOR EACH ROW EXECUTE FUNCTION public.update_storage_quota();


--
-- Name: users users_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: vault_items vault_items_updated_at; Type: TRIGGER; Schema: public; Owner: vault
--

CREATE TRIGGER vault_items_updated_at BEFORE UPDATE ON public.vault_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: album_items album_items_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: album_items album_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.album_items
    ADD CONSTRAINT album_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: albums albums_cover_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_cover_item_id_fkey FOREIGN KEY (cover_item_id) REFERENCES public.vault_items(id);


--
-- Name: albums albums_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.albums(id);


--
-- Name: albums albums_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chat_conversations chat_conversations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: chat_members chat_members_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_reply_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_reply_to_id_fkey FOREIGN KEY (reply_to_id) REFERENCES public.chat_messages(id) ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chat_reactions chat_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON DELETE CASCADE;


--
-- Name: chat_reactions chat_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_read_receipts chat_read_receipts_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_read_receipts
    ADD CONSTRAINT chat_read_receipts_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id) ON DELETE CASCADE;


--
-- Name: chat_read_receipts chat_read_receipts_last_read_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_read_receipts
    ADD CONSTRAINT chat_read_receipts_last_read_message_id_fkey FOREIGN KEY (last_read_message_id) REFERENCES public.chat_messages(id) ON DELETE SET NULL;


--
-- Name: chat_read_receipts chat_read_receipts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.chat_read_receipts
    ADD CONSTRAINT chat_read_receipts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: collaborators collaborators_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: collaborators collaborators_collaborator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_collaborator_id_fkey FOREIGN KEY (collaborator_id) REFERENCES public.users(id);


--
-- Name: collaborators collaborators_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT collaborators_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: data_exports data_exports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: document_metadata document_metadata_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: document_metadata document_metadata_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.document_metadata
    ADD CONSTRAINT document_metadata_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: embeddings embeddings_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: embeddings embeddings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: face_clusters face_clusters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.face_clusters
    ADD CONSTRAINT face_clusters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: faces faces_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.face_clusters(id) ON DELETE SET NULL;


--
-- Name: faces faces_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: faces faces_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.faces
    ADD CONSTRAINT faces_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_connections import_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_connections
    ADD CONSTRAINT import_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: import_history import_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: import_history import_history_vault_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_history
    ADD CONSTRAINT import_history_vault_item_id_fkey FOREIGN KEY (vault_item_id) REFERENCES public.vault_items(id);


--
-- Name: import_jobs import_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: item_places item_places_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.place_clusters(id) ON DELETE SET NULL;


--
-- Name: item_places item_places_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_places
    ADD CONSTRAINT item_places_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: item_versions item_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: item_versions item_versions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.item_versions
    ADD CONSTRAINT item_versions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_accounts oauth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: place_clusters place_clusters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.place_clusters
    ADD CONSTRAINT place_clusters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: processing_queue processing_queue_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: processing_queue processing_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.processing_queue
    ADD CONSTRAINT processing_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: share_links share_links_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id);


--
-- Name: share_links share_links_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id);


--
-- Name: share_links share_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.share_links
    ADD CONSTRAINT share_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shares shares_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.vault_items(id) ON DELETE CASCADE;


--
-- Name: shares shares_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: storage_multipart_parts storage_multipart_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_parts
    ADD CONSTRAINT storage_multipart_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.storage_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: storage_multipart_uploads storage_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_multipart_uploads
    ADD CONSTRAINT storage_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.storage_buckets(id);


--
-- Name: storage_object_chunks storage_object_chunks_chunk_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_chunk_hash_fkey FOREIGN KEY (chunk_hash) REFERENCES public.storage_chunks(hash);


--
-- Name: storage_object_chunks storage_object_chunks_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_object_chunks
    ADD CONSTRAINT storage_object_chunks_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.storage_objects(id) ON DELETE CASCADE;


--
-- Name: storage_objects storage_objects_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.storage_buckets(id);


--
-- Name: storage_quotas storage_quotas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.storage_quotas
    ADD CONSTRAINT storage_quotas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sync_tokens sync_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.sync_tokens
    ADD CONSTRAINT sync_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_keys user_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vault_items vault_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: vault
--

ALTER TABLE ONLY public.vault_items
    ADD CONSTRAINT vault_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict PbBrvzVjEMz5FBq3OWfQSBpK1u3QWtUjHatrVNKZHakMSsWdw7gmiIbGQUClJK0

